// Runs in its own process (engine/child.js): finds who speaks when, then transcribes every turn with
// Whisper. Input: a raw 16 kHz mono s16le file. Everything stays on the computer.
import fs from 'node:fs';
import os from 'node:os';
import { createRequire } from 'node:module';
import { assignGlobalSpeakers, buildUnits, cleanTurns, splitAtQuietPoints } from './turns.js';
import { cleanText } from './text.js';

const require = createRequire(import.meta.url);
const sherpa = require('sherpa-onnx-node');

const RATE = 16_000;
const BLOCK_SEC_DEFAULT = 5 * 60; // the voices are found 5 minutes at a time: low memory on long videos, and a visible progress
const threads = Math.max(1, Math.min(8, (os.availableParallelism?.() || os.cpus().length) - 1));

const progress = (phase, done, total, extra = {}) => post({ type: 'progress', phase, done, total, ...extra });

let pcmFile;
let models;
let options;
let post;
let totalSamples;
let totalSec;
let fd;
let BLOCK_SEC = BLOCK_SEC_DEFAULT;

/** Reads [start, end) seconds of the audio as floats in [-1, 1]. */
const readAudio = (startSec, endSec) => {
  const first = Math.max(0, Math.floor(startSec * RATE));
  const last = Math.min(totalSamples, Math.ceil(endSec * RATE));
  const count = Math.max(0, last - first);
  const bytes = Buffer.alloc(count * 2);
  fs.readSync(fd, bytes, 0, bytes.length, first * 2);
  const out = new Float32Array(count);
  for (let i = 0; i < count; i++) out[i] = bytes.readInt16LE(i * 2) / 32768;
  return out;
};

const embeddingOf = (extractor, samples) => {
  const stream = extractor.createStream();
  stream.acceptWaveform({ sampleRate: RATE, samples });
  stream.inputFinished();
  if (!extractor.isReady(stream)) return null;
  return Float32Array.from(extractor.compute(stream));
};

/* --------------------------------------------------------------- who speaks when */

const speechWithVad = async () => {
  const vad = new sherpa.Vad(
    { sileroVad: { model: models.vad, threshold: 0.45, minSilenceDuration: 0.35, minSpeechDuration: 0.2, windowSize: 512, maxSpeechDuration: 25 }, sampleRate: RATE, numThreads: 1, debug: 0 },
    60,
  );
  const turns = [];
  const drain = () => {
    while (!vad.isEmpty()) {
      const segment = vad.front(false);
      turns.push({ start: segment.start / RATE, end: (segment.start + segment.samples.length) / RATE, speaker: 0 });
      vad.pop();
    }
  };
  const blocks = Math.ceil(totalSec / BLOCK_SEC);
  for (let b = 0; b < blocks; b++) {
    const samples = readAudio(b * BLOCK_SEC, Math.min(totalSec, (b + 1) * BLOCK_SEC));
    for (let i = 0; i + 512 <= samples.length; i += 512) {
      vad.acceptWaveform(samples.subarray(i, i + 512));
      drain();
    }
    progress('voices', b + 1, blocks);
    await tick();
  }
  vad.flush();
  drain();
  return { turns, speakerCount: turns.length ? 1 : 0 };
};

const speechWithDiarization = async (wantedSpeakers) => {
  const diarization = new sherpa.OfflineSpeakerDiarization({
    segmentation: { pyannote: { model: models.segmentation }, numThreads: threads },
    embedding: { model: models.embedding, numThreads: threads },
    // a little over-split inside each block: the voices are merged again across the whole video below
    clustering: { numClusters: -1, threshold: 0.6 },
    minDurationOn: 0.25,
    minDurationOff: 0.4,
  });
  const extractor = new sherpa.SpeakerEmbeddingExtractor({ model: models.embedding, numThreads: threads, debug: 0 });
  const blocks = Math.ceil(totalSec / BLOCK_SEC);
  const turns = [];
  const locals = []; // { key, embedding, seconds }
  for (let b = 0; b < blocks; b++) {
    const offset = b * BLOCK_SEC;
    const samples = readAudio(offset, Math.min(totalSec, offset + BLOCK_SEC));
    const segments = cleanTurns(diarization.process(samples).map((s) => ({ start: s.start, end: s.end, speaker: s.speaker })));
    const bySpeaker = new Map();
    for (const s of segments) {
      const key = `${b}:${s.speaker}`;
      turns.push({ start: s.start + offset, end: s.end + offset, speaker: key });
      if (!bySpeaker.has(key)) bySpeaker.set(key, []);
      bySpeaker.get(key).push(s);
    }
    for (const [key, list] of bySpeaker) {
      // up to 30 s of the clearest (longest) turns of this voice
      const chosen = [...list].sort((x, y) => y.end - y.start - (x.end - x.start));
      const parts = [];
      let length = 0;
      for (const s of chosen) {
        if (length > 30 * RATE) break;
        const part = samples.subarray(Math.floor(s.start * RATE), Math.floor(s.end * RATE));
        parts.push(part);
        length += part.length;
      }
      const joined = new Float32Array(length);
      let at = 0;
      for (const part of parts) {
        joined.set(part, at);
        at += part.length;
      }
      const embedding = length > 0.4 * RATE ? embeddingOf(extractor, joined) : null;
      locals.push({ key, embedding, seconds: list.reduce((sum, s) => sum + s.end - s.start, 0) });
    }
    progress('voices', b + 1, blocks);
    await tick();
  }
  const mapping = assignGlobalSpeakers(locals, { wanted: wantedSpeakers });
  const ordered = turns.map((t) => ({ ...t, speaker: mapping.get(t.speaker) ?? 0 })).sort((a, b) => a.start - b.start);
  // number the voices in order of first appearance
  const renumber = new Map();
  for (const t of ordered) if (!renumber.has(t.speaker)) renumber.set(t.speaker, renumber.size);
  return { turns: ordered.map((t) => ({ ...t, speaker: renumber.get(t.speaker) })), speakerCount: renumber.size };
};

/* --------------------------------------------------------------- language */

const recognizerConfig = (language) => ({
  featConfig: { sampleRate: RATE, featureDim: 80 },
  modelConfig: {
    whisper: { encoder: models.encoder, decoder: models.decoder, language, task: 'transcribe', tailPaddings: -1 },
    tokens: models.tokens,
    numThreads: threads,
    provider: 'cpu',
    debug: 0,
  },
});

const decodeUnit = (recognizer, unit) => {
  const stream = recognizer.createStream();
  stream.acceptWaveform({ sampleRate: RATE, samples: readAudio(unit.start, unit.end) });
  recognizer.decode(stream);
  return recognizer.getResult(stream);
};

/** Whisper guesses the language on the longest passages; the whole video is then read in it. */
const detectLanguage = (recognizer, units) => {
  const votes = new Map();
  const longest = [...units].sort((a, b) => b.end - b.start - (a.end - a.start)).slice(0, 3);
  for (const unit of longest) {
    const lang = decodeUnit(recognizer, unit).lang?.replace(/[<>|]/g, '');
    if (lang) votes.set(lang, (votes.get(lang) || 0) + (unit.end - unit.start));
  }
  return [...votes].sort((a, b) => b[1] - a[1])[0]?.[0] || '';
};

/* --------------------------------------------------------------- main */

const run = async () => {
  const started = Date.now();
  progress('voices', 0, 1);
  const wanted = options.speakers === 'auto' ? 0 : Number(options.speakers) || 0;
  const { turns, speakerCount } = wanted === 1 ? await speechWithVad() : await speechWithDiarization(wanted);
  const units = splitAtQuietPoints(buildUnits(turns), (start, end) => readAudio(start, end));
  if (!units.length) {
    post({ type: 'done', result: { segments: [], speakerCount: 0, language: options.language || '', seconds: totalSec, elapsedMs: Date.now() - started } });
    return;
  }

  const chosen = options.language && options.language !== 'auto' ? options.language : '';
  const recognizer = new sherpa.OfflineRecognizer(recognizerConfig(chosen));
  const language = chosen || detectLanguage(recognizer, units);
  if (language && !chosen) recognizer.setConfig(recognizerConfig(language));
  progress('language', 1, 1, { language });
  await tick();

  const speechSeconds = units.reduce((sum, u) => sum + u.end - u.start, 0);
  let doneSeconds = 0;
  const segments = [];
  const transcribeStarted = Date.now();
  for (let i = 0; i < units.length; i++) {
    const unit = units[i];
    const text = cleanText(decodeUnit(recognizer, unit).text, unit.end - unit.start);
    if (text) segments.push({ start: round(unit.start), end: round(unit.end), speaker: unit.speaker, text });
    doneSeconds += unit.end - unit.start;
    const elapsed = (Date.now() - transcribeStarted) / 1000;
    const remaining = doneSeconds > 0 ? (elapsed / doneSeconds) * (speechSeconds - doneSeconds) : null;
    await tick();
    progress('text', i + 1, units.length, { position: unit.end, remainingSec: remaining, preview: text ? { speaker: unit.speaker, text, start: unit.start } : null });
  }

  const used = [...new Set(segments.map((s) => s.speaker))].sort((a, b) => a - b);
  const renumber = new Map(used.map((id, index) => [id, index]));
  post({
    type: 'done',
    result: {
      segments: segments.map((s) => ({ ...s, speaker: renumber.get(s.speaker) })),
      speakerCount: used.length || speakerCount,
      language,
      seconds: totalSec,
      elapsedMs: Date.now() - started,
    },
  });
};

const round = (value) => Math.round(value * 100) / 100;
// lets the progress messages leave the process between two heavy steps
const tick = () => new Promise((resolve) => setImmediate(resolve));

/** Runs one transcription; every message (progress, done, error) goes to send. */
export const transcribe = async (input, send) => {
  ({ pcmFile, models, options } = input);
  post = send;
  BLOCK_SEC = options.blockSec || BLOCK_SEC_DEFAULT;
  totalSamples = Math.floor(fs.statSync(pcmFile).size / 2);
  totalSec = totalSamples / RATE;
  fd = fs.openSync(pcmFile, 'r');
  try {
    await run();
  } catch (error) {
    post({ type: 'error', message: error.message || String(error) });
  } finally {
    fs.closeSync(fd);
  }
};
