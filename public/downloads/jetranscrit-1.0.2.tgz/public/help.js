// Every problem jetranscrit can run into, what it means and what to do. Used by the error screens
// and by the "Aide" panel. The same list is on the site (justecoqqo.fr/jetranscrit/#problemes).

export const START = [
  { title: 'Choisis ta vidéo', text: 'Un projet CapCut ou Premiere Pro, un fichier (bouton ou glisser-déposer) ou un lien.' },
  { title: 'Laisse travailler', text: "Le texte s'écrit en direct. Tu peux revenir à l'accueil pendant ce temps, mais laisse jetranscrit ouvert." },
  { title: 'Corrige et exporte', text: 'Renomme les voix, corrige les mots, puis exporte tout ou une seule voix.' },
];

export const TIPS = [
  { title: 'Les voix sont mal séparées', text: 'Avant de lancer, indique le nombre de personnes qui parlent dans « Nombre de voix ». Après coup : clique sur la pastille d’une phrase pour changer sa voix, ou utilise « … » puis « Fusionner » sur une voix en trop.' },
  { title: 'Un mot revient mal écrit (un prénom, une marque)', text: 'Utilise « Chercher » puis « Tout remplacer » en haut de la transcription.' },
  { title: 'La langue détectée est fausse', text: 'Choisis la langue dans « Langue » sur l’accueil, puis relance la transcription.' },
  { title: 'C’est long', text: 'Compte environ le tiers ou la moitié de la durée de la vidéo. Ferme les programmes lourds (jeux, montage en cours d’export). Si une seule personne parle, choisis « 1 voix » : c’est plus rapide.' },
  { title: 'Raccourcis', text: 'Ctrl + Espace : lecture / pause. Entrée dans une phrase : la couper en deux. Retour arrière au début d’une phrase : la recoller à la précédente. Ctrl + F : chercher.' },
];

export const PROBLEMS = {
  'first-run': {
    title: 'Le premier lancement télécharge environ 600 Mo',
    text: 'C’est le moteur de transcription. Il est téléchargé une seule fois, puis tout marche sans internet (sauf les liens). Il faut environ 1,5 Go de place libre.',
  },
  'disk-full': {
    title: 'Plus assez de place sur ton disque',
    text: 'jetranscrit a besoin d’environ 1,5 Go pour son moteur, plus à peu près 120 Mo par heure de vidéo. Libère de la place (vide la Corbeille, supprime de vieux rushs), puis relance.',
  },
  'models-download': {
    title: 'Le moteur de transcription ne se télécharge pas',
    text: 'Vérifie ta connexion à internet, puis relance. Si ça bloque encore, un antivirus ou un réseau d’entreprise / d’école bloque peut-être github.com : essaie avec une autre connexion (partage de connexion du téléphone).',
  },
  'no-ffmpeg': {
    title: 'Un composant de jetranscrit manque',
    text: 'Ouvre le launcher justecoqqo, puis ouvre jetranscrit : il répare tout seul. Sinon, retélécharge jetranscrit depuis justecoqqo.fr.',
  },
  'no-audio': {
    title: 'Ce fichier n’a pas de son',
    text: 'La vidéo ne contient pas de piste audio, ou le son est complètement muet. Vérifie que tu as choisi le bon fichier.',
  },
  unreadable: {
    title: 'Ce fichier n’a pas pu être lu',
    text: 'Le format n’est pas reconnu ou le fichier est abîmé (copie pas terminée, fichier d’iPhone encore sur iCloud…). Exporte ou convertis la vidéo en MP4, puis importe-la.',
  },
  'capcut-encrypted': {
    title: 'Ce projet CapCut est verrouillé',
    text: 'CapCut chiffre certains projets (souvent ceux faits depuis un modèle). jetranscrit ne peut pas les lire : exporte la vidéo depuis CapCut, puis choisis « Importer une vidéo ».',
  },
  'missing-media': {
    title: 'Les vidéos du montage sont introuvables',
    text: 'Les fichiers utilisés dans le montage ont été déplacés, renommés ou sont sur un disque débranché. Rebranche le disque ou ouvre le projet dans CapCut / Premiere pour relier les médias. Sinon, exporte la vidéo et importe-la.',
  },
  'silent-edit': {
    title: 'Ce montage n’a pas de son',
    text: 'Toutes les pistes sont muettes ou coupées. Vérifie le volume de tes clips dans le montage.',
  },
  'premiere-unreadable': {
    title: 'Ce projet Premiere Pro n’a pas pu être lu',
    text: 'Certaines versions de Premiere enregistrent leurs projets autrement. Dans Premiere : Fichier › Exporter › Média, choisis un format audio (MP3 ou WAV), puis importe ce fichier dans jetranscrit.',
  },
  'link-private': {
    title: 'Cette vidéo demande une connexion',
    text: 'Elle est privée, réservée aux abonnés ou limitée par l’âge. Télécharge-la depuis ton compte, puis choisis « Importer une vidéo ».',
  },
  'link-unsupported': {
    title: 'Ce site n’est pas pris en charge',
    text: 'Copie le lien de la vidéo elle-même (pas celui d’une page ou d’un profil). Si ça ne marche toujours pas, télécharge la vidéo et importe-la.',
  },
  'link-unavailable': {
    title: 'Cette vidéo n’est pas disponible',
    text: 'Elle a été supprimée, mise en privé, ou est bloquée dans ton pays. Vérifie le lien dans ton navigateur.',
  },
  offline: {
    title: 'Pas de connexion à internet',
    text: 'Les liens et le premier téléchargement du moteur ont besoin d’internet. Les fichiers et projets déjà sur ton ordi, eux, marchent sans.',
  },
  memory: {
    title: 'Pas assez de mémoire',
    text: 'Le moteur a besoin d’environ 2 Go de mémoire libre. Ferme les programmes ouverts (navigateur avec beaucoup d’onglets, jeux, logiciel de montage), puis relance.',
  },
  'engine-crash': {
    title: 'Le moteur de transcription s’est arrêté',
    text: 'Relance la transcription. Si ça recommence, redémarre l’ordinateur. Un antivirus peut aussi bloquer le moteur : autorise jetranscrit dans ton antivirus.',
  },
  'no-speech': {
    title: 'Aucune parole trouvée',
    text: 'Le son ne contient que de la musique, du bruit, ou une voix trop faible. Si c’est un montage, vérifie que la piste de voix n’est pas muette.',
  },
  interrupted: {
    title: 'La transcription a été interrompue',
    text: 'jetranscrit a été fermé (ou l’ordinateur s’est mis en veille) pendant la transcription. Relance-la depuis la vidéo : rien d’autre n’est perdu.',
  },
  smartscreen: {
    title: 'Windows affiche « Windows a protégé votre ordinateur »',
    text: 'C’est normal pour une petite appli pas encore signée avec un certificat payant. Clique sur « Informations complémentaires », puis « Exécuter quand même ».',
  },
};

/** The advice that goes with an error message (by code, else guessed from the text). */
export const problemFor = (code, message = '') => {
  if (code && PROBLEMS[code]) return { code, ...PROBLEMS[code] };
  const text = message.toLowerCase();
  const guess = [
    [/place|espace|disque plein|enospc/, 'disk-full'],
    [/mémoire/, 'memory'],
    [/connexion à internet/, 'offline'],
    [/introuvable : réinstalle|ffmpeg|outil de téléchargement/, 'no-ffmpeg'],
    [/pas de son|ne contient pas de son/, 'no-audio'],
    [/chiffré/, 'capcut-encrypted'],
    [/introuvables|déplacés/, 'missing-media'],
    [/premiere/, 'premiere-unreadable'],
    [/privée|connexion :/, 'link-private'],
    [/pas pris en charge/, 'link-unsupported'],
    [/pas disponible/, 'link-unavailable'],
    [/téléchargement|abîmé|modèles/, 'models-download'],
    [/aucune parole/, 'no-speech'],
    [/moteur/, 'engine-crash'],
    [/lire le son/, 'unreadable'],
  ].find(([pattern]) => pattern.test(text));
  return guess ? { code: guess[1], ...PROBLEMS[guess[1]] } : null;
};
