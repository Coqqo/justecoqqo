// jetranscrit: choosing a video, following the transcription, correcting and exporting it.
import { BRAND } from './brand.js';
import { PROBLEMS, START, TIPS, problemFor } from './help.js';
import { offerReport, setupReports } from './report.js';

const TOKEN = document.querySelector('meta[name="app-token"]').content;
const $ = (id) => document.getElementById(id);
const el = (tag, props = {}, children = []) => {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'style') for (const [name, v] of Object.entries(value)) name.startsWith('--') ? node.style.setProperty(name, v) : (node.style[name] = v);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else if (value !== undefined && value !== null && value !== false) node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of [].concat(children)) if (child !== null && child !== undefined) node.append(child);
  return node;
};
const icon = (name) => {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#i-${name}`);
  svg.append(use);
  return svg;
};

const api = async (path, { method = 'GET', body } = {}) => {
  const response = await fetch(path, { method, headers: { 'X-App-Token': TOKEN, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || `Erreur ${response.status}`), { code: data.code });
  return data;
};
const withToken = (path) => `${path}${path.includes('?') ? '&' : '?'}token=${TOKEN}`;

/* ------------------------------------------------------------------ helpers */

const duration = (seconds) => {
  if (!Number.isFinite(seconds)) return '';
  const s = Math.round(seconds);
  if (s < 60) return `${s} s`;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h} h ${String(m).padStart(2, '0')}` : `${m} min${s % 60 ? ` ${String(s % 60).padStart(2, '0')}` : ''}`;
};
const clock = (seconds) => {
  const s = Math.max(0, Math.floor(seconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
};
const when = (ms) => {
  const date = new Date(ms);
  const today = new Date();
  const time = date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  if (date.toDateString() === today.toDateString()) return `aujourd'hui à ${time}`;
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return `hier à ${time}`;
  return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: date.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
};
const megabytes = (bytes) => `${Math.round(bytes / 1e6)} Mo`;
const LANGS = { fr: 'français', en: 'anglais', es: 'espagnol', de: 'allemand', it: 'italien', pt: 'portugais', nl: 'néerlandais', ar: 'arabe', zh: 'chinois', ja: 'japonais', ru: 'russe' };

let toastTimer;
const toast = (message, kind = '') => {
  const node = $('toast');
  node.textContent = message;
  node.className = `toast ${kind}`;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (node.hidden = true), kind === 'error' ? 6000 : 3200);
};

/* ------------------------------------------------------------------ views and sheets */

let status = {};
const views = ['homeView', 'progressView', 'editorView'];
const show = (view) => {
  for (const id of views) $(id).hidden = id !== view;
  window.scrollTo(0, 0);
  if (view !== 'editorView') stopPlayback();
  if (view === 'homeView') refreshLibrary();
};

let openSheetId = null;
const openSheet = (id) => {
  closeSheet();
  openSheetId = id;
  $('scrim').hidden = false;
  $(id).hidden = false;
};
const closeSheet = () => {
  if (openSheetId) $(openSheetId).hidden = true;
  openSheetId = null;
  $('scrim').hidden = true;
};
$('scrim').addEventListener('click', closeSheet);
document.querySelectorAll('[data-close]').forEach((button) => button.addEventListener('click', closeSheet));
document.querySelectorAll('[data-go-home]').forEach((button) => button.addEventListener('click', () => goHome()));
$('homeBtn').addEventListener('click', () => goHome());

const goHome = async () => {
  await flushSave();
  current = null;
  watching = null;
  show('homeView');
};

/* ------------------------------------------------------------------ help */

const renderHelp = () => {
  $('helpStart').replaceChildren(...START.map((step) => el('li', {}, [el('b', { text: step.title }), el('span', { text: step.text })])));
  const item = (code, entry) => el('details', { 'data-code': code }, [el('summary', { text: entry.title }), el('p', { text: entry.text })]);
  $('helpTips').replaceChildren(...TIPS.map((tip, i) => item(`tip-${i}`, tip)));
  $('helpProblems').replaceChildren(...Object.entries(PROBLEMS).map(([code, entry]) => item(code, entry)));
};
renderHelp();

const openHelp = (code) => {
  openSheet('helpSheet');
  $('helpSheet').querySelectorAll('details').forEach((d) => (d.open = d.dataset.code === code));
  const target = code && $('helpSheet').querySelector(`details[data-code="${code}"]`);
  if (target) setTimeout(() => target.scrollIntoView({ block: 'center', behavior: 'smooth' }), 80);
  else $('helpSheet').scrollTop = 0;
};
$('helpBtn').addEventListener('click', () => openHelp(null));

/** An error before a transcription starts: the message, plus the matching advice when there is one. */
const showError = (error) => {
  setTimeout(() => offerReport(error, { where: 'démarrage' }), 900);
  const problem = problemFor(error.code, error.message);
  toast(problem ? `${error.message} — ${problem.text}` : error.message, 'error');
};

/* ------------------------------------------------------------------ home: library */

const SOURCE_ICONS = { capcut: 'timeline', premiere: 'sequence', file: 'file', upload: 'file', link: 'link' };
const SOURCE_NAMES = { capcut: 'CapCut', premiere: 'Premiere Pro', file: 'Fichier', upload: 'Fichier', link: 'Lien' };
let libraryTimer;

const refreshLibrary = async () => {
  clearTimeout(libraryTimer);
  let items = [];
  try {
    ({ items } = await api('/api/transcriptions'));
  } catch {
    return;
  }
  const list = $('libraryList');
  list.replaceChildren(...items.map(renderEntry));
  $('libraryEmpty').hidden = items.length > 0;
  if (items.some((item) => item.live && !['done', 'error', 'cancelled'].includes(item.live.step)) && !$('homeView').hidden) {
    libraryTimer = setTimeout(refreshLibrary, 1500);
  }
};

const renderEntry = (item) => {
  const live = item.live && !['done', 'error', 'cancelled'].includes(item.live.step) ? item.live : null;
  const meta = [];
  meta.push(el('span', { text: SOURCE_NAMES[item.source?.kind] || '' }));
  if (item.seconds) meta.push(el('span', { text: duration(item.seconds) }));
  if (item.status === 'done' && item.speakerCount) meta.push(el('span', { text: `${item.speakerCount} voix` }));
  meta.push(el('span', { text: when(item.createdAt) }));
  let badge = null;
  if (live) badge = el('span', { class: 'status live', text: live.step === 'queued' ? 'En attente' : `${live.percent || 0} %` });
  else if (item.status === 'error') badge = el('span', { class: 'status error', text: 'Échec' });
  else if (item.status === 'cancelled' || item.status === 'running' || item.status === 'queued') badge = el('span', { class: item.status === 'cancelled' ? 'status' : 'status error', text: item.status === 'cancelled' ? 'Annulée' : 'Interrompue' });
  const interrupted = !live && (item.status === 'running' || item.status === 'queued');
  const failed = !live && (item.status === 'error' || interrupted);

  const remove = el('button', { class: 'icon-btn', type: 'button', title: 'Supprimer', 'aria-label': 'Supprimer' }, icon('trash'));
  remove.addEventListener('click', async (event) => {
    event.stopPropagation();
    if (!remove.classList.contains('confirm')) {
      remove.classList.add('confirm');
      remove.replaceChildren('Supprimer ?');
      remove.className = 'ghost small danger confirm';
      setTimeout(() => remove.isConnected && refreshLibrary(), 4000);
      return;
    }
    await api('/api/transcription/delete', { method: 'POST', body: { id: item.id } });
    refreshLibrary();
  });

  const row = el('div', { class: 'entry', role: 'button', tabindex: '0' }, [
    el('span', { class: 'entry-icon' }, icon(SOURCE_ICONS[item.source?.kind] || 'file')),
    el('div', { style: { minWidth: 0 } }, [
      el('div', { class: 'entry-title', text: item.title || 'Sans titre' }),
      el('div', { class: 'entry-meta' }, meta),
      live ? el('div', { class: 'entry-progress' }, el('span', { style: { width: `${live.percent || 0}%` } })) : null,
      failed ? el('div', { class: 'entry-meta', style: { color: 'var(--danger)' } }, [interrupted ? 'jetranscrit a été fermé pendant la transcription.' : item.error || 'Échec.', ' ', el('button', { class: 'entry-fix', type: 'button', text: 'Que faire ?', onclick: (event) => (event.stopPropagation(), showProblem(item, interrupted ? 'interrupted' : item.errorCode)) })]) : null,
    ]),
    el('div', { class: 'entry-actions' }, [badge, remove]),
  ]);
  const open = () => {
    if (live) watchJob(item.id, item.title);
    else if (item.status === 'done') openEditor(item.id);
    else if (failed) showProblem(item, interrupted ? 'interrupted' : item.errorCode);
  };
  row.addEventListener('click', open);
  row.addEventListener('keydown', (event) => event.key === 'Enter' && open());
  return row;
};

/* ------------------------------------------------------------------ starting a transcription */

const options = () => ({ language: $('languageSelect').value, speakers: $('speakersSelect').value });
try {
  const saved = JSON.parse(localStorage.getItem('jetranscrit.options') || '{}');
  if (saved.language) $('languageSelect').value = saved.language;
  if (saved.speakers) $('speakersSelect').value = saved.speakers;
} catch {
  /* first time */
}
for (const id of ['languageSelect', 'speakersSelect']) {
  $(id).addEventListener('change', () => {
    try {
      localStorage.setItem('jetranscrit.options', JSON.stringify(options()));
    } catch {
      /* not kept */
    }
  });
}

const start = async (source, title) => {
  try {
    const { id } = await api('/api/transcribe', { method: 'POST', body: { source, title, options: options() } });
    closeSheet();
    watchJob(id, title);
  } catch (error) {
    showError(error);
  }
};

document.querySelectorAll('[data-source]').forEach((button) =>
  button.addEventListener('click', () => {
    const kind = button.dataset.source;
    if (kind === 'capcut') openCapcut();
    else if (kind === 'premiere') openPremiere();
    else if (kind === 'file') pickFile();
    else if (kind === 'link') {
      openSheet('linkSheet');
      $('linkInfo').hidden = true;
      $('linkInput').value = '';
      setTimeout(() => $('linkInput').focus(), 50);
    }
  }),
);

/* files */
const hiddenInput = el('input', { type: 'file', accept: 'video/*,audio/*,.mkv,.mts,.m2ts', hidden: true });
document.body.append(hiddenInput);
hiddenInput.addEventListener('change', () => hiddenInput.files[0] && uploadAndStart(hiddenInput.files[0]));

const pickFile = async () => {
  if (!status.nativeDialogs) return hiddenInput.click();
  try {
    const { file, name } = await api('/api/pick-file', { method: 'POST' });
    if (file) start({ kind: 'file', path: file }, name.replace(/\.[^.]+$/, ''));
  } catch (error) {
    showError(error);
  }
};

const uploadAndStart = (file) =>
  new Promise((resolve) => {
    const request = new XMLHttpRequest();
    request.open('POST', withToken(`/api/upload?name=${encodeURIComponent(file.name)}`));
    request.upload.onprogress = (event) => event.lengthComputable && toast(`Copie de la vidéo… ${Math.round((event.loaded / event.total) * 100)} %`);
    request.onload = () => {
      try {
        const data = JSON.parse(request.responseText);
        if (request.status !== 200) throw new Error(data.error || 'Copie impossible.');
        $('toast').hidden = true;
        start({ kind: 'upload', path: data.path }, file.name.replace(/\.[^.]+$/, ''));
      } catch (error) {
        toast(error.message, 'error');
      }
      resolve();
    };
    request.onerror = () => {
      toast('Copie impossible.', 'error');
      resolve();
    };
    request.send(file);
  });

let dragDepth = 0;
window.addEventListener('dragenter', (event) => {
  if (!event.dataTransfer?.types?.includes('Files') || $('homeView').hidden) return;
  dragDepth += 1;
  $('dropOverlay').hidden = false;
});
window.addEventListener('dragleave', () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth) $('dropOverlay').hidden = true;
});
window.addEventListener('dragover', (event) => event.preventDefault());
window.addEventListener('drop', (event) => {
  event.preventDefault();
  dragDepth = 0;
  $('dropOverlay').hidden = true;
  const file = event.dataTransfer?.files?.[0];
  if (file && !$('homeView').hidden) uploadAndStart(file);
});

/* CapCut */
const openCapcut = async () => {
  openSheet('capcutSheet');
  const grid = $('capcutGrid');
  grid.replaceChildren(el('p', { class: 'pick-empty', text: 'Recherche de tes projets…' }));
  try {
    const { projects, dir } = await api('/api/capcut/projects');
    $('capcutEmpty').hidden = projects.length > 0;
    $('capcutDir').textContent = dir || '(introuvable)';
    $('capcutPickDir').hidden = !status.nativeDialogs;
    $('capcutHint').textContent = projects.length ? 'Le montage est transcrit tel qu’on l’entend : tous les clips audibles, à leur place. Ton projet n’est jamais modifié.' : '';
    grid.replaceChildren(
      ...projects.map((project) =>
        el(
          'button',
          {
            class: 'project',
            type: 'button',
            onclick: () => start({ kind: 'capcut', id: project.id }, project.name),
          },
          [
            el('span', { class: 'project-cover', style: project.hasCover ? { backgroundImage: `url("${withToken(`/api/capcut/cover?id=${encodeURIComponent(project.id)}`)}")` } : {} }, project.hasCover ? null : icon('timeline')),
            el('span', { class: 'project-name', text: project.name }),
            el('span', { class: 'project-meta', text: [duration(project.seconds), when(project.modifiedMs)].filter(Boolean).join(' · ') }),
          ],
        ),
      ),
    );
  } catch (error) {
    grid.replaceChildren(el('p', { class: 'pick-empty', text: error.message }));
  }
};
$('capcutPickDir').addEventListener('click', async () => {
  try {
    const { path } = await api('/api/pick-folder', { method: 'POST' });
    if (!path) return;
    await api('/api/settings', { method: 'POST', body: { capcutDir: path } });
    openCapcut();
  } catch (error) {
    toast(error.message, 'error');
  }
});

/* Premiere Pro */
const showSequences = async (file, button) => {
  document.querySelectorAll('#premiereList button').forEach((b) => b.classList.toggle('on', b === button));
  const list = $('sequenceList');
  list.replaceChildren(el('li', { class: 'pick-empty', text: 'Lecture du projet…' }));
  try {
    const { sequences } = await api(`/api/premiere/sequences?file=${encodeURIComponent(file)}`);
    if (!sequences.length) return list.replaceChildren(el('li', { class: 'pick-empty', text: 'Aucune séquence avec du son dans ce projet.' }));
    list.replaceChildren(
      ...sequences.map((sequence) =>
        el('li', {}, el('button', { type: 'button', onclick: () => start({ kind: 'premiere', file, sequenceId: sequence.id }, sequence.name) }, [el('b', { text: sequence.name }), el('span', { text: `${duration(sequence.seconds)} · ${sequence.clips} clip${sequence.clips > 1 ? 's' : ''} audio` })])),
      ),
    );
  } catch (error) {
    list.replaceChildren(el('li', { class: 'pick-empty', text: error.message }));
  }
};

const openPremiere = async () => {
  openSheet('premiereSheet');
  $('premierePick').hidden = !status.nativeDialogs;
  $('sequenceList').replaceChildren(el('li', { class: 'pick-empty', text: 'Choisis un projet.' }));
  const list = $('premiereList');
  list.replaceChildren(el('li', { class: 'pick-empty', text: 'Recherche de tes projets…' }));
  try {
    const { projects } = await api('/api/premiere/projects');
    if (!projects.length) return list.replaceChildren(el('li', { class: 'pick-empty', text: 'Aucun projet Premiere Pro trouvé. Ouvre-le avec le bouton ci-dessous.' }));
    list.replaceChildren(
      ...projects.map((project) => {
        const button = el('button', { type: 'button' }, [el('b', { text: project.name }), el('span', { text: `${when(project.modifiedMs)} · ${project.folder}` })]);
        button.addEventListener('click', () => showSequences(project.id, button));
        return el('li', {}, button);
      }),
    );
  } catch (error) {
    list.replaceChildren(el('li', { class: 'pick-empty', text: error.message }));
  }
};
$('premierePick').addEventListener('click', async () => {
  const { file } = await api('/api/pick-premiere', { method: 'POST' });
  if (file) showSequences(file, null);
});

/* links */
$('linkForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const url = $('linkInput').value.trim();
  const button = $('linkGo');
  button.disabled = true;
  button.textContent = 'Vérification…';
  try {
    const info = await api('/api/link/info', { method: 'POST', body: { url } });
    $('linkInfo').replaceChildren(el('div', {}, [el('b', { text: info.title }), el('div', { class: 'hint', text: [info.site, duration(info.seconds)].filter(Boolean).join(' · ') })]));
    $('linkInfo').hidden = false;
    await start({ kind: 'link', url }, info.title);
  } catch (error) {
    const problem = problemFor(error.code, error.message);
    $('linkInfo').replaceChildren(el('div', { class: 'link-error' }, [el('b', { text: error.message }), problem ? problem.text : '']));
    setTimeout(() => offerReport(error, { where: 'lien' }), 900);
    $('linkInfo').hidden = false;
  } finally {
    button.disabled = false;
    button.textContent = 'Transcrire';
  }
});

/* ------------------------------------------------------------------ following a transcription */

let watching = null;
const STEPS = ['audio', 'models', 'voices', 'text'];

let failedId = null;
/** The screen shown when a transcription fails: what happened, what to do, try again. */
const showProblem = (item, code) => {
  failedId = item.id;
  const problem = problemFor(code, item.error || '') || { code: null, title: 'La transcription n’a pas abouti', text: 'Relance-la. Si ça recommence, redémarre l’ordinateur, puis écris-moi sur TikTok @justecoqqo avec une capture.' };
  $('problemSource').textContent = item.title || '';
  $('problemTitle').textContent = problem.title;
  // the raw message is only shown when it says more than the title (a file name, an error number…)
  const message = code === 'interrupted' ? '' : item.error || '';
  $('problemMessage').textContent = /[:(]|\d/.test(message) || !problemFor(code, message) ? message : '';
  $('problemFix').textContent = problem.text;
  $('problemHelpBtn').onclick = () => openHelp(problem.code);
  show('progressView');
  $('problemCard').hidden = false;
  if (code !== 'interrupted') setTimeout(() => offerReport({ message: item.error || problem.title, code }, { where: 'transcription' }), 700);
  document.querySelector('.progress-card').hidden = true;
};
$('retryBtn').addEventListener('click', async () => {
  if (!failedId) return;
  try {
    const { id } = await api('/api/retry', { method: 'POST', body: { id: failedId } });
    watchJob(id, $('problemSource').textContent);
  } catch (error) {
    showError(error);
  }
});

const watchJob = (id, title) => {
  watching = id;
  $('problemCard').hidden = true;
  document.querySelector('.progress-card').hidden = false;
  $('progressTitle').textContent = title || '';
  $('livePreview').replaceChildren();
  $('progressBar').style.width = '0%';
  $('progressMeta').textContent = '';
  show('progressView');
  pollJob(id);
};

const pollJob = async (id) => {
  if (watching !== id) return;
  let job;
  try {
    ({ job } = await api(`/api/job?id=${encodeURIComponent(id)}`));
  } catch {
    job = null;
  }
  if (watching !== id) return;
  if (!job) {
    toast('Cette transcription a été interrompue.', 'error');
    return goHome();
  }
  if (job.step === 'done') {
    watching = null;
    return openEditor(id);
  }
  if (job.step === 'cancelled') {
    watching = null;
    return goHome();
  }
  if (job.step === 'error') {
    watching = null;
    return showProblem({ id, title: $('progressTitle').textContent, error: job.label }, job.code);
  }
  $('progressLabel').textContent = job.label;
  $('progressBar').style.width = `${job.percent || 0}%`;
  const currentIndex = STEPS.indexOf(job.step);
  document.querySelectorAll('#progressSteps li').forEach((li) => {
    const index = STEPS.indexOf(li.dataset.step);
    if (li.dataset.step === 'models') li.hidden = !(job.step === 'models' || li.classList.contains('done') || li.classList.contains('on'));
    li.classList.toggle('on', index === currentIndex);
    li.classList.toggle('done', currentIndex > index);
  });
  const meta = [];
  if (job.download?.total) meta.push(`${megabytes(job.download.received)} sur ${megabytes(job.download.total)}`);
  if (job.step === 'text' && Number.isFinite(job.remainingSec) && job.remainingSec > 0) meta.push(`encore environ ${duration(Math.max(10, job.remainingSec))}`);
  if (job.language && job.step === 'text') meta.push(`langue : ${LANGS[job.language] || job.language}`);
  if (job.missing?.length) meta.push(`${job.missing.length} média${job.missing.length > 1 ? 's' : ''} introuvable${job.missing.length > 1 ? 's' : ''} (ignoré${job.missing.length > 1 ? 's' : ''})`);
  $('progressMeta').textContent = job.step === 'queued' ? 'Une autre transcription est en cours : celle-ci démarre juste après.' : meta.join(' · ');
  const preview = job.preview || [];
  const box = $('livePreview');
  const shown = box.dataset.key || '';
  const key = preview.map((p) => p.start).join(',');
  if (key !== shown) {
    box.dataset.key = key;
    box.replaceChildren(...preview.slice(-4).map((p) => el('div', { class: 'live-line' }, [el('span', { class: 'chip', style: { '--voice': voiceColor(p.speaker) }, text: `Voix ${p.speaker + 1}` }), el('span', { text: p.text })])));
  }
  setTimeout(() => pollJob(id), 800);
};

$('cancelJobBtn').addEventListener('click', async () => {
  if (!watching) return;
  await api('/api/cancel', { method: 'POST', body: { id: watching } });
  watching = null;
  goHome();
});

const PALETTE = ['#ff6b4a', '#4a8bff', '#2fbf8f', '#b06bff', '#f2b33d', '#ff5fa2', '#3fc4d9', '#8a9a3c', '#e0703a', '#6d7cff'];
const voiceColor = (id) => current?.speakers.find((s) => s.id === id)?.color || PALETTE[id % PALETTE.length];

/* ------------------------------------------------------------------ editor */

let current = null; // { id, title, speakers, segments, meta }
let hiddenVoices = new Set();
let saveTimer = null;
let dirty = false;

const openEditor = async (id) => {
  try {
    current = await api(`/api/transcription?id=${encodeURIComponent(id)}`);
  } catch (error) {
    toast(error.message, 'error');
    return goHome();
  }
  hiddenVoices = new Set();
  show('editorView');
  $('docTitle').value = current.title;
  const m = current.meta;
  $('docMeta').textContent = [duration(m.seconds), `${current.speakers.length} voix`, m.language ? LANGS[m.language] || m.language : '', m.elapsedMs ? `transcrit en ${duration(m.elapsedMs / 1000)}` : ''].filter(Boolean).join(' · ');
  $('saveState').textContent = '';
  const audio = $('audio');
  audio.src = withToken(`/api/audio?id=${encodeURIComponent(id)}`);
  audio.playbackRate = Number($('speedSelect').value);
  renderVoices();
  renderSegments();
  voiced = [];
  api(`/api/voicing?id=${encodeURIComponent(id)}`).then((r) => (voiced = r.intervals || [])).catch(() => {});
};

const speakerById = (id) => current.speakers.find((s) => s.id === id);

const scheduleSave = () => {
  dirty = true;
  $('saveState').textContent = 'Modifications…';
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 700);
};

const flushSave = async () => {
  clearTimeout(saveTimer);
  if (!dirty || !current) return;
  dirty = false;
  try {
    await api('/api/transcription/save', { method: 'POST', body: { id: current.id, title: current.title, speakers: current.speakers, segments: current.segments } });
    $('saveState').textContent = 'Enregistré';
  } catch (error) {
    dirty = true;
    $('saveState').textContent = 'Pas enregistré';
    toast(error.message, 'error');
  }
};
window.addEventListener('beforeunload', () => {
  if (dirty && current) navigator.sendBeacon?.(withToken('/api/transcription/save'), new Blob([JSON.stringify({ id: current.id, title: current.title, speakers: current.speakers, segments: current.segments })], { type: 'application/json' }));
});

$('docTitle').addEventListener('input', () => {
  current.title = $('docTitle').value;
  scheduleSave();
});

/* voices panel */
const renderVoices = () => {
  const seconds = new Map();
  const counts = new Map();
  for (const s of current.segments) {
    seconds.set(s.speaker, (seconds.get(s.speaker) || 0) + (s.end - s.start));
    counts.set(s.speaker, (counts.get(s.speaker) || 0) + 1);
  }
  $('voicesList').replaceChildren(
    ...current.speakers.map((speaker) => {
      const name = el('input', { class: 'voice-name', value: speaker.name, 'aria-label': 'Nom de la voix', spellcheck: 'false' });
      name.addEventListener('input', () => {
        speaker.name = name.value || `Voix ${speaker.id + 1}`;
        document.querySelectorAll(`.chip[data-voice="${speaker.id}"]`).forEach((chip) => (chip.textContent = speaker.name));
        scheduleSave();
      });
      name.addEventListener('keydown', (event) => event.key === 'Enter' && name.blur());
      const dot = el('button', { class: 'voice-dot', type: 'button', title: 'Changer la couleur', style: { background: speaker.color } });
      dot.addEventListener('click', () => {
        speaker.color = PALETTE[(PALETTE.indexOf(speaker.color) + 1) % PALETTE.length];
        renderVoices();
        renderSegments();
        scheduleSave();
      });
      const more = el('button', { class: 'icon-btn voice-more', type: 'button', 'aria-label': 'Options de la voix' }, icon('more'));
      more.addEventListener('click', (event) => voiceOptions(speaker, event.currentTarget));
      return el('li', { class: `voice${hiddenVoices.has(speaker.id) ? ' hidden-voice' : ''}` }, [
        dot,
        name,
        more,
        el('span', { class: 'voice-stats', text: counts.get(speaker.id) ? `${duration(seconds.get(speaker.id))} de parole` : 'ne parle pas' }),
      ]);
    }),
  );
};

const openMenu = (anchor, items) => {
  const menu = $('voiceMenu');
  menu.replaceChildren(
    ...items.map((item) => {
      if (item === '-') return el('hr');
      if (item.title) return el('div', { class: 'menu-title', text: item.title });
      return el('button', { type: 'button', onclick: () => (closeMenu(), item.action()) }, [item.color ? el('i', { style: { background: item.color } }) : null, item.label]);
    }),
  );
  menu.hidden = false;
  const rect = anchor.getBoundingClientRect();
  const height = menu.offsetHeight;
  const top = rect.bottom + 6 + height > window.innerHeight ? Math.max(8, rect.top - height - 6) : rect.bottom + 6;
  menu.style.top = `${top}px`;
  menu.style.left = `${Math.min(rect.left, window.innerWidth - menu.offsetWidth - 10)}px`;
};
const closeMenu = () => ($('voiceMenu').hidden = true);
document.addEventListener('pointerdown', (event) => {
  if (!$('voiceMenu').hidden && !$('voiceMenu').contains(event.target)) closeMenu();
});

const voiceOptions = (speaker, anchor) => {
  const others = current.speakers.filter((s) => s.id !== speaker.id);
  openMenu(anchor, [
    { label: hiddenVoices.has(speaker.id) ? 'Afficher ses phrases' : 'Masquer ses phrases', action: () => toggleVoice(speaker.id) },
    ...(others.length ? ['-', { title: `Fusionner ${speaker.name} avec` }, ...others.map((o) => ({ label: o.name, color: o.color, action: () => mergeVoices(speaker.id, o.id) }))] : []),
  ]);
};

const toggleVoice = (id) => {
  hiddenVoices.has(id) ? hiddenVoices.delete(id) : hiddenVoices.add(id);
  renderVoices();
  applyFilter();
};

const mergeVoices = (fromId, intoId) => {
  for (const s of current.segments) if (s.speaker === fromId) s.speaker = intoId;
  current.speakers = current.speakers.filter((s) => s.id !== fromId);
  hiddenVoices.delete(fromId);
  renderVoices();
  renderSegments();
  scheduleSave();
  toast(`Les deux voix n'en font plus qu'une : ${speakerById(intoId).name}`);
};

$('addVoiceBtn').addEventListener('click', () => {
  addVoice();
  renderVoices();
  scheduleSave();
});
const addVoice = () => {
  const id = current.speakers.reduce((max, s) => Math.max(max, s.id), -1) + 1;
  const speaker = { id, name: `Voix ${id + 1}`, color: PALETTE[id % PALETTE.length] };
  current.speakers.push(speaker);
  return speaker;
};

/* segments */
const segmentNodes = new Map(); // segment id → row

const renderSegments = () => {
  segmentNodes.clear();
  const rows = current.segments.map((segment, index) => renderSegment(segment, current.segments[index - 1]));
  $('segments').replaceChildren(...rows);
  applyFilter();
};

const renderSegment = (segment, previous) => {
  const speaker = speakerById(segment.speaker) || { name: '?', color: '#999' };
  const time = el('button', { class: 'seg-time', type: 'button', title: 'Écouter à partir d’ici' }, [icon('play'), clock(segment.start)]);
  time.addEventListener('click', () => playFrom(segment.start));
  const chip = el('button', { class: 'chip seg-chip', type: 'button', 'data-voice': segment.speaker, style: { '--voice': speaker.color }, title: 'Changer la voix', text: speaker.name });
  chip.addEventListener('click', (event) => chooseVoice(segment, event.currentTarget));
  const text = el('div', { class: 'seg-text', contenteditable: 'plaintext-only', spellcheck: 'true', lang: current.meta?.language || 'fr' });
  text.textContent = segment.text;
  text.addEventListener('input', () => {
    segment.text = text.textContent;
    scheduleSave();
  });
  text.addEventListener('keydown', (event) => onTextKey(event, segment, text));
  const row = el('div', { class: `seg${previous && previous.speaker === segment.speaker ? ' same-voice' : ''}`, 'data-id': segment.id, style: { '--voice': speaker.color } }, [time, el('div', { class: 'seg-body' }, [chip, text])]);
  segmentNodes.set(segment.id, row);
  return row;
};

const chooseVoice = (segment, anchor) => {
  const index = current.segments.indexOf(segment);
  // the following phrases of the same voice (one "block") can be changed together
  let blockEnd = index;
  while (current.segments[blockEnd + 1]?.speaker === segment.speaker) blockEnd += 1;
  const assign = (speakerId, whole) => {
    for (let i = index; i <= (whole ? blockEnd : index); i++) current.segments[i].speaker = speakerId;
    renderVoices();
    renderSegments();
    scheduleSave();
  };
  const choices = current.speakers.filter((s) => s.id !== segment.speaker);
  openMenu(anchor, [
    { title: blockEnd > index ? 'Cette phrase et les suivantes' : 'Qui parle ici ?' },
    ...choices.map((s) => ({ label: s.name, color: s.color, action: () => assign(s.id, true) })),
    { label: 'Nouvelle voix', action: () => assign(addVoice().id, true) },
    ...(blockEnd > index ? ['-', { title: 'Seulement cette phrase' }, ...choices.map((s) => ({ label: s.name, color: s.color, action: () => assign(s.id, false) }))] : []),
  ]);
};

const caretOffset = (node) => {
  const selection = window.getSelection();
  if (!selection.rangeCount) return 0;
  const range = selection.getRangeAt(0).cloneRange();
  range.selectNodeContents(node);
  range.setEnd(selection.getRangeAt(0).endContainer, selection.getRangeAt(0).endOffset);
  return range.toString().length;
};
const placeCaret = (node, offset) => {
  node.focus();
  const range = document.createRange();
  const textNode = node.firstChild || node;
  range.setStart(textNode, Math.min(offset, textNode.textContent.length));
  range.collapse(true);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
};

const onTextKey = (event, segment, node) => {
  const index = current.segments.indexOf(segment);
  if (event.key === 'Enter' && !event.shiftKey) {
    // cut the phrase in two at the cursor (the time is shared out by the length of the text)
    event.preventDefault();
    const at = caretOffset(node);
    const full = node.textContent;
    const before = full.slice(0, at).trimEnd();
    const after = full.slice(at).trimStart();
    if (!before || !after) return;
    const cut = segment.start + (segment.end - segment.start) * (before.length / full.length);
    const next = { id: `s${Date.now().toString(36)}`, start: Math.round(cut * 100) / 100, end: segment.end, speaker: segment.speaker, text: after };
    segment.text = before;
    segment.end = next.start;
    current.segments.splice(index + 1, 0, next);
    renderSegments();
    scheduleSave();
    placeCaret(segmentNodes.get(next.id).querySelector('.seg-text'), 0);
  } else if (event.key === 'Backspace' && index > 0 && caretOffset(node) === 0 && window.getSelection().isCollapsed) {
    // glue the phrase to the previous one
    event.preventDefault();
    const previous = current.segments[index - 1];
    const join = previous.text.length + (previous.text && segment.text ? 1 : 0);
    previous.text = [previous.text, segment.text].filter(Boolean).join(' ');
    previous.end = Math.max(previous.end, segment.end);
    current.segments.splice(index, 1);
    renderSegments();
    scheduleSave();
    placeCaret(segmentNodes.get(previous.id).querySelector('.seg-text'), join);
  }
};

const applyFilter = () => {
  const query = $('findInput').value.trim().toLowerCase();
  let hits = 0;
  let first = null;
  for (const segment of current.segments) {
    const row = segmentNodes.get(segment.id);
    if (!row) continue;
    row.classList.toggle('filtered', hiddenVoices.has(segment.speaker));
    const hit = query && segment.text.toLowerCase().includes(query);
    if (hit) {
      hits += segment.text.toLowerCase().split(query).length - 1;
      first = first || row;
    }
    row.classList.toggle('found', Boolean(hit));
    row.querySelector('.seg-text').style.background = hit ? 'var(--marker-soft)' : '';
  }
  $('findCount').textContent = query ? String(hits) : '';
  return first;
};
$('findInput').addEventListener('input', () => {
  const first = applyFilter();
  first?.scrollIntoView({ block: 'center', behavior: 'smooth' });
});
$('findInput').addEventListener('keydown', (event) => {
  if (event.key !== 'Enter') return;
  const found = [...document.querySelectorAll('.seg.found')];
  if (!found.length) return;
  const middle = window.innerHeight / 2;
  const next = found.find((row) => row.getBoundingClientRect().top > middle + 10) || found[0];
  next.scrollIntoView({ block: 'center', behavior: 'smooth' });
});
$('replaceAllBtn').addEventListener('click', () => {
  const query = $('findInput').value;
  if (!query.trim()) return toast('Écris d’abord ce que tu cherches.');
  const replacement = $('replaceInput').value;
  const pattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  let count = 0;
  for (const segment of current.segments) {
    segment.text = segment.text.replace(pattern, () => {
      count += 1;
      return replacement;
    });
  }
  renderSegments();
  scheduleSave();
  toast(count ? `${count} remplacement${count > 1 ? 's' : ''}` : 'Rien trouvé');
});

/* playback */
const audio = $('audio');
let activeRow = null;

const stopPlayback = () => {
  audio.pause();
};
const playFrom = (seconds) => {
  audio.currentTime = seconds;
  audio.play().catch(() => {});
};
const togglePlay = () => (audio.paused ? audio.play().catch(() => {}) : audio.pause());
$('playBtn').addEventListener('click', togglePlay);
$('speedSelect').addEventListener('change', () => (audio.playbackRate = Number($('speedSelect').value)));
audio.addEventListener('play', () => $('playBtn').replaceChildren(icon('pause')));
audio.addEventListener('pause', () => $('playBtn').replaceChildren(icon('play')));
$('seekBar').addEventListener('input', () => {
  if (audio.duration) audio.currentTime = (Number($('seekBar').value) / 1000) * audio.duration;
});

const segmentAt = (time) => {
  const list = current?.segments || [];
  let lo = 0;
  let hi = list.length - 1;
  let found = null;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (list[mid].start <= time) {
      found = list[mid];
      lo = mid + 1;
    } else hi = mid - 1;
  }
  return found && time <= found.end + 0.3 ? found : null;
};

audio.addEventListener('timeupdate', () => {
  if (!current) return;
  $('playTime').textContent = `${clock(audio.currentTime)} / ${clock(audio.duration || current.meta?.seconds)}`;
  if (audio.duration) $('seekBar').value = String(Math.round((audio.currentTime / audio.duration) * 1000));
  const segment = segmentAt(audio.currentTime);
  const row = segment ? segmentNodes.get(segment.id) : null;
  if (row === activeRow) return;
  activeRow?.classList.remove('playing');
  activeRow = row;
  if (!row) return;
  row.classList.add('playing');
  const editing = document.activeElement?.classList?.contains('seg-text');
  const rect = row.getBoundingClientRect();
  if (!audio.paused && !editing && (rect.top < 200 || rect.bottom > window.innerHeight - 40)) row.scrollIntoView({ block: 'center', behavior: 'smooth' });
});

/* karaoke: the words already said turn dark, the word being said is highlighted */

let voiced = []; // moments the voice really speaks: [[start, end], …]
const karaokeOn = typeof CSS !== 'undefined' && CSS.highlights && typeof Highlight !== 'undefined';
const timingCache = new Map();

/** When each word of a phrase starts, spread over the moments the voice speaks (pauses skipped). */
const wordTimes = (segment) => {
  const key = `${segment.id}|${segment.start}|${segment.end}|${segment.text}`;
  if (timingCache.get(segment.id)?.key === key) return timingCache.get(segment.id).words;
  const words = [...segment.text.matchAll(/\S+/g)].map((m) => ({ from: m.index, to: m.index + m[0].length, weight: m[0].length + (/[.,!?;:…]$/.test(m[0]) ? 4 : 1) }));
  let spans = voiced.map(([s, e]) => [Math.max(s, segment.start), Math.min(e, segment.end)]).filter(([s, e]) => e - s > 0.04);
  const talking = spans.reduce((sum, [s, e]) => sum + e - s, 0);
  if (talking < (segment.end - segment.start) * 0.3) spans = [[segment.start, segment.end]];
  const total = spans.reduce((sum, [s, e]) => sum + e - s, 0) || 1;
  const weights = words.reduce((sum, w) => sum + w.weight, 0) || 1;
  // a position in "talking time" → a real time on the timeline
  const at = (fraction) => {
    let left = fraction * total;
    for (const [s, e] of spans) {
      if (left <= e - s) return s + left;
      left -= e - s;
    }
    return segment.end;
  };
  let done = 0;
  for (const word of words) {
    word.start = at(done / weights);
    done += word.weight;
    word.end = at(done / weights);
  }
  timingCache.set(segment.id, { key, words });
  return words;
};

const rangeIn = (node, from, to) => {
  const range = document.createRange();
  const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
  let offset = 0;
  let started = false;
  for (let text = walker.nextNode(); text; text = walker.nextNode()) {
    const length = text.textContent.length;
    if (!started && from <= offset + length) {
      range.setStart(text, from - offset);
      started = true;
    }
    if (started && to <= offset + length) {
      range.setEnd(text, to - offset);
      return range;
    }
    offset += length;
  }
  return started ? range : null;
};

let karaokeFrame = 0;
const clearKaraoke = () => {
  if (!karaokeOn) return;
  CSS.highlights.delete('kara-said');
  CSS.highlights.delete('kara-now');
  document.querySelectorAll('.seg.singing').forEach((row) => row.classList.remove('singing'));
};
const karaoke = () => {
  cancelAnimationFrame(karaokeFrame);
  if (!karaokeOn || !current || audio.paused) return;
  const time = audio.currentTime;
  const segment = segmentAt(time);
  const row = segment && segmentNodes.get(segment.id);
  const node = row?.querySelector('.seg-text');
  if (node && document.activeElement !== node) {
    document.querySelectorAll('.seg.singing').forEach((r) => r !== row && r.classList.remove('singing'));
    row.classList.add('singing');
    const words = wordTimes(segment);
    let index = words.findIndex((w) => time < w.end);
    if (index < 0) index = words.length - 1;
    const said = index > 0 ? rangeIn(node, 0, words[index - 1].to) : null;
    const now = words[index] && time >= words[index].start - 0.05 ? rangeIn(node, words[index].from, words[index].to) : null;
    said ? CSS.highlights.set('kara-said', new Highlight(said)) : CSS.highlights.delete('kara-said');
    now ? CSS.highlights.set('kara-now', new Highlight(now)) : CSS.highlights.delete('kara-now');
  } else clearKaraoke();
  karaokeFrame = requestAnimationFrame(karaoke);
};
audio.addEventListener('play', karaoke);
audio.addEventListener('pause', () => cancelAnimationFrame(karaokeFrame));
audio.addEventListener('seeked', () => (audio.paused ? clearKaraoke() : karaoke()));

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && openSheetId) return closeSheet();
  if ($('editorView').hidden) return;
  if ((event.ctrlKey || event.metaKey) && event.code === 'Space') {
    event.preventDefault();
    togglePlay();
  } else if (event.key === 'Escape') {
    if (openSheetId) closeSheet();
    else audio.pause();
  } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'f') {
    event.preventDefault();
    $('findInput').focus();
  } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
    event.preventDefault();
    flushSave();
  }
});

/* ------------------------------------------------------------------ export */

let exportFormat = 'txt';
let exportScope = 'all';

$('exportBtn').addEventListener('click', async () => {
  await flushSave();
  $('exportDone').hidden = true;
  const voices = $('exportVoices');
  voices.replaceChildren(
    ...current.speakers.map((s) =>
      el('li', {}, el('label', {}, [el('input', { type: 'checkbox', value: String(s.id), checked: true }), el('i', { style: { background: s.color } }), s.name])),
    ),
  );
  const single = current.speakers.length < 2;
  $('exportScope').hidden = single;
  $('exportNames').closest('label').hidden = single;
  openSheet('exportSheet');
});

$('exportScope').addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;
  exportScope = button.dataset.scope;
  $('exportScope').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === button));
  $('exportVoices').hidden = exportScope !== 'voices';
});
$('exportFormats').addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;
  exportFormat = button.dataset.format;
  $('exportFormats').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === button));
  const subtitles = exportFormat === 'srt' || exportFormat === 'vtt';
  $('exportTimes').closest('label').hidden = subtitles || exportFormat === 'csv' || exportFormat === 'json';
  $('exportNames').checked = !subtitles;
});

const exportBody = (extra = {}) => ({
  id: current.id,
  format: exportFormat,
  speakers: exportScope === 'voices' ? [...$('exportVoices').querySelectorAll('input:checked')].map((i) => Number(i.value)) : [],
  names: $('exportNames').checked,
  times: $('exportTimes').checked,
  ...extra,
});

const decode = (base64) => Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));

$('exportGo').addEventListener('click', async () => {
  const body = exportBody();
  if (exportScope === 'voices' && !body.speakers.length) return toast('Coche au moins une voix.');
  try {
    const result = await api('/api/export', { method: 'POST', body });
    if (result.content) {
      const url = URL.createObjectURL(new Blob([decode(result.content)], { type: result.mime }));
      const link = el('a', { href: url, download: result.fileName });
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      return;
    }
    if (!result.saved) return;
    const done = $('exportDone');
    const reveal = el('button', { type: 'button', text: 'Afficher dans le dossier' });
    reveal.addEventListener('click', () => api('/api/reveal', { method: 'POST', body: { path: result.path } }));
    done.replaceChildren('Fichier enregistré. ', reveal);
    done.hidden = false;
  } catch (error) {
    toast(error.message, 'error');
  }
});

$('copyTextBtn').addEventListener('click', async () => {
  const body = exportBody({ format: 'txt', inline: true });
  if (exportScope === 'voices' && !body.speakers.length) return toast('Coche au moins une voix.');
  try {
    const result = await api('/api/export', { method: 'POST', body });
    const text = new TextDecoder().decode(decode(result.content)).replace(/^﻿/, '');
    await navigator.clipboard.writeText(text);
    toast('Texte copié');
  } catch (error) {
    toast(error.message || 'Copie impossible', 'error');
  }
});

/* ------------------------------------------------------------------ start */

const init = async () => {
  $('supportLink').href = BRAND.support;
  try {
    status = await api('/api/status');
  } catch {
    status = {};
  }
  setupReports({ app: 'jetranscrit', version: status.version, accent: '#5a46f0', send: (payload) => api('/api/report', { method: 'POST', body: payload }) });
  if (!status.modelsReady && status.modelsDownloadBytes) {
    $('modelsNote').textContent = `La première fois, jetranscrit télécharge son moteur de transcription (${megabytes(status.modelsDownloadBytes)}, une seule fois).`;
    $('modelsNote').hidden = false;
  }
  show('homeView');
  try {
    const { jobs } = await api('/api/jobs');
    const running = jobs.find((job) => job.step !== 'queued');
    if (running) watchJob(running.id, running.title);
  } catch {
    /* nothing running */
  }
};
init();
