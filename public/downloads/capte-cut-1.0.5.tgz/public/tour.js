// Guided tour: a spotlight on one part of the screen at a time, with a short explanation card.

const GAP = 14;

const make = (tag, className, parent) => {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (parent) parent.append(element);
  return element;
};

/**
 * steps: [{ target: selector | null, title, text, placement?: 'auto' | 'center' }]
 * Returns a promise resolved with 'done' or 'skipped'.
 */
export const runTour = (steps, { label = 'Tutoriel' } = {}) =>
  new Promise((resolve) => {
    const layer = make('div', 'tour-layer', document.body);
    const spot = make('div', 'tour-spot', layer);
    const card = make('div', 'tour-card', layer);
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');
    card.setAttribute('aria-label', label);
    const progress = make('div', 'tour-progress', card);
    const title = make('h3', 'tour-title', card);
    const text = make('p', 'tour-text', card);
    const actions = make('div', 'tour-actions', card);
    const skip = make('button', 'tour-skip', actions);
    skip.type = 'button';
    skip.textContent = 'Passer';
    const next = make('button', 'tour-next', actions);
    next.type = 'button';

    let index = 0;
    let target = null;

    const place = () => {
      const step = steps[index];
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const cardRect = card.getBoundingClientRect();
      if (!target || step.placement === 'center') {
        spot.style.opacity = '0';
        layer.classList.add('is-dim');
        card.style.left = `${Math.round((vw - cardRect.width) / 2)}px`;
        card.style.top = `${Math.round((vh - cardRect.height) / 2)}px`;
        return;
      }
      layer.classList.remove('is-dim');
      const r = target.getBoundingClientRect();
      const pad = step.pad ?? 8;
      Object.assign(spot.style, {
        left: `${r.left - pad}px`,
        top: `${r.top - pad}px`,
        width: `${r.width + pad * 2}px`,
        height: `${r.height + pad * 2}px`,
        opacity: '1',
      });
      const fits = {
        right: vw - r.right - pad - GAP >= cardRect.width,
        left: r.left - pad - GAP >= cardRect.width,
        below: vh - r.bottom - pad - GAP >= cardRect.height,
        above: r.top - pad - GAP >= cardRect.height,
      };
      let left;
      let top;
      if (fits.below) {
        top = r.bottom + pad + GAP;
        left = r.left + r.width / 2 - cardRect.width / 2;
      } else if (fits.right) {
        left = r.right + pad + GAP;
        top = r.top + r.height / 2 - cardRect.height / 2;
      } else if (fits.left) {
        left = r.left - pad - GAP - cardRect.width;
        top = r.top + r.height / 2 - cardRect.height / 2;
      } else if (fits.above) {
        top = r.top - pad - GAP - cardRect.height;
        left = r.left + r.width / 2 - cardRect.width / 2;
      } else {
        left = vw - cardRect.width - 24;
        top = vh - cardRect.height - 24;
      }
      card.style.left = `${Math.round(Math.min(Math.max(12, left), vw - cardRect.width - 12))}px`;
      card.style.top = `${Math.round(Math.min(Math.max(12, top), vh - cardRect.height - 12))}px`;
    };

    const show = () => {
      const step = steps[index];
      target = step.target ? document.querySelector(step.target) : null;
      if (target && !target.getClientRects().length) target = null;
      progress.textContent = `${index + 1} sur ${steps.length}`;
      title.textContent = step.title;
      text.textContent = step.text;
      next.textContent = index === steps.length - 1 ? (step.done || 'Terminé') : step.next || 'Suivant';
      skip.hidden = index === steps.length - 1;
      card.classList.remove('is-in');
      if (target) target.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      requestAnimationFrame(() => {
        place();
        card.classList.add('is-in');
        next.focus();
      });
      setTimeout(place, 350);
    };

    const finish = (result) => {
      window.removeEventListener('resize', place);
      window.removeEventListener('scroll', place, true);
      document.removeEventListener('keydown', onKey, true);
      layer.classList.add('is-out');
      setTimeout(() => layer.remove(), 220);
      resolve(result);
    };

    const onKey = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        finish('skipped');
      } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        next.click();
      }
    };

    next.addEventListener('click', () => {
      if (index === steps.length - 1) return finish('done');
      index++;
      show();
    });
    skip.addEventListener('click', () => finish('skipped'));
    window.addEventListener('resize', place);
    window.addEventListener('scroll', place, true);
    document.addEventListener('keydown', onKey, true);
    show();
  });
