import { BRAND } from './brand.js';
import { DEFAULT_SETTINGS, detectSilences, totalDuration } from './silence.js';
import { runTour } from './tour.js';
import { offerReport, setupReports } from './report.js';

const TOKEN = document.querySelector('meta[name="app-token"]').content;
const $ = (id) => document.getElementById(id);
const REDUCED_MOTION = window.matchMedia('(prefers-reduced-motion: reduce)');

// ---- Helpers ------------------------------------------------------------------

const api = async (method, url, body) => {
  const response = await fetch(url, {
    method,
    headers: { 'X-App-Token': TOKEN, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || `Erreur ${response.status}`), { status: response.status, code: data.code });
  return data;
};

const storage = {
  get(key, fallback) {
    try {
      const raw = localStorage.getItem(`captecut.${key}`);
      return raw === null ? fallback : JSON.parse(raw);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(`captecut.${key}`, JSON.stringify(value));
    } catch {
      /* storage is a convenience only */
    }
  },
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const decimal = (value, digits = 1) => value.toFixed(digits).replace('.', ',');
const plural = (n, word, many = `${word}s`) => (n > 1 ? many : word);

const formatDuration = (us) => {
  const seconds = Math.max(0, us) / 1e6;
  if (seconds < 60) return `${decimal(seconds)} s`;
  const totalMinutes = Math.floor(seconds / 60);
  const rest = Math.round(seconds - totalMinutes * 60);
  if (totalMinutes < 60) return rest ? `${totalMinutes} min ${String(rest).padStart(2, '0')} s` : `${totalMinutes} min`;
  return `${Math.floor(totalMinutes / 60)} h ${String(totalMinutes % 60).padStart(2, '0')} min`;
};

const formatClock = (us, withTenths = false) => {
  const totalSeconds = Math.max(0, us) / 1e6;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const tenths = Math.floor((totalSeconds * 10) % 10);
  const base = hours ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}` : `${minutes}:${String(seconds).padStart(2, '0')}`;
  return withTenths ? `${base},${tenths}` : base;
};

const formatDb = (db) => `${String(db).replace('-', '−')} dB`;
const formatMs = (ms) => (ms >= 1000 ? `${decimal(ms / 1000, ms % 1000 ? 2 : 0)} s` : `${ms} ms`);
const formatDate = (ms) => new Date(ms).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

const decodeLevels = (base64) => {
  const binary = atob(base64);
  const levels = new Int8Array(binary.length);
  for (let i = 0; i < binary.length; i++) levels[i] = (binary.charCodeAt(i) << 24) >> 24;
  return levels;
};

const css = getComputedStyle(document.documentElement);
const C = Object.fromEntries(
  ['night', 'deck', 'deck-2', 'deck-3', 'rule', 'text', 'mute', 'faint', 'wave', 'wave-low', 'cut', 'ok', 'clip-video', 'clip-audio', 'clip-text', 'clip-fx', 'clip-sticker'].map((name) => [
    name,
    css.getPropertyValue(`--${name}`).trim(),
  ]),
);
const CLIP_COLORS = { video: C['clip-video'], audio: C['clip-audio'], text: C['clip-text'], effect: C['clip-fx'], filter: C['clip-fx'], adjust: C['clip-fx'], sticker: C['clip-sticker'] };
const withAlpha = (hex, alpha) => {
  const value = parseInt(hex.slice(1), 16);
  return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${alpha})`;
};

/** Removes protected ranges from intervals (both sorted lists of {start, end}). */
const subtractRanges = (intervals, ranges) => {
  if (!ranges.length) return intervals;
  const out = [];
  for (const interval of intervals) {
    let cursor = interval.start;
    for (const range of ranges) {
      if (range.end <= cursor || range.start >= interval.end) continue;
      if (range.start > cursor) out.push({ start: cursor, end: range.start });
      cursor = Math.max(cursor, range.end);
      if (cursor >= interval.end) break;
    }
    if (cursor < interval.end) out.push({ start: cursor, end: interval.end });
  }
  return out;
};

// ---- State ------------------------------------------------------------------

const savedPrefs = storage.get('prefs', {});
const state = {
  status: null,
  projects: [],
  project: null,
  listen: new Set(),
  cut: new Set(),
  settings: { ...DEFAULT_SETTINGS, ...(savedPrefs.settings || {}) },
  thresholdChosen: false,
  mode: savedPrefs.mode === 'split' ? 'split' : 'ripple',
  shiftOthers: savedPrefs.shiftOthers !== false,
  analysis: null,
  intervals: [], // blanks found in the sound
  kept: [], // points (µs) inside blanks the user chose to keep
  cutBlanks: [], // what will really be cut: not kept, not on protected clips
  protectedBlanks: [], // blanks left in place because they fall on clips that cannot be cut
  view: { startUs: 0, zoom: 0 },
  display: 'before',
  squeeze: 0, // 0 = timeline as it is, 1 = timeline after the cut
  analysisRun: 0,
  hover: null,
  busy: false,
};

const savePrefs = () => {
  const { thresholdDb, ...settings } = state.settings;
  storage.set('prefs', { settings, mode: state.mode, shiftOthers: state.shiftOthers });
};

const isKept = (interval) => state.kept.some((p) => p >= interval.start && p < interval.end);

const protectedRanges = () => {
  if (!state.project) return [];
  const ranges = [];
  for (const track of state.project.tracks) {
    if (!state.cut.has(track.id) || !track.canCut) continue;
    for (const [start, end, flags] of track.clips) {
      if (flags & 1 || (flags & 2 && state.listen.has(track.id))) ranges.push({ start, end });
    }
  }
  return ranges.sort((a, b) => a.start - b.start);
};

const refreshBlanks = () => {
  const frameUs = 1e6 / (state.analysis?.fps || 30);
  const wanted = state.intervals.filter((i) => !isKept(i));
  state.cutBlanks = subtractRanges(wanted, protectedRanges()).filter((i) => i.end - i.start >= frameUs);
  state.protectedBlanks = subtractRanges(wanted, state.cutBlanks).filter((i) => i.end - i.start >= frameUs);
  const protectedUs = totalDuration(state.protectedBlanks);
  const warnings = [...(state.analysis?.warnings || [])];
  if (protectedUs > 50_000) warnings.push(`${formatDuration(protectedUs)} de blancs tombent sur des photos ou des clips qui ne se découpent pas : ils sont gardés (en gris).`);
  $('notice').hidden = !warnings.length;
  $('notice').textContent = warnings.join(' ');
};

// ---- Banner, message and dialog ---------------------------------------------------

const showBanner = (html) => {
  offerReport(String(html).replace(/<[^>]+>/g, ''), { where: 'bandeau', quiet: true });
  $('banner').innerHTML = html;
  $('banner').hidden = !html;
};

const setMessage = (text, tone = '') => {
  $('actionMsg').textContent = text;
  $('actionMsg').className = `dock-msg${tone ? ` is-${tone}` : ''}`;
};

const ICONS = {
  waiting: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 9 9"/></svg>',
  done: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  error: '<svg viewBox="0 0 24 24"><path d="M12 7v6M12 17h.01"/><circle cx="12" cy="12" r="9"/></svg>',
  layers: '<svg viewBox="0 0 24 24"><path d="M12 3.5 21 8l-9 4.5L3 8z"/><path d="m3 12.5 9 4.5 9-4.5"/><path d="m3 16.5 9 4.5 9-4.5" opacity=".5"/></svg>',
};

let sheetHandlers = {};
const openSheet = ({ kind, title, text, stats, note, primary = 'OK', secondary, onPrimary, onSecondary, onEscape }) => {
  if (kind === 'error') setTimeout(() => offerReport(`${title} : ${text || ''}`, { where: title }), 600);
  $('sheetNote').hidden = !note;
  $('sheetNote').textContent = note || '';
  $('sheetIcon').className = `sheet-icon is-${kind}`;
  $('sheetIcon').innerHTML = ICONS[kind];
  $('sheetTitle').textContent = title;
  $('sheetText').textContent = text || '';
  $('sheetStats').hidden = !stats;
  $('sheetStats').replaceChildren(
    ...(stats || []).map(([label, value]) => {
      const item = document.createElement('li');
      const a = document.createElement('span');
      const b = document.createElement('span');
      a.textContent = label;
      b.textContent = value;
      item.append(a, b);
      return item;
    }),
  );
  $('sheetPrimary').textContent = primary;
  $('sheetPrimary').hidden = primary === null;
  $('sheetSecondary').hidden = !secondary;
  $('sheetSecondary').textContent = secondary || '';
  sheetHandlers = { onPrimary, onSecondary, onEscape };
  if (!$('sheet').open) $('sheet').showModal();
};
const closeSheet = () => $('sheet').open && $('sheet').close();

$('sheetPrimary').addEventListener('click', () => {
  const handler = sheetHandlers.onPrimary;
  closeSheet();
  handler?.();
});
$('sheetSecondary').addEventListener('click', () => {
  const handler = sheetHandlers.onSecondary;
  closeSheet();
  handler?.();
});
$('sheet').addEventListener('cancel', (event) => {
  event.preventDefault();
  if (sheetHandlers.onEscape) {
    closeSheet();
    return sheetHandlers.onEscape();
  }
  $('sheetSecondary').hidden ? $('sheetPrimary').click() : $('sheetSecondary').click();
});

// ---- Gallery ----------------------------------------------------------------------

setupReports({ app: 'capte-cut', accent: '#ff4f6d', send: (payload) => api('POST', '/api/report', payload) });

const loadStatus = async () => {
  state.status = await api('GET', '/api/status');
  if (!state.status.ffmpeg) {
    showBanner(
      state.status.launcher
        ? `<strong>Le moteur audio est introuvable</strong>, l'outil ne peut pas écouter le son. Ferme ${BRAND.name} et relance-le : le launcher justecoqqo le réinstalle tout seul.`
        : state.status.desktop
        ? `<strong>ffmpeg est introuvable</strong>, l'outil ne peut pas écouter le son. Réinstalle ${BRAND.name} depuis <strong>${BRAND.page}</strong>.`
        : `<strong>ffmpeg est introuvable</strong>, l'outil ne peut pas écouter le son. Relance <strong>Lancer ${BRAND.name}</strong> : il s'installe tout seul. Sinon, installe-le avec <code>winget install ffmpeg</code>.`,
    );
  }
  checkForUpdate(state.status.version);
  $('draftsDirInput').value = state.status.draftsDir || state.status.suggestedDraftsDirs[0] || '';
  $('draftsDirBox').hidden = state.status.draftsDirExists;
};

const projectCard = (project) => {
  const item = document.createElement('li');
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'project-card';
  const cover = document.createElement('span');
  cover.className = `project-cover${project.hasCover ? '' : ' no-cover'}`;
  if (project.hasCover) cover.style.backgroundImage = `url("/api/cover?id=${encodeURIComponent(project.id)}&token=${TOKEN}")`;
  if (project.durationUs) {
    const duration = document.createElement('span');
    duration.className = 'project-duration';
    duration.textContent = formatClock(project.durationUs);
    cover.append(duration);
  }
  if (project.openInCapcut) {
    const flag = document.createElement('span');
    flag.className = 'project-flag';
    flag.textContent = 'Ouvert dans CapCut';
    cover.append(flag);
  }
  const name = document.createElement('span');
  name.className = 'project-name';
  name.textContent = project.name;
  const date = document.createElement('span');
  date.className = 'project-date';
  date.textContent = `Modifié le ${formatDate(project.modifiedMs)}`;
  button.append(cover, name, date);
  button.addEventListener('click', () => openProject(project.id));
  item.append(button);
  return item;
};

const renderProjects = () => {
  const list = $('projectList');
  const query = $('projectSearch').value.trim().toLowerCase();
  const shown = state.projects.filter((p) => !query || p.name.toLowerCase().includes(query));
  $('gallerySub').textContent = state.projects.length
    ? `${state.projects.length} ${plural(state.projects.length, 'projet')} CapCut, du plus récent au plus ancien.`
    : 'Tes projets CapCut, du plus récent au plus ancien.';
  if (!state.projects.length) {
    list.innerHTML = `<li class="project-empty">Aucun projet trouvé dans ce dossier. Indique l'emplacement des brouillons de CapCut ci-dessus.</li>`;
    $('draftsDirBox').hidden = false;
    return;
  }
  if (!shown.length) {
    list.innerHTML = '';
    const empty = document.createElement('li');
    empty.className = 'project-empty';
    empty.textContent = `Aucun projet ne contient « ${$('projectSearch').value.trim()} ».`;
    list.append(empty);
    return;
  }
  list.replaceChildren(...shown.map(projectCard));
};

$('projectSearch').addEventListener('input', renderProjects);

const showChooser = async () => {
  resetListening();
  state.project = null;
  state.analysis = null;
  $('editor').hidden = true;
  $('chooser').hidden = false;
  $('crumbs').hidden = true;
  $('capcutState').hidden = true;
  document.title = BRAND.name;
  try {
    state.projects = (await api('GET', '/api/projects')).projects;
    renderProjects();
  } catch (error) {
    showBanner(error.message);
  }
};

$('draftsDirSave').addEventListener('click', async () => {
  try {
    await api('POST', '/api/settings', { draftsDir: $('draftsDirInput').value });
    await loadStatus();
    await showChooser();
  } catch (error) {
    showBanner(error.message);
  }
});

$('backBtn').addEventListener('click', () => showChooser());
$('homeBtn').addEventListener('click', () => showChooser());

// ---- Project -----------------------------------------------------------------------

const defaultTrackChoice = (tracks) => {
  const main = tracks.find((t) => t.isMain && t.hasAudio) || tracks.find((t) => t.hasAudio);
  return { listen: main ? [main.id] : [], cut: main ? [main.id] : [] };
};

const renderProjectHeader = () => {
  const project = state.project;
  $('crumbs').hidden = false;
  $('crumbProject').textContent = project.name;
  $('projectTitle').textContent = project.name;
  const tracks = project.tracks.length;
  $('projectMeta').textContent = `${formatDuration(project.durationUs)} de montage, ${tracks} ${plural(tracks, 'piste')}`;
  $('undoBtn').hidden = !project.backups;
  $('undoLabel').textContent = project.lastChange === 'ungroup' ? 'Annuler la décomposition' : 'Annuler le dernier cut';
  document.title = `${project.name} – ${BRAND.name}`;
  renderCompoundBar();
};

// ---- Compound clips -------------------------------------------------------------------

const renderCompoundBar = () => {
  const info = state.project?.compounds;
  const show = Boolean(info && info.count);
  $('compoundBar').hidden = !show;
  if (!show) return;
  const n = info.count;
  const what = `<strong>${n} ${plural(n, 'clip composé', 'clips composés')}</strong>`;
  if (info.ready) {
    $('compoundText').innerHTML = `${what} dans ce montage. ${BRAND.name} ${n > 1 ? 'les coupe' : 'le coupe'} tel quel, ou tu peux ${n > 1 ? 'les décomposer' : 'le décomposer'} pour remettre tes clips d'origine sur la timeline.`;
    $('ungroupBtn').hidden = false;
  } else {
    $('compoundText').innerHTML = `${what} dans ce montage, ${BRAND.name} ${n > 1 ? 'les coupe' : 'le coupe'} tel quel. Pour ${n > 1 ? 'les décomposer' : 'le décomposer'}, fais-le dans CapCut (clic droit, « Dissocier ») : ${escapeHtml(info.blocked.join(', '))}.`;
    $('ungroupBtn').hidden = true;
  }
};

const escapeHtml = (text) => String(text).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const ungroup = async ({ force = false } = {}) => {
  state.busy = true;
  updateCutButton();
  $('ungroupBtn').disabled = true;
  setMessage('Décomposition…');
  try {
    const result = await api('POST', '/api/ungroup', { projectId: state.project.id, force });
    // new tracks taken out of a compound clip are listened to and cut like the track it was on
    for (const [trackId, origin] of Object.entries(result.stats.trackOrigins || {})) {
      if (state.listen.has(origin)) state.listen.add(trackId);
      if (state.cut.has(origin)) state.cut.add(trackId);
    }
    state.busy = false;
    setMessage('');
    const { stats } = result;
    const lines = [
      [plural(stats.compounds, 'Clip composé décomposé', 'Clips composés décomposés'), String(stats.compounds)],
      ['Clips remis sur la timeline', String(stats.clipsAdded)],
    ];
    if (stats.newTracks) lines.push(['Nouvelles pistes', String(stats.newTracks)]);
    const lost = stats.lostEdits.length ? ` Non repris : ${stats.lostEdits.join(', ')}.` : '';
    const kept = stats.skipped.length ? ` Gardés tels quels : ${stats.skipped.join(', ')}.` : '';
    openSheet({
      kind: 'done',
      title: plural(stats.compounds, 'Clip composé décomposé', 'Clips composés décomposés'),
      text: `Tes clips sont de nouveau directement sur la timeline : l'analyse est refaite, tu peux lancer le cut. Une sauvegarde a été faite : « Annuler la décomposition » remet le projet comme avant.${lost}${kept}`,
      stats: lines,
    });
    await refreshProject();
  } catch (error) {
    state.busy = false;
    updateCutButton();
    if (error.code === 'open-in-capcut') {
      return whenProjectClosed('Ferme le projet dans CapCut', ungroup, { text: "Reviens à l'accueil de CapCut (flèche en haut à gauche du montage). La décomposition part toute seule dès que le projet est fermé.", doing: 'Projet fermé. Décomposition…', primary: 'Le projet est fermé, décomposer' });
    }
    setMessage(error.message, 'error');
    openSheet({ kind: 'error', title: "Le clip composé n'a pas été décomposé", text: error.message });
  } finally {
    $('ungroupBtn').disabled = false;
  }
};

$('ungroupBtn').addEventListener('click', () => {
  const info = state.project.compounds;
  const n = info.ready;
  const lost = info.lostEdits.length ? ` Attention, ${n > 1 ? 'ces clips composés ont' : 'ce clip composé a'} des réglages qui ne seront pas repris : ${info.lostEdits.join(', ')}.` : '';
  openSheet({
    kind: 'layers',
    title: n > 1 ? `Décomposer les ${n} clips composés ?` : 'Décomposer le clip composé ?',
    text: `${BRAND.name} remet les clips qui sont dedans directement sur ta timeline, comme « Dissocier » dans CapCut. Le zoom, la vitesse, le volume et les effets du clip composé passent sur chaque clip.${lost} Une sauvegarde est faite avant : tu pourras annuler.`,
    primary: 'Décomposer',
    secondary: 'Garder tel quel',
    onPrimary: () => ungroup(),
  });
});

const openProject = async (id) => {
  if (state.status?.ffmpeg) showBanner('');
  try {
    state.project = await api('GET', `/api/project?id=${encodeURIComponent(id)}`);
  } catch (error) {
    showBanner(error.message);
    return;
  }
  const project = state.project;
  const ids = new Set(project.tracks.map((t) => t.id));
  const saved = storage.get(`tracks.${id}`, null);
  const choice = saved && saved.listen.every((t) => ids.has(t)) && saved.cut.every((t) => ids.has(t)) ? saved : defaultTrackChoice(project.tracks);
  state.listen = new Set(choice.listen);
  state.cut = new Set(choice.cut);
  const savedThreshold = storage.get(`threshold.${id}`, null);
  state.thresholdChosen = savedThreshold !== null;
  if (savedThreshold !== null) state.settings.thresholdDb = savedThreshold;
  state.kept = [];
  state.analysis = null;
  state.intervals = [];
  state.cutBlanks = [];
  state.view = { startUs: 0, zoom: 0 };
  $('zoom').value = 0;
  setDisplay('before', { instant: true });

  $('chooser').hidden = true;
  $('editor').hidden = false;
  window.scrollTo(0, 0);
  renderProjectHeader();
  renderLockState(project.openInCapcut);
  renderLanes();
  renderSettings();
  setMessage('');
  runAnalysis();
};

const refreshProject = async () => {
  state.project = await api('GET', `/api/project?id=${encodeURIComponent(state.project.id)}`);
  renderProjectHeader();
  const ids = new Set(state.project.tracks.map((t) => t.id));
  state.listen = new Set([...state.listen].filter((t) => ids.has(t)));
  state.cut = new Set([...state.cut].filter((t) => ids.has(t)));
  state.kept = [];
  // After a cut there is almost no silence left, so an automatic threshold would drift: keep the one used.
  state.thresholdChosen = true;
  setDisplay('before', { instant: true });
  renderLanes();
  await runAnalysis();
};

const renderLockState = (open) => {
  const chip = $('capcutState');
  chip.hidden = false;
  chip.classList.toggle('is-open', open);
  chip.textContent = open ? 'Projet ouvert dans CapCut' : 'Projet fermé dans CapCut';
};

// ---- Lanes (track headers) ----------------------------------------------------------

const RULER_H = 30;
let WAVE_H = 168;
const laneHeight = () => (state.project && state.project.tracks.length > 6 ? 34 : 44);

/** Gives the waveform whatever height is left on screen once the lanes are placed. */
const fitWaveHeight = () => {
  const lanes = state.project ? state.project.tracks.length * laneHeight() : 0;
  const compact = window.innerWidth <= 1080;
  const bar = state.project?.compounds?.count ? 64 : 0;
  const room = window.innerHeight - 60 - 26 - 74 - 112 - RULER_H - lanes - bar;
  WAVE_H = compact ? 160 : clamp(Math.round(room), 150, 340);
};

const laneDetail = (track) => {
  if (!track.canCut) return 'Suit le montage';
  if (track.isMain) return 'Piste principale';
  const name = track.mediaNames[0] || `${track.segmentCount} clips`;
  return track.mediaCount > 1 ? `${name} +${track.mediaCount - 1}` : name;
};

const laneButton = (track, kind) => {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `lane-btn ${kind}`;
  const allowed = kind === 'listen' ? track.hasAudio : track.canCut;
  button.disabled = !allowed;
  const active = state[kind].has(track.id);
  button.setAttribute('aria-pressed', String(active));
  const verb = kind === 'listen' ? 'Écouter' : 'Couper';
  button.title = `${verb} ${track.label}`;
  button.setAttribute('aria-label', `${verb} ${track.label}`);
  button.innerHTML = `<svg aria-hidden="true"><use href="#i-${kind}"/></svg>`;
  button.addEventListener('click', () => {
    state[kind].has(track.id) ? state[kind].delete(track.id) : state[kind].add(track.id);
    button.setAttribute('aria-pressed', String(state[kind].has(track.id)));
    storage.set(`tracks.${state.project.id}`, { listen: [...state.listen], cut: [...state.cut] });
    renderListenSummary();
    if (kind === 'listen') scheduleAnalysis();
    else {
      refreshBlanks();
      renderReadout();
      drawAll();
      updateCutButton();
    }
  });
  return button;
};

const renderListenSummary = () => {
  const listened = state.project.tracks.filter((t) => state.listen.has(t.id));
  $('listenSummary').textContent = !listened.length
    ? 'Aucune piste écoutée'
    : listened.length === 1
      ? `Piste écoutée : ${listened[0].label}`
      : `${listened.length} pistes écoutées ensemble`;
};

const renderLanes = () => {
  fitWaveHeight();
  const box = $('timelineBox');
  box.style.setProperty('--ruler-h', `${RULER_H}px`);
  box.style.setProperty('--wave-h', `${WAVE_H}px`);
  box.style.setProperty('--lane-h', `${laneHeight()}px`);
  const heads = state.project.tracks.map((track) => {
    const head = document.createElement('div');
    head.className = 'tl-head lane-head';
    const swatch = document.createElement('span');
    swatch.className = 'lane-swatch';
    swatch.style.background = CLIP_COLORS[track.type] || C.faint;
    const name = document.createElement('span');
    name.className = 'lane-name';
    const strong = document.createElement('strong');
    strong.textContent = track.label;
    const small = document.createElement('small');
    small.textContent = laneDetail(track);
    small.title = track.mediaNames.join(', ');
    name.append(strong, small);
    head.append(swatch, name, laneButton(track, 'listen'), laneButton(track, 'cut'));
    return head;
  });
  $('laneHeads').replaceChildren(...heads);
  $('timeline').style.height = `${RULER_H + WAVE_H + state.project.tracks.length * laneHeight()}px`;
  $('tlView').style.height = $('timeline').style.height;
  renderListenSummary();
};

// ---- Analysis -----------------------------------------------------------------------

let analysisTimer;
const scheduleAnalysis = () => {
  clearTimeout(analysisTimer);
  analysisTimer = setTimeout(runAnalysis, 350);
};

const showTimelineMessage = (text) => {
  $('tlEmpty').hidden = !text;
  $('analysisProgress').hidden = true;
  $('tlEmptyText').hidden = !text;
  $('tlEmptyText').textContent = text || '';
};

const runAnalysis = async () => {
  const run = ++state.analysisRun;
  resetListening();
  state.analysis = null;
  state.intervals = [];
  state.cutBlanks = [];
  setDisplay('before', { instant: true });
  renderReadout();
  drawAll();
  drawHistogram();
  if (!state.listen.size) {
    showTimelineMessage('Active l’écoute (casque) sur au moins une piste pour chercher les blancs.');
    updateCutButton();
    return;
  }
  $('tlEmpty').hidden = false;
  $('tlEmptyText').hidden = true;
  $('analysisProgress').hidden = false;
  $('analysisBar').style.width = '4%';
  $('analysisText').textContent = 'Lecture du son…';
  updateCutButton();
  try {
    const { jobId } = await api('POST', '/api/analyze', { projectId: state.project.id, listenTrackIds: [...state.listen] });
    let job;
    for (;;) {
      await sleep(400);
      if (run !== state.analysisRun) return;
      job = await api('GET', `/api/job?id=${jobId}`);
      if (job.status !== 'running') break;
      const { done, total } = job.progress || {};
      if (total) {
        $('analysisBar').style.width = `${Math.max(4, (done / total) * 100)}%`;
        $('analysisText').textContent = done < total ? `Lecture du son, fichier ${Math.min(done + 1, total)} sur ${total}` : 'Assemblage de la timeline…';
      }
    }
    if (run !== state.analysisRun) return;
    if (job.status === 'error') throw new Error(job.error);
    const result = job.result;
    state.analysis = { ...result, levels: decodeLevels(result.levels) };
    state.histogram = buildHistogram(state.analysis.levels);
    if (!state.thresholdChosen) state.settings.thresholdDb = result.suggestedThresholdDb;
    $('tlEmpty').hidden = true;
    renderSettings();
    recompute();
    prepareListening();
    setTimeout(maybeEditorTour, 450);
  } catch (error) {
    if (run !== state.analysisRun) return;
    showTimelineMessage(error.message);
    setMessage(error.message, 'error');
    offerReport(error, { where: 'analyse du projet' });
  }
};

const recompute = () => {
  if (!state.analysis) return;
  state.intervals = detectSilences(state.analysis, state.settings);
  refreshBlanks();
  renderReadout();
  drawAll();
  drawHistogram();
  updateCutButton();
};

const renderReadout = () => {
  const duration = state.analysis?.durationUs ?? state.project?.durationUs ?? 0;
  const ready = Boolean(state.analysis);
  const removed = totalDuration(state.cutBlanks);
  const split = state.mode === 'split';
  $('savingValue').textContent = ready ? `${split || !removed ? '' : '−'}${formatDuration(removed)}` : '—';
  $('savingValue').classList.toggle('is-zero', ready && !removed);
  $('savingLabel').textContent = split ? 'de blancs isolés' : 'en moins';
  $('blankCount').textContent = ready ? String(state.cutBlanks.length) : '—';
  $('blankWord').textContent = plural(state.cutBlanks.length, 'blanc');
  $('durationBefore').textContent = duration ? formatDuration(duration) : '—';
  $('durationAfter').textContent = ready ? formatDuration(split ? duration : duration - removed) : '—';
  $('viewAfter').closest('.view-switch').classList.toggle('is-disabled', !ready || !state.cutBlanks.length);
};

// ---- Settings ------------------------------------------------------------------------

const SLIDERS = [
  { id: 'threshold', key: 'thresholdDb', format: formatDb },
  { id: 'minSilence', key: 'minSilenceMs', format: formatMs },
  { id: 'keepAfter', key: 'keepAfterSpeechMs', format: formatMs },
  { id: 'keepBefore', key: 'keepBeforeSpeechMs', format: formatMs },
  { id: 'ignoreNoise', key: 'ignoreNoiseMs', format: formatMs },
];

const paintRange = (input) => {
  const ratio = (Number(input.value) - Number(input.min)) / (Number(input.max) - Number(input.min));
  input.style.setProperty('--fill', `${ratio * 100}%`);
};

const renderMargins = () => {
  const width = (ms) => `${Math.round(6 + Math.min(ms, 1000) * 0.08)}px`;
  $('padAfter').style.width = width(state.settings.keepAfterSpeechMs);
  $('padBefore').style.width = width(state.settings.keepBeforeSpeechMs);
};

const renderSettings = () => {
  for (const { id, key, format } of SLIDERS) {
    $(id).value = state.settings[key];
    $(`${id}Out`).textContent = format(state.settings[key]);
    paintRange($(id));
  }
  document.querySelector(`input[name="mode"][value="${state.mode}"]`).checked = true;
  $('shiftOthers').checked = state.shiftOthers;
  $('shiftOthersRow').hidden = state.mode === 'split';
  $('viewAfter').textContent = state.mode === 'split' ? 'Coupes' : 'Après le cut';
  renderMargins();
};

const setThreshold = (db, chosen = true) => {
  state.settings.thresholdDb = clamp(Math.round(db), Number($('threshold').min), Number($('threshold').max));
  state.thresholdChosen = chosen;
  if (state.project) storage.set(`threshold.${state.project.id}`, chosen ? state.settings.thresholdDb : null);
  renderSettings();
  recompute();
};

for (const { id, key, format } of SLIDERS) {
  $(id).addEventListener('input', () => {
    if (key === 'thresholdDb') return setThreshold(Number($(id).value));
    state.settings[key] = Number($(id).value);
    $(`${id}Out`).textContent = format(state.settings[key]);
    paintRange($(id));
    renderMargins();
    savePrefs();
    recompute();
  });
}

$('autoThreshold').addEventListener('click', () => {
  if (state.analysis) setThreshold(state.analysis.suggestedThresholdDb, false);
});

for (const radio of document.querySelectorAll('input[name="mode"]')) {
  radio.addEventListener('change', () => {
    state.mode = radio.value;
    savePrefs();
    renderSettings();
    renderReadout();
    setDisplay(state.display, { instant: true });
    updateCutButton();
  });
}

$('shiftOthers').addEventListener('change', () => {
  state.shiftOthers = $('shiftOthers').checked;
  savePrefs();
  drawAll();
});

// ---- Threshold histogram ------------------------------------------------------------

const HIST_MIN = -64;
const buildHistogram = (levels) => {
  const counts = new Float64Array(-HIST_MIN + 1);
  for (let i = 0; i < levels.length; i++) {
    if (levels[i] <= -100) continue;
    counts[clamp(levels[i], HIST_MIN, 0) - HIST_MIN]++;
  }
  return counts;
};

const histogram = $('histogram');
const drawHistogram = () => {
  const { context: c, width, height } = canvasSize(histogram);
  c.clearRect(0, 0, width, height);
  const counts = state.histogram;
  const min = Number($('threshold').min);
  const max = Number($('threshold').max);
  // The histogram spans the slider range so the threshold line sits right above the thumb.
  const xOf = (db) => 8 + ((db - min) / (max - min)) * (width - 16);
  if (counts && state.analysis) {
    const peak = Math.max(...counts.slice(min - HIST_MIN));
    const bar = (width - 16) / (max - min + 1);
    for (let db = min; db <= max; db++) {
      const value = db === min ? counts.slice(0, min - HIST_MIN + 1).reduce((a, b) => a + b, 0) : counts[db - HIST_MIN];
      if (!value) continue;
      const h = Math.max(2, (Math.log1p(value) / Math.log1p(peak || 1)) * (height - 6));
      c.fillStyle = db < state.settings.thresholdDb ? C['wave-low'] : C.wave;
      c.beginPath();
      c.roundRect(xOf(db) - bar / 2 + 0.5, height - h, Math.max(1, bar - 1.5), h, 2);
      c.fill();
    }
  } else {
    c.fillStyle = C['deck-2'];
    c.fillRect(8, height - 3, width - 16, 3);
  }
  const x = Math.round(xOf(state.settings.thresholdDb)) + 0.5;
  c.strokeStyle = C.cut;
  c.lineWidth = 2;
  c.beginPath();
  c.moveTo(x, 0);
  c.lineTo(x, height);
  c.stroke();
};

const thresholdFromHistogram = (event) => {
  const rect = histogram.getBoundingClientRect();
  const min = Number($('threshold').min);
  const max = Number($('threshold').max);
  setThreshold(min + ((event.clientX - rect.left - 8) / (rect.width - 16)) * (max - min));
};
histogram.addEventListener('pointerdown', (event) => {
  histogram.setPointerCapture(event.pointerId);
  thresholdFromHistogram(event);
  const move = (e) => thresholdFromHistogram(e);
  histogram.addEventListener('pointermove', move);
  histogram.addEventListener('pointerup', () => histogram.removeEventListener('pointermove', move), { once: true });
});

// ---- Before / after view ---------------------------------------------------------------

let squeezeAnimation = null;
const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

const setDisplay = (display, { instant = false } = {}) => {
  state.display = display;
  const after = display === 'after';
  $('viewBefore').setAttribute('aria-checked', String(!after));
  $('viewAfter').setAttribute('aria-checked', String(after));
  $('viewAfter').closest('.view-switch').classList.toggle('is-after', after);
  const target = after && state.mode === 'ripple' ? 1 : 0;
  return animateSqueeze(target, instant);
};

/** Animates the timeline between "as it is" (0) and "after the cut" (1), keeping the centre of the view in place. */
const animateSqueeze = (target, instant) =>
  new Promise((resolve) => {
    if (squeezeAnimation) cancelAnimationFrame(squeezeAnimation);
    const from = state.squeeze;
    const width = timelineCanvas.clientWidth || 1;
    const anchor = buildSqueeze(from).fromDisplay(state.view.startUs + (usPerPx() * width) / 2);
    const place = () => {
      state.view.startUs = buildSqueeze(state.squeeze).toDisplay(anchor) - (usPerPx() * width) / 2;
      drawAll();
    };
    if (instant || REDUCED_MOTION.matches || from === target) {
      state.squeeze = target;
      place();
      return resolve();
    }
    const started = performance.now();
    const duration = 700;
    const step = (now) => {
      const t = Math.min(1, (now - started) / duration);
      state.squeeze = from + (target - from) * easeInOut(t);
      place();
      if (t < 1) squeezeAnimation = requestAnimationFrame(step);
      else {
        squeezeAnimation = null;
        resolve();
      }
    };
    squeezeAnimation = requestAnimationFrame(step);
  });

$('viewBefore').addEventListener('click', () => setDisplay('before'));
$('viewAfter').addEventListener('click', () => setDisplay('after'));

/** Time mapping between the original timeline and the displayed one, with blanks shrunk by factor p. */
const buildSqueeze = (p) => {
  const blanks = p > 0 ? state.cutBlanks : [];
  const n = blanks.length;
  const shownStart = new Float64Array(n);
  const shownEnd = new Float64Array(n);
  const removedBefore = new Float64Array(n);
  let removed = 0;
  for (let i = 0; i < n; i++) {
    const length = blanks[i].end - blanks[i].start;
    removedBefore[i] = removed;
    shownStart[i] = blanks[i].start - p * removed;
    shownEnd[i] = blanks[i].end - p * (removed + length);
    removed += length;
  }
  const lastAtOrBefore = (values, t) => {
    let lo = 0;
    let hi = n;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (values(mid) <= t) lo = mid + 1;
      else hi = mid;
    }
    return lo - 1;
  };
  const toDisplay = (t) => {
    const i = lastAtOrBefore((k) => blanks[k].start, t);
    if (i < 0) return t;
    const b = blanks[i];
    if (t < b.end) return shownStart[i] + (t - b.start) * (1 - p);
    return t - p * (removedBefore[i] + (b.end - b.start));
  };
  const fromDisplay = (u) => {
    const i = lastAtOrBefore((k) => shownStart[k], u);
    if (i < 0) return u;
    const b = blanks[i];
    if (u < shownEnd[i]) return b.start + (u - shownStart[i]) / (1 - p);
    return u + p * (removedBefore[i] + (b.end - b.start));
  };
  const total = (state.analysis?.durationUs || state.project?.durationUs || 0) - p * removed;
  return { toDisplay, fromDisplay, duration: Math.max(1, total), p };
};

// ---- Timeline drawing ------------------------------------------------------------------

const timelineCanvas = $('timeline');
const overview = $('overview');
const MIN_US_PER_PX = 2500; // 400 px per second at full zoom
const FLOOR_DB = -60;

const canvasSize = (canvas) => {
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
  }
  const context = canvas.getContext('2d');
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { context, width, height };
};

const displayDuration = () => buildSqueeze(state.squeeze).duration;

const usPerPx = () => {
  const width = timelineCanvas.clientWidth || 1;
  const fit = displayDuration() / width;
  const min = Math.min(MIN_US_PER_PX, fit);
  return fit * Math.pow(min / fit, state.view.zoom / 1000);
};

const clampView = () => {
  const visible = usPerPx() * timelineCanvas.clientWidth;
  state.view.startUs = clamp(state.view.startUs, 0, Math.max(0, displayDuration() - visible));
};

const amplitude = (db) => clamp((db - FLOOR_DB) / -FLOOR_DB, 0, 1);

const patterns = new WeakMap();
const hatch = (context, color, background) => {
  const key = `${color}|${background}`;
  let byKey = patterns.get(context);
  if (!byKey) patterns.set(context, (byKey = new Map()));
  if (!byKey.has(key)) {
    const tile = document.createElement('canvas');
    tile.width = tile.height = 10;
    const t = tile.getContext('2d');
    t.fillStyle = background;
    t.fillRect(0, 0, 10, 10);
    t.strokeStyle = color;
    t.lineWidth = 2.5;
    t.beginPath();
    for (const offset of [-10, 0, 10]) {
      t.moveTo(offset, 10);
      t.lineTo(offset + 10, 0);
    }
    t.stroke();
    byKey.set(key, context.createPattern(tile, 'repeat'));
  }
  return byKey.get(key);
};

const peakBetween = (levels, binUs, fromUs, toUs) => {
  let first = Math.max(0, Math.floor(fromUs / binUs));
  const last = Math.max(first + 1, Math.ceil(toUs / binUs));
  let peak = -100;
  for (; first < last && first < levels.length; first++) if (levels[first] > peak) peak = levels[first];
  return peak;
};

/** Peak and average level (dB) of the bins between two times; average ignores bins with no sound at all. */
const levelsBetween = (levels, binUs, fromUs, toUs) => {
  let first = Math.max(0, Math.floor(fromUs / binUs));
  const last = Math.max(first + 1, Math.ceil(toUs / binUs));
  let peak = -100;
  let sum = 0;
  let count = 0;
  for (; first < last && first < levels.length; first++) {
    const v = levels[first];
    if (v > peak) peak = v;
    if (v > -100) {
      sum += v;
      count++;
    }
  }
  return { peak, mean: count ? sum / count : -100 };
};

const tickStep = (pxPerSecond) => [0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600].find((s) => s * pxPerSecond >= 84) || 3600;

const drawRuler = (c, width, startUs, scale) => {
  c.fillStyle = C.deck;
  c.fillRect(0, 0, width, RULER_H);
  const step = tickStep(1e6 / scale);
  c.font = '500 11.5px Figtree, system-ui, sans-serif';
  c.textBaseline = 'middle';
  c.strokeStyle = C.rule;
  c.fillStyle = C.mute;
  c.lineWidth = 1;
  c.beginPath();
  const minor = step / 5;
  for (let t = Math.floor(startUs / 1e6 / minor) * minor; t * 1e6 <= startUs + width * scale; t += minor) {
    const x = Math.round((t * 1e6 - startUs) / scale) + 0.5;
    const major = Math.abs(t / step - Math.round(t / step)) < 1e-6;
    c.moveTo(x, major ? RULER_H - 11 : RULER_H - 5);
    c.lineTo(x, RULER_H);
    if (major) c.fillText(formatClock(t * 1e6, step < 1), x + 5, RULER_H / 2 - 2);
  }
  c.moveTo(0, RULER_H - 0.5);
  c.lineTo(width, RULER_H - 0.5);
  c.stroke();
};

/** Where each clip of a lane is drawn, following what the cut will do to that lane. */
const laneMapper = (track, squeeze) => {
  const isCut = state.cut.has(track.id) && track.canCut;
  const follows = state.mode === 'ripple' && (isCut || state.shiftOthers);
  if (!follows) return { start: (t) => t, end: (t) => t, isCut };
  if (isCut || !track.canCut) return { start: squeeze.toDisplay, end: squeeze.toDisplay, isCut };
  return { start: squeeze.toDisplay, end: (t, start) => squeeze.toDisplay(start) + (t - start), isCut };
};

const drawLanes = (c, width, startUs, scale, squeeze, top) => {
  const laneH = laneHeight();
  state.project.tracks.forEach((track, index) => {
    const y = top + index * laneH;
    c.fillStyle = index % 2 ? 'rgba(255, 255, 255, 0.012)' : 'rgba(255, 255, 255, 0.028)';
    c.fillRect(0, y, width, laneH);
    const color = CLIP_COLORS[track.type] || C.faint;
    const map = laneMapper(track, squeeze);
    const active = map.isCut || state.listen.has(track.id);
    const clips = track.clips;
    for (let k = 0; k < clips.length; k++) {
      const [start, end, flags] = clips[k];
      const s = map.start(start);
      let e = map.end(end, start);
      const next = clips[k + 1];
      if (next && !map.isCut) e = Math.min(e, map.start(next[0]));
      const x0 = (s - startUs) / scale;
      const x1 = (e - startUs) / scale;
      if (x1 < -2 || x0 > width + 2 || x1 - x0 < 0.4) continue;
      const pad = laneH > 40 ? 7 : 5;
      c.beginPath();
      c.roundRect(x0 + 0.5, y + pad, Math.max(1, x1 - x0 - 1), laneH - pad * 2, 4);
      c.fillStyle = withAlpha(color, active ? 0.42 : 0.2);
      c.fill();
      c.lineWidth = 1;
      c.setLineDash(flags & 1 ? [3, 3] : []);
      c.strokeStyle = withAlpha(color, active ? 0.95 : 0.45);
      c.stroke();
      c.setLineDash([]);
      if (x1 - x0 > 6) {
        c.fillStyle = withAlpha(color, active ? 1 : 0.5);
        c.fillRect(x0 + 1.5, y + pad + 1, 2.5, laneH - pad * 2 - 2);
      }
    }
    // Cut marks: where the clip pieces will join (ripple) or be split (split).
    if (map.isCut && state.display === 'after' && state.cutBlanks.length) {
      c.fillStyle = C.night;
      for (const blank of state.cutBlanks) {
        const marks = state.mode === 'split' ? [blank.start, blank.end] : [blank.start];
        for (const t of marks) {
          const x = (squeeze.toDisplay(t) - startUs) / scale;
          if (x < -2 || x > width + 2) continue;
          c.fillRect(Math.round(x) - 1, y + 4, 2, laneH - 8);
        }
      }
    }
  });
};

const drawBlanks = (c, width, height, startUs, scale, squeeze, waveTop, laneTop) => {
  const p = squeeze.p;
  const laneH = laneHeight();
  const cutLanes = state.project.tracks.map((t, i) => (state.cut.has(t.id) && t.canCut ? i : -1)).filter((i) => i >= 0);
  const xOf = (t) => (squeeze.toDisplay(t) - startUs) / scale;

  // Blanks the user keeps, and blanks left on clips that cannot be cut (photos, speed curves...).
  for (const interval of state.intervals) {
    if (!isKept(interval)) continue;
    const x0 = xOf(interval.start);
    const x1 = xOf(interval.end);
    if (x1 < 0 || x0 > width) continue;
    c.setLineDash([4, 4]);
    c.lineWidth = 1.5;
    c.strokeStyle = state.hover === interval ? C.text : 'rgba(238, 241, 251, 0.55)';
    c.strokeRect(x0 + 0.75, waveTop + 6.75, Math.max(1, x1 - x0) - 1.5, WAVE_H - 13.5);
    c.setLineDash([]);
  }
  c.fillStyle = hatch(c, 'rgba(142, 150, 184, 0.3)', 'rgba(142, 150, 184, 0.07)');
  for (const blank of state.protectedBlanks) {
    const x0 = xOf(blank.start);
    const x1 = xOf(blank.end);
    if (x1 < 0 || x0 > width) continue;
    c.fillRect(x0, waveTop + 6, Math.max(1, x1 - x0), WAVE_H - 12);
  }

  const alpha = 1 - p;
  if (alpha <= 0.01) return;
  c.globalAlpha = alpha;
  const red = hatch(c, 'rgba(255, 79, 109, 0.55)', 'rgba(255, 79, 109, 0.16)');
  for (const blank of state.cutBlanks) {
    const x0 = xOf(blank.start);
    const x1 = xOf(blank.end);
    if (x1 < 0 || x0 > width) continue;
    const w = Math.max(1, x1 - x0);
    const hovered = state.hover && blank.start >= state.hover.start && blank.end <= state.hover.end;
    c.fillStyle = red;
    c.fillRect(x0, waveTop + 6, w, WAVE_H - 12);
    for (const lane of cutLanes) c.fillRect(x0, laneTop + lane * laneH + 3, w, laneH - 6);
    c.fillStyle = C.cut;
    c.fillRect(x0, waveTop + 6, w, 2);
    c.fillRect(x0, waveTop + WAVE_H - 8, w, 2);
    if (hovered) {
      c.strokeStyle = C.cut;
      c.lineWidth = 1.5;
      c.strokeRect(x0 + 0.75, waveTop + 6.75, w - 1.5, WAVE_H - 13.5);
    }
  }
  c.globalAlpha = 1;
};

const drawTimeline = () => {
  if (!state.project) return;
  const { context: c, width, height } = canvasSize(timelineCanvas);
  c.clearRect(0, 0, width, height);
  const squeeze = buildSqueeze(state.squeeze);
  clampView();
  const scale = usPerPx();
  const startUs = state.view.startUs;
  const waveTop = RULER_H;
  const laneTop = RULER_H + WAVE_H;

  c.fillStyle = 'rgba(8, 10, 20, 0.35)';
  c.fillRect(0, waveTop, width, WAVE_H);
  drawLanes(c, width, startUs, scale, squeeze, laneTop);

  const analysis = state.analysis;
  if (analysis) {
    const mid = waveTop + WAVE_H / 2;
    const half = WAVE_H / 2 - 14;
    const threshold = state.settings.thresholdDb;
    const loudEdge = withAlpha(C.wave, 0.38);
    const quietEdge = withAlpha(C['wave-low'], 0.7);
    for (let x = 0; x < width; x++) {
      const t0 = squeeze.fromDisplay(startUs + x * scale);
      const t1 = squeeze.fromDisplay(startUs + (x + 1) * scale);
      const { peak, mean } = levelsBetween(analysis.levels, analysis.binUs, t0, t1);
      if (peak <= -100) continue;
      const loud = peak >= threshold;
      const outer = Math.max(1, amplitude(peak) * half);
      const inner = Math.max(1, Math.min(outer, amplitude(mean + 4) * half));
      c.fillStyle = loud ? loudEdge : quietEdge;
      c.fillRect(x, mid - outer, 1, outer * 2);
      c.fillStyle = loud ? C.wave : C['wave-low'];
      c.fillRect(x, mid - inner, 1, inner * 2);
    }
    drawBlanks(c, width, height, startUs, scale, squeeze, waveTop, laneTop);

    const ty = Math.round(amplitude(threshold) * half);
    c.strokeStyle = 'rgba(255, 79, 109, 0.75)';
    c.lineWidth = 1;
    c.setLineDash([3, 4]);
    c.beginPath();
    c.moveTo(0, mid - ty + 0.5);
    c.lineTo(width, mid - ty + 0.5);
    c.moveTo(0, mid + ty + 0.5);
    c.lineTo(width, mid + ty + 0.5);
    c.stroke();
    c.setLineDash([]);
  }

  drawRuler(c, width, startUs, scale);
  c.fillStyle = C.rule;
  c.fillRect(0, laneTop, width, 1);

  if (hoverX !== null) {
    c.fillStyle = 'rgba(238, 241, 251, 0.5)';
    c.fillRect(Math.round(hoverX), RULER_H, 1, height - RULER_H);
  }

  // the playhead
  if (listening.shown) {
    const x = Math.round((squeeze.toDisplay(listening.us) - startUs) / scale);
    if (x >= -8 && x <= width + 8) {
      c.fillStyle = C.ok;
      c.fillRect(x - 1, 4, 2, height - 4);
      c.beginPath();
      c.moveTo(x - 7, 4);
      c.lineTo(x + 7, 4);
      c.lineTo(x, 13);
      c.closePath();
      c.fill();
    }
  }
};

const drawOverview = () => {
  const { context: c, width, height } = canvasSize(overview);
  c.clearRect(0, 0, width, height);
  const analysis = state.analysis;
  if (!analysis) return;
  const squeeze = buildSqueeze(state.squeeze);
  const scale = squeeze.duration / width;
  const mid = height / 2;
  c.fillStyle = C['wave-low'];
  for (let x = 0; x < width; x++) {
    const peak = peakBetween(analysis.levels, analysis.binUs, squeeze.fromDisplay(x * scale), squeeze.fromDisplay((x + 1) * scale));
    if (peak <= -100) continue;
    const h = Math.max(1, amplitude(peak) * (mid - 6));
    c.fillRect(x, mid - h, 1, h * 2);
  }
  c.globalAlpha = 1 - squeeze.p;
  c.fillStyle = C.cut;
  for (const blank of state.cutBlanks) {
    const x0 = squeeze.toDisplay(blank.start) / scale;
    c.fillRect(x0, height - 6, Math.max(1, (squeeze.toDisplay(blank.end) - squeeze.toDisplay(blank.start)) / scale), 3);
  }
  c.globalAlpha = 1;
  if (listening.shown) {
    c.fillStyle = C.ok;
    c.fillRect(Math.round(squeeze.toDisplay(listening.us) / scale) - 1, 2, 2, height - 4);
  }
  const visibleStart = state.view.startUs / scale;
  const visibleWidth = Math.max(6, (usPerPx() * timelineCanvas.clientWidth) / scale);
  if (visibleWidth < width - 2) {
    c.fillStyle = 'rgba(238, 241, 251, 0.08)';
    c.fillRect(visibleStart, 0, visibleWidth, height);
    c.strokeStyle = C.text;
    c.lineWidth = 1.5;
    c.beginPath();
    c.roundRect(visibleStart + 0.75, 1, Math.min(width - 1.5, visibleWidth - 1.5), height - 2, 5);
    c.stroke();
  }
};

let frameRequested = false;
const drawAll = () => {
  if (frameRequested) return;
  frameRequested = true;
  requestAnimationFrame(() => {
    frameRequested = false;
    drawTimeline();
    drawOverview();
  });
};

window.addEventListener('resize', () => {
  if (state.project && !$('editor').hidden) renderLanes();
  drawAll();
  drawHistogram();
});

// ---- Timeline interactions --------------------------------------------------------------

let hoverX = null;

const timeAt = (clientX) => {
  const rect = timelineCanvas.getBoundingClientRect();
  const u = state.view.startUs + (clientX - rect.left) * usPerPx();
  return { u, t: buildSqueeze(state.squeeze).fromDisplay(u) };
};

const intervalAt = (t) => state.intervals.find((i) => t >= i.start && t < i.end) || null;
const canEditBlanks = () => state.squeeze === 0;

const setZoom = (zoom, anchorClientX) => {
  const rect = timelineCanvas.getBoundingClientRect();
  const anchorX = anchorClientX === undefined ? rect.width / 2 : anchorClientX - rect.left;
  const anchorUs = state.view.startUs + anchorX * usPerPx();
  state.view.zoom = clamp(zoom, 0, 1000);
  state.view.startUs = anchorUs - anchorX * usPerPx();
  $('zoom').value = state.view.zoom;
  paintRange($('zoom'));
  drawAll();
};

$('zoom').addEventListener('input', () => setZoom(Number($('zoom').value)));

timelineCanvas.addEventListener(
  'wheel',
  (event) => {
    if (!state.analysis) return;
    event.preventDefault();
    if (event.ctrlKey || event.metaKey) return setZoom(state.view.zoom - event.deltaY * 0.6, event.clientX);
    const delta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
    state.view.startUs += delta * usPerPx();
    drawAll();
  },
  { passive: false },
);

let drag = null;
timelineCanvas.addEventListener('pointerdown', (event) => {
  if (!state.analysis) return;
  drag = { x: event.clientX, startUs: state.view.startUs, moved: false };
  timelineCanvas.setPointerCapture(event.pointerId);
});

timelineCanvas.addEventListener('pointermove', (event) => {
  if (!state.analysis) return;
  const rect = timelineCanvas.getBoundingClientRect();
  if (drag) {
    const dx = event.clientX - drag.x;
    if (Math.abs(dx) > 4) drag.moved = true;
    if (drag.moved) {
      state.view.startUs = drag.startUs - dx * usPerPx();
      $('tlTooltip').hidden = true;
      hoverX = null;
      drawAll();
      return;
    }
  }
  hoverX = event.clientX - rect.left;
  const { u, t } = timeAt(event.clientX);
  const interval = canEditBlanks() && event.clientY - rect.top >= RULER_H ? intervalAt(t) : null;
  state.hover = interval;
  const tooltip = $('tlTooltip');
  tooltip.hidden = false;
  const onRuler = event.clientY - rect.top < RULER_H;
  if (!interval || onRuler) tooltip.textContent = `${formatClock(t, true)} · clic pour écouter`;
  else if (isKept(interval)) tooltip.textContent = `Blanc gardé, clic pour le couper`;
  else if (!state.cutBlanks.some((b) => b.start < interval.end && b.end > interval.start)) tooltip.textContent = 'Sur un clip protégé, gardé';
  else tooltip.textContent = `Blanc de ${decimal((interval.end - interval.start) / 1e6, 2)} s, clic pour le garder`;
  tooltip.style.left = `${clamp(hoverX + 12, 6, rect.width - tooltip.offsetWidth - 6)}px`;
  drawAll();
});

timelineCanvas.addEventListener('pointerleave', () => {
  $('tlTooltip').hidden = true;
  state.hover = null;
  hoverX = null;
  drawAll();
});

timelineCanvas.addEventListener('pointerup', (event) => {
  const wasDrag = drag?.moved;
  drag = null;
  if (wasDrag || !state.analysis) return;
  const { t } = timeAt(event.clientX);
  const onRuler = event.clientY - timelineCanvas.getBoundingClientRect().top < RULER_H;
  const interval = canEditBlanks() && !onRuler ? intervalAt(t) : null;
  // a click outside a blank (or on the time ruler) plays from there
  if (!interval) return playFrom(t);
  const inside = (p) => p >= interval.start && p < interval.end;
  state.kept = state.kept.some(inside) ? state.kept.filter((p) => !inside(p)) : [...state.kept, Math.floor((interval.start + interval.end) / 2)];
  refreshBlanks();
  renderReadout();
  drawAll();
  updateCutButton();
});

const moveOverviewTo = (event) => {
  if (!state.analysis) return;
  const rect = overview.getBoundingClientRect();
  const u = ((event.clientX - rect.left) / rect.width) * displayDuration();
  state.view.startUs = u - (usPerPx() * timelineCanvas.clientWidth) / 2;
  drawAll();
};
overview.addEventListener('pointerdown', (event) => {
  overview.setPointerCapture(event.pointerId);
  moveOverviewTo(event);
  const move = (e) => moveOverviewTo(e);
  overview.addEventListener('pointermove', move);
  overview.addEventListener('pointerup', () => overview.removeEventListener('pointermove', move), { once: true });
});

// ---- Listening ------------------------------------------------------------------------
// The server mixes the listened tracks along the timeline; the player can skip the blanks that
// will be cut, to hear the result (and check that no word loses its start) before cutting.

const player = new Audio();
player.preload = 'auto';
const listening = { run: 0, ready: false, preparing: false, playing: false, shown: false, us: 0, frame: 0 };

const renderTransport = () => {
  const button = $('playBtn');
  button.disabled = !listening.ready;
  button.classList.toggle('is-playing', listening.playing);
  button.classList.toggle('is-preparing', listening.preparing);
  const label = listening.preparing ? 'Préparation du son…' : listening.playing ? 'Pause (Espace)' : 'Écouter (Espace)';
  button.setAttribute('aria-label', label);
  button.title = label;
  $('playTime').textContent = formatClock(listening.us, true);
};

const stopTicking = () => {
  cancelAnimationFrame(listening.frame);
  listening.frame = 0;
};

const pausePlayback = () => {
  player.pause();
  listening.playing = false;
  stopTicking();
  renderTransport();
  drawAll();
};

const resetListening = () => {
  listening.run++;
  pausePlayback();
  listening.ready = false;
  listening.preparing = false;
  listening.shown = false;
  listening.us = 0;
  player.removeAttribute('src');
  player.load();
  renderTransport();
};

const prepareListening = async () => {
  const run = ++listening.run;
  listening.ready = false;
  listening.preparing = true;
  renderTransport();
  try {
    const { jobId } = await api('POST', '/api/preview', { projectId: state.project.id, listenTrackIds: state.analysis.listenTrackIds });
    let job;
    for (;;) {
      await sleep(300);
      if (run !== listening.run) return;
      job = await api('GET', `/api/job?id=${jobId}`);
      if (job.status !== 'running') break;
    }
    if (job.status === 'error') throw new Error(job.error);
    player.src = `/api/preview-audio?key=${encodeURIComponent(job.result.key)}&token=${encodeURIComponent(TOKEN)}`;
    listening.ready = true;
  } catch {
    /* listening is a bonus: the cut works without it */
  } finally {
    if (run === listening.run) {
      listening.preparing = false;
      renderTransport();
    }
  }
};

/** The blank that will be cut at time t, if any. */
const cutBlankAt = (t) => {
  const blanks = state.cutBlanks;
  let lo = 0;
  let hi = blanks.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (blanks[mid].end <= t) lo = mid + 1;
    else if (blanks[mid].start > t) hi = mid - 1;
    else return blanks[mid];
  }
  return null;
};
const skipping = () => $('skipBlanks').checked || state.squeeze > 0;

/** Keeps the playhead in view while it plays. */
const followPlayhead = () => {
  const width = timelineCanvas.clientWidth || 1;
  const scale = usPerPx();
  const x = (buildSqueeze(state.squeeze).toDisplay(listening.us) - state.view.startUs) / scale;
  if (x > width * 0.9 || x < 0) state.view.startUs = buildSqueeze(state.squeeze).toDisplay(listening.us) - width * scale * 0.1;
};

const tick = () => {
  if (!listening.playing) return;
  let t = player.currentTime * 1e6;
  const blank = skipping() ? cutBlankAt(t) : null;
  if (blank) {
    player.currentTime = blank.end / 1e6;
    t = blank.end;
  }
  listening.us = t;
  followPlayhead();
  $('playTime').textContent = formatClock(t, true);
  drawAll();
  listening.frame = requestAnimationFrame(tick);
};

const playFrom = async (us) => {
  if (!listening.ready) return;
  const end = state.analysis?.durationUs || 0;
  let t = clamp(us ?? listening.us, 0, Math.max(0, end - 1));
  const blank = skipping() ? cutBlankAt(t) : null;
  if (blank) t = blank.end;
  listening.us = t;
  listening.shown = true;
  player.currentTime = t / 1e6;
  try {
    await player.play();
  } catch {
    return;
  }
  listening.playing = true;
  stopTicking();
  listening.frame = requestAnimationFrame(tick);
  renderTransport();
};

const togglePlayback = () => {
  if (listening.playing) return pausePlayback();
  const end = state.analysis?.durationUs || 0;
  return playFrom(listening.us >= end - 50_000 ? 0 : listening.us);
};

player.addEventListener('ended', () => {
  listening.playing = false;
  stopTicking();
  renderTransport();
  drawAll();
});
player.addEventListener('pause', () => {
  if (!listening.playing) return;
  listening.playing = false;
  stopTicking();
  renderTransport();
});

$('playBtn').addEventListener('click', () => togglePlayback());
$('skipBlanks').addEventListener('change', () => storage.set('skipBlanks', $('skipBlanks').checked));
$('skipBlanks').checked = storage.get('skipBlanks', true);

document.addEventListener('keydown', (event) => {
  if (event.code !== 'Space' || event.repeat || event.ctrlKey || event.metaKey || event.altKey) return;
  if ($('editor').hidden || $('sheet').open || !listening.ready) return;
  const target = event.target;
  if (target.closest?.('textarea, select, [contenteditable="true"]')) return;
  if (target.matches?.('input') && !['checkbox', 'radio', 'range', 'button'].includes(target.type)) return;
  event.preventDefault();
  togglePlayback();
});

// ---- Cut and undo -----------------------------------------------------------------------

const updateCutButton = () => {
  const ready = Boolean(state.analysis) && state.cutBlanks.length > 0 && state.cut.size > 0 && !state.busy;
  $('cutBtn').disabled = !ready;
  if (!state.analysis || state.busy) return;
  const main = state.project.tracks.find((t) => t.isMain && t.segmentCount);
  if (!state.cut.size) setMessage('Active les ciseaux sur au moins une piste à couper.', 'warning');
  else if (state.mode === 'ripple' && main && !state.cut.has(main.id)) {
    setMessage("La piste principale n'est pas coupée : la vidéo ne suivra pas les coupes du son.", 'warning');
  } else if (!state.cutBlanks.length) setMessage('Aucun blanc à couper avec ces réglages.');
  else setMessage('');
};

/** Waits until CapCut has closed the project (its .locked file disappears), then runs the action. */
const whenProjectClosed = (title, action, wording = {}) =>
  new Promise((resolve) => {
    let cancelled = false;
    openSheet({
      kind: 'waiting',
      title,
      text: wording.text || "Reviens à l'accueil de CapCut (flèche en haut à gauche du montage). Le cut part tout seul dès que le projet est fermé.",
      primary: wording.primary || 'Le projet est fermé, appliquer',
      secondary: 'Annuler',
      onPrimary: () => {
        cancelled = true;
        resolve(action({ force: true }));
      },
      onSecondary: () => {
        cancelled = true;
        resolve(null);
      },
    });
    (async () => {
      for (;;) {
        await sleep(700);
        if (cancelled) return;
        try {
          const { openInCapcut } = await api('GET', `/api/lock?id=${encodeURIComponent(state.project.id)}`);
          renderLockState(openInCapcut);
          if (!openInCapcut) break;
        } catch {
          /* keep waiting */
        }
      }
      $('sheetText').textContent = wording.doing || 'Projet fermé. Application du cut…';
      await sleep(1500); // let CapCut finish its last save
      if (cancelled) return;
      cancelled = true;
      closeSheet();
      resolve(action({}));
    })();
  });

const launchCut = async ({ force = false } = {}) => {
  state.busy = true;
  updateCutButton();
  setMessage('Application du cut…');
  try {
    const result = await api('POST', '/api/apply', {
      projectId: state.project.id,
      fingerprint: state.analysis.fingerprint,
      intervals: state.cutBlanks,
      cutTrackIds: [...state.cut],
      listenTrackIds: state.analysis.listenTrackIds,
      mode: state.mode,
      shiftOthers: state.shiftOthers,
      force,
    });
    state.busy = false;
    setMessage('');
    if (result.summary.mode === 'ripple') await setDisplay('after');
    showCutDone(result);
    await refreshProject();
  } catch (error) {
    state.busy = false;
    updateCutButton();
    if (error.code === 'open-in-capcut') return whenProjectClosed('Ferme le projet dans CapCut', launchCut);
    if (error.code === 'changed') {
      openSheet({
        kind: 'error',
        title: 'Le projet a changé dans CapCut',
        text: "Il a été modifié depuis l'analyse. L'analyse est refaite : vérifie les blancs puis relance le cut.",
      });
      await refreshProject();
      return;
    }
    setMessage(error.message, 'error');
    openSheet({ kind: 'error', title: "Le cut n'a pas été appliqué", text: error.message });
  }
};

const showCutDone = ({ stats, summary }) => {
  const ripple = summary.mode === 'ripple';
  const lines = [
    ['Blancs traités', String(summary.blanks)],
    [ripple ? 'Temps supprimé' : 'Blancs isolés', formatDuration(summary.removedUs)],
    ['Durée finale', formatDuration(stats.durationAfter)],
    ['Clips dans les pistes coupées', `${stats.segmentsBefore} avant, ${stats.segmentsAfter} après`],
  ];
  if (stats.othersShifted) lines.push(['Éléments recalés sur les autres pistes', String(stats.othersShifted)]);
  if (stats.othersTrimmed) lines.push(['Clips raccourcis pour rester calés', String(stats.othersTrimmed)]);
  if (stats.othersRemoved) lines.push(['Éléments retirés (entièrement dans un blanc)', String(stats.othersRemoved)]);
  const untouched = stats.skippedUs
    ? ` ${formatDuration(stats.skippedUs)} de blancs ont été gardés sur des clips qui ne se découpent pas (${stats.untouched.join(', ')}).`
    : '';
  openSheet({
    kind: 'done',
    title: 'Cut appliqué',
    text: `Rouvre le projet dans CapCut pour voir le résultat. Une sauvegarde a été faite : « Annuler le dernier cut » remet le projet comme avant.${untouched}`,
    stats: lines,
    note: `${BRAND.name} est gratuit. S'il t'a fait gagner du temps, un petit don aide à le garder à jour.`,
    secondary: 'Soutenir le projet',
    onSecondary: () => window.open(BRAND.support, '_blank', 'noopener'),
    onEscape: () => {},
  });
};

$('cutBtn').addEventListener('click', () => launchCut());

const undoLastCut = async ({ force = false } = {}) => {
  try {
    const result = await api('POST', '/api/undo', { projectId: state.project.id, force });
    const remaining = result.remaining;
    const ungrouped = result.restored?.mode === 'ungroup';
    openSheet({
      kind: 'done',
      title: ungrouped ? 'Décomposition annulée' : 'Cut annulé',
      text: `Le projet est revenu à son état d'avant ${ungrouped ? 'la décomposition' : 'le dernier cut'}. Rouvre-le dans CapCut.${remaining ? ` Il reste ${remaining} ${plural(remaining, 'sauvegarde plus ancienne', 'sauvegardes plus anciennes')}.` : ''}`,
    });
    await refreshProject();
  } catch (error) {
    if (error.code === 'open-in-capcut') return whenProjectClosed('Ferme le projet pour annuler', undoLastCut);
    openSheet({ kind: 'error', title: "Impossible d'annuler", text: error.message });
  }
};

$('undoBtn').addEventListener('click', () => {
  const ungrouped = state.project.lastChange === 'ungroup';
  const what = ungrouped ? 'la décomposition' : 'le dernier cut';
  openSheet({
    kind: 'error',
    title: ungrouped ? 'Annuler la décomposition ?' : 'Annuler le dernier cut ?',
    text: `Le projet revient exactement à son état d'avant ${what}. Les modifications faites dans CapCut depuis seront perdues.`,
    primary: ungrouped ? 'Annuler la décomposition' : 'Annuler le cut',
    secondary: 'Garder',
    onPrimary: () => undoLastCut(),
  });
});

// ---- Lock polling -------------------------------------------------------------------------

setInterval(async () => {
  if (!state.project || $('sheet').open || document.hidden) return;
  try {
    const { openInCapcut } = await api('GET', `/api/lock?id=${encodeURIComponent(state.project.id)}`);
    renderLockState(openInCapcut);
  } catch {
    /* the server may be restarting */
  }
}, 3000);

// ---- Brand and updates ------------------------------------------------------------------

for (const element of document.querySelectorAll('[data-brand="name"]')) element.textContent = BRAND.name;
$('supportLink').href = BRAND.support;
$('tutorialsLink').href = `${BRAND.page}#tutos`;

// ---- Help menu and guided tour -----------------------------------------------------------

const setHelpOpen = (open) => {
  $('helpMenu').hidden = !open;
  $('helpBtn').setAttribute('aria-expanded', String(open));
};
$('helpBtn').addEventListener('click', (event) => {
  event.stopPropagation();
  setHelpOpen($('helpMenu').hidden);
});
document.addEventListener('click', (event) => {
  if (!$('helpMenu').hidden && !$('helpMenu').contains(event.target)) setHelpOpen(false);
});
$('tutorialsLink').addEventListener('click', () => setHelpOpen(false));

const GALLERY_TOUR = [
  {
    target: null,
    title: `Bienvenue dans ${BRAND.name}`,
    text: "30 secondes pour comprendre l'essentiel. Tu pourras revoir ce tutoriel à tout moment depuis le bouton Aide.",
    next: 'Commencer',
  },
  {
    target: '#projectList',
    title: 'Tes projets CapCut',
    text: "Capte Cut les retrouve tout seul, du plus récent au plus ancien. Clique sur celui que tu veux nettoyer : la suite du tutoriel t'attend dedans.",
    done: 'Compris',
  },
];

const EDITOR_TOUR = [
  {
    target: '#timelineBox',
    title: 'Ta timeline',
    text: 'En haut, le son analysé. En rouge, les blancs qui seront coupés, sur toutes les pistes coupées. Clique sur un blanc pour le garder.',
  },
  {
    target: '#laneHeads .lane-head:first-child',
    title: 'Casque et ciseaux',
    text: "Le casque choisit la piste dont le son est écouté. Les ciseaux, les pistes coupées aux mêmes endroits pour rester synchro.",
  },
  {
    target: '#histogram',
    pad: 12,
    title: 'Le seuil de silence',
    text: "Ce relief, c'est ton son : bruit de fond à gauche, voix à droite. Sous le trait rouge, c'est du blanc. Auto le place pour toi.",
  },
  {
    target: '.margins',
    pad: 12,
    title: 'La respiration',
    text: 'Le petit blanc gardé après une phrase et avant la suivante, pour que ton montage ne sonne pas haché.',
  },
  {
    target: '.view-switch',
    title: 'Avant / Après',
    text: 'Vois ta timeline resserrée avant de toucher à ton projet.',
  },
  {
    target: '.cut-dock',
    title: 'Lance le cut',
    text: "Le compteur montre le temps gagné. Ton projet est sauvegardé avant chaque cut, et « Annuler le dernier cut » le remet comme avant.",
  },
  {
    target: '#supportLink',
    title: 'Gratuit, pour de vrai',
    text: `${BRAND.name} est gratuit et le restera. Si tu veux soutenir le projet, c'est ici. Bon montage !`,
    done: "C'est parti",
  },
];

let touring = false;
const tour = async (steps, flag) => {
  if (touring) return;
  touring = true;
  await runTour(steps, { label: `Tutoriel ${BRAND.name}` });
  storage.set(flag, true);
  touring = false;
};

const maybeGalleryTour = () => {
  if (!storage.get('tour.gallery', false)) tour(GALLERY_TOUR, 'tour.gallery');
};
const maybeEditorTour = () => {
  if (!storage.get('tour.editor', false) && !$('sheet').open) tour(EDITOR_TOUR, 'tour.editor');
};

$('replayTour').addEventListener('click', () => {
  setHelpOpen(false);
  if (!$('editor').hidden && state.analysis) tour(EDITOR_TOUR, 'tour.editor');
  else tour(GALLERY_TOUR, 'tour.gallery');
});

const newer = (a, b) => {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};

/** Tells the user when a newer version is published on the site (CapCut updates may require one). */
const checkForUpdate = async (current) => {
  try {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 5000);
    const feed = await (await fetch(BRAND.versionFeed, { signal: controller.signal, cache: 'no-store' })).json();
    if (!feed.version || !newer(feed.version, current)) return;
    const note = feed.note ? ` : ${feed.note}` : '.';
    if (state.status?.launcher) {
      // the justecoqqo launcher installs it by itself at the next start
      $('updateText').textContent = `${BRAND.name} ${feed.version} est disponible${note} Ferme et relance ${BRAND.name} pour l'installer.`;
      $('updateLink').textContent = 'Nouveautés';
    } else {
      $('updateText').textContent = `${BRAND.name} ${feed.version} est disponible${note}`;
    }
    if (feed.url) $('updateLink').href = feed.url;
    $('updateBanner').hidden = false;
  } catch {
    /* offline or site not published yet */
  }
};

// ---- Boot --------------------------------------------------------------------------------

paintRange($('zoom'));
(async () => {
  try {
    await loadStatus();
  } catch (error) {
    showBanner(`L'outil ne répond pas : ${error.message}`);
    return;
  }
  await showChooser();
  maybeGalleryTour();
})();
