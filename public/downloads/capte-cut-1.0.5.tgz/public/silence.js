// Silence detection shared by the browser (live preview) and the server (validation, tests).

export const DEFAULT_SETTINGS = Object.freeze({
  thresholdDb: -38,
  minSilenceMs: 400,
  keepAfterSpeechMs: 150, // blank kept right after someone stops talking
  keepBeforeSpeechMs: 120, // blank kept right before someone starts talking again
  ignoreNoiseMs: 60, // sounds shorter than this inside a blank (click, breath) do not break it
});

const US_PER_MS = 1000;
const NO_CONTENT_DB = -100;

/** CapCut places clips on frame boundaries rounded down: frame k starts at floor(k * 1e6 / fps). */
export const frameStartUs = (frame, fps) => Math.floor((frame * 1_000_000) / fps);
// Exact on CapCut's grid: a time that already is a frame start maps to that frame.
const firstFrameAtOrAfter = (us, fps) => {
  const k = Math.round((us * fps) / 1_000_000);
  return frameStartUs(k, fps) >= us ? k : k + 1;
};
const lastFrameAtOrBefore = (us, fps) => {
  const k = Math.round((us * fps) / 1_000_000);
  return frameStartUs(k, fps) <= us ? k : k - 1;
};

const markSilentBins = (levels, thresholdDb) => {
  const silent = new Uint8Array(levels.length);
  for (let i = 0; i < levels.length; i++) silent[i] = levels[i] < thresholdDb ? 1 : 0;
  return silent;
};

const absorbShortNoises = (silent, maxBins) => {
  if (maxBins <= 0) return;
  let i = 0;
  while (i < silent.length) {
    if (silent[i]) {
      i++;
      continue;
    }
    let j = i;
    while (j < silent.length && !silent[j]) j++;
    const boundedBySilence = i > 0 && j < silent.length;
    if (boundedBySilence && j - i <= maxBins) silent.fill(1, i, j);
    i = j;
  }
};

const silentRuns = (silent) => {
  const runs = [];
  let i = 0;
  while (i < silent.length) {
    if (!silent[i]) {
      i++;
      continue;
    }
    let j = i;
    while (j < silent.length && silent[j]) j++;
    runs.push([i, j]);
    i = j;
  }
  return runs;
};

/**
 * Returns the blanks to remove as [{start, end}] in microseconds, frame-aligned and in order.
 * Blanks at the very start or end of the timeline are removed entirely (there is no speech to pad).
 */
export const detectSilences = ({ levels, binUs, durationUs, fps }, settings = DEFAULT_SETTINGS) => {
  const s = { ...DEFAULT_SETTINGS, ...settings };
  const silent = markSilentBins(levels, s.thresholdDb);
  absorbShortNoises(silent, Math.round((s.ignoreNoiseMs * US_PER_MS) / binUs));

  const intervals = [];
  for (const [a, b] of silentRuns(silent)) {
    const rawStart = a * binUs;
    const rawEnd = Math.min(b * binUs, durationUs);
    if (rawEnd - rawStart < s.minSilenceMs * US_PER_MS) continue;
    const atTimelineStart = rawStart === 0;
    const atTimelineEnd = rawEnd >= durationUs;
    const start = atTimelineStart ? 0 : rawStart + s.keepAfterSpeechMs * US_PER_MS;
    const end = atTimelineEnd ? durationUs : rawEnd - s.keepBeforeSpeechMs * US_PER_MS;
    const startFrame = firstFrameAtOrAfter(start, fps);
    const endFrame = lastFrameAtOrBefore(end, fps);
    if (endFrame - startFrame < 1 && !atTimelineEnd) continue;
    const startUs = atTimelineStart ? 0 : frameStartUs(startFrame, fps);
    const endUs = atTimelineEnd ? durationUs : frameStartUs(endFrame, fps);
    if (endUs > startUs) intervals.push({ start: startUs, end: endUs });
  }
  return intervals;
};

/** Suggests a threshold between the noise floor and the speech level of the timeline. */
export const suggestThreshold = (levels) => {
  const histogram = new Uint32Array(101);
  let total = 0;
  for (let i = 0; i < levels.length; i++) {
    if (levels[i] <= NO_CONTENT_DB) continue;
    histogram[-levels[i]]++;
    total++;
  }
  if (!total) return DEFAULT_SETTINGS.thresholdDb;
  const percentile = (p) => {
    let seen = 0;
    for (let db = 100; db >= 0; db--) {
      seen += histogram[db];
      if (seen >= total * p) return -db;
    }
    return 0;
  };
  const noise = percentile(0.1);
  const speech = percentile(0.85);
  // Stay well under the voice even when there is little silence to measure the noise floor from.
  const threshold = Math.min(Math.round(noise + Math.max(6, (speech - noise) * 0.35)), speech - 18);
  return Math.max(-58, Math.min(-30, threshold));
};

export const totalDuration = (intervals) => intervals.reduce((sum, i) => sum + (i.end - i.start), 0);

/** Validates intervals coming from the browser before they touch a project. */
export const sanitizeIntervals = (intervals, durationUs) => {
  if (!Array.isArray(intervals)) throw new Error('Liste des blancs invalide.');
  const clean = intervals
    .map((i) => ({ start: Math.round(Number(i.start)), end: Math.round(Number(i.end)) }))
    .filter((i) => Number.isFinite(i.start) && Number.isFinite(i.end) && i.end > i.start)
    .map((i) => ({ start: Math.max(0, i.start), end: Math.min(durationUs, i.end) }))
    .filter((i) => i.end > i.start)
    .sort((a, b) => a.start - b.start);
  const merged = [];
  for (const interval of clean) {
    const last = merged[merged.length - 1];
    if (last && interval.start <= last.end) last.end = Math.max(last.end, interval.end);
    else merged.push({ ...interval });
  }
  return merged;
};

/** Puts interval edges on CapCut's frame grid (shrinking them, never cutting into speech). */
export const alignToFrames = (intervals, fps, durationUs) =>
  intervals
    .map(({ start, end }) => ({
      start: start <= 0 ? 0 : frameStartUs(firstFrameAtOrAfter(start, fps), fps),
      end: end >= durationUs ? durationUs : frameStartUs(lastFrameAtOrBefore(end, fps), fps),
    }))
    .filter((i) => i.end > i.start);
