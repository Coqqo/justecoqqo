// The only place where the name and the links of the tool are written.
export const BRAND = Object.freeze({
  name: 'Capte Cut',
  tagline: 'Supprime les blancs de tes montages CapCut',
  site: 'https://justecoqqo.fr',
  page: 'https://justecoqqo.fr/capte-cut/',
  tutorials: 'https://justecoqqo.fr/capte-cut/tutos/',
  // The donation page lives on the site, so the donation link can change without a new version of the app.
  support: 'https://justecoqqo.fr/soutenir/',
  versionFeed: 'https://justecoqqo.fr/capte-cut/version.json',
  dataFolder: 'CapteCut',
});
