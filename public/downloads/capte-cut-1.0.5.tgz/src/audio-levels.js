import { spawn, spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { appDataDir } from './paths.js';

export const BIN_US = 10_000; // one level per 10 ms
const SAMPLE_RATE = 16_000;
const SAMPLES_PER_BIN = (SAMPLE_RATE * BIN_US) / 1_000_000;
const SILENT_DB = -100;
const CACHE_VERSION = 1;
const MAX_PARALLEL_DECODES = 2;

const locateOnPath = (command) => {
  const finder = process.platform === 'win32' ? 'where' : 'which';
  const result = spawnSync(finder, [command], { encoding: 'utf8' });
  if (result.status !== 0) return null;
  return result.stdout.split(/\r?\n/).map((line) => line.trim()).find((line) => line && fs.existsSync(line)) || null;
};

const bundledFfmpeg = () => {
  try {
    const require = createRequire(import.meta.url);
    const binary = require('ffmpeg-static');
    return binary && fs.existsSync(binary) ? binary : null;
  } catch {
    return null;
  }
};

const KNOWN_LOCATIONS = [
  'C:\\ffmpeg\\bin\\ffmpeg.exe',
  'C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe',
  '/opt/homebrew/bin/ffmpeg',
  '/usr/local/bin/ffmpeg',
  '/usr/bin/ffmpeg',
];

let ffmpegPath;
export const findFfmpeg = () => {
  if (ffmpegPath !== undefined) return ffmpegPath;
  const fromEnv = process.env.CAPTECUT_FFMPEG && fs.existsSync(process.env.CAPTECUT_FFMPEG) ? process.env.CAPTECUT_FFMPEG : null;
  ffmpegPath = fromEnv || locateOnPath('ffmpeg') || bundledFfmpeg() || KNOWN_LOCATIONS.find((p) => fs.existsSync(p)) || null;
  return ffmpegPath;
};

const levelFromPeak = (peak) => (peak <= 0 ? SILENT_DB : Math.max(SILENT_DB, Math.round(20 * Math.log10(peak / 32768))));

class LevelBuffer {
  constructor() {
    this.data = new Int8Array(1 << 16);
    this.length = 0;
  }
  push(value) {
    if (this.length === this.data.length) {
      const bigger = new Int8Array(this.data.length * 2);
      bigger.set(this.data);
      this.data = bigger;
    }
    this.data[this.length++] = value;
  }
  result() {
    return this.data.slice(0, this.length);
  }
}

/** Decodes the first audio stream of a file and returns its peak level (dBFS) per 10 ms window. */
const decodeLevels = (file, onProgress) =>
  new Promise((resolve, reject) => {
    const ffmpeg = findFfmpeg();
    if (!ffmpeg) return reject(new Error('ffmpeg introuvable.'));
    const args = ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', file, '-map', '0:a:0?', '-vn', '-sn', '-dn', '-ac', '1', '-ar', String(SAMPLE_RATE), '-acodec', 'pcm_s16le', '-f', 's16le', 'pipe:1'];
    const child = spawn(ffmpeg, args, { windowsHide: true });
    const levels = new LevelBuffer();
    let carry = Buffer.alloc(0);
    let windowPeak = 0;
    let windowCount = 0;
    let stderr = '';

    child.stdout.on('data', (chunk) => {
      const buffer = carry.length ? Buffer.concat([carry, chunk]) : chunk;
      const usable = buffer.length - (buffer.length % 2);
      for (let offset = 0; offset < usable; offset += 2) {
        const sample = buffer.readInt16LE(offset);
        const magnitude = sample < 0 ? -sample : sample;
        if (magnitude > windowPeak) windowPeak = magnitude;
        if (++windowCount === SAMPLES_PER_BIN) {
          levels.push(levelFromPeak(windowPeak));
          windowPeak = 0;
          windowCount = 0;
        }
      }
      carry = buffer.subarray(usable);
      if (onProgress) onProgress(levels.length * BIN_US);
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (windowCount > 0) levels.push(levelFromPeak(windowPeak));
      const result = levels.result();
      if (code !== 0 && result.length === 0 && stderr.trim()) {
        return reject(new Error(`ffmpeg n'a pas pu lire ${path.basename(file)} : ${stderr.trim().split(/\r?\n/).pop()}`));
      }
      resolve(result);
    });
  });

const cacheDir = () => {
  const dir = path.join(appDataDir(), 'cache');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const cacheKey = (file, stat) =>
  crypto.createHash('sha1').update(`${CACHE_VERSION}|${path.resolve(file)}|${stat.size}|${Math.round(stat.mtimeMs)}`).digest('hex');

const memoryCache = new Map();
const inFlight = new Map();
let activeDecodes = 0;
const waiting = [];

const withDecodeSlot = async (work) => {
  if (activeDecodes >= MAX_PARALLEL_DECODES) await new Promise((release) => waiting.push(release));
  activeDecodes++;
  try {
    return await work();
  } finally {
    activeDecodes--;
    waiting.shift()?.();
  }
};

/**
 * Peak levels of a media file, cached in memory and on disk (keyed by path, size and mtime) so a
 * second analysis of the same rushes is instant.
 * @returns {Promise<{levels: Int8Array, hasAudio: boolean}>}
 */
export const mediaLevels = async (file, onProgress) => {
  if (!fs.existsSync(file)) throw Object.assign(new Error(`Média introuvable : ${file}`), { code: 'missing-media' });
  const stat = fs.statSync(file);
  const key = cacheKey(file, stat);
  if (memoryCache.has(key)) return memoryCache.get(key);
  if (inFlight.has(key)) return inFlight.get(key);

  const job = (async () => {
    const diskFile = path.join(cacheDir(), `${key}.levels`);
    let levels;
    if (fs.existsSync(diskFile)) {
      const raw = fs.readFileSync(diskFile);
      levels = new Int8Array(raw.buffer, raw.byteOffset, raw.byteLength).slice();
    } else {
      levels = await withDecodeSlot(() => decodeLevels(file, onProgress));
      fs.writeFileSync(diskFile, Buffer.from(levels.buffer, levels.byteOffset, levels.byteLength));
    }
    const result = { levels, hasAudio: levels.length > 0 };
    memoryCache.set(key, result);
    return result;
  })();
  inFlight.set(key, job);
  try {
    return await job;
  } finally {
    inFlight.delete(key);
  }
};

export const isCached = (file) => {
  try {
    const key = cacheKey(file, fs.statSync(file));
    return memoryCache.has(key) || fs.existsSync(path.join(cacheDir(), `${key}.levels`));
  } catch {
    return false;
  }
};
