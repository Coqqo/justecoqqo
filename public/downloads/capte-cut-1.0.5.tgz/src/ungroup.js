// Decomposes CapCut compound clips ("clips composés"): the clips inside go back onto the timeline,
// like "Dissocier" in CapCut, so they can be cut one by one.
import { adaptAnimations, buildPieces, removeOrphans } from './cutter.js';
import { buildMaterialIndex, isCompoundSegment, MEDIA_TRACK_TYPES, newCapcutId, segmentEnd, segmentSpeed, timelineDuration } from './draft-model.js';
import { nestedDraftOf } from './timeline-levels.js';

const copy = (value) => structuredClone(value);
const MIN_US = 1000;

// Materials CapCut gives every clip; they hold no visible edit of the compound clip itself.
const PLAIN_LISTS = new Set([
  'speeds',
  'placeholder_infos',
  'canvases',
  'sound_channel_mappings',
  'material_colors',
  'vocal_separations',
  'vocal_beautifys',
  'realtime_denoises',
  'loudnesses',
  'beats',
  'drafts',
  'transitions',
]);

const refsOf = (segment, index) => (segment.extra_material_refs || []).map((id) => ({ id, ref: index.get(id) })).filter(({ ref }) => ref);

const near = (value, expected) => Math.abs(Number(value ?? expected) - expected) < 1e-6;

// Effects of the compound clip that are copied onto each clip it contains (when that clip has none of its own).
const NOT_CARRIED = new Set(['material_animations', 'audio_fades', 'common_mask']);
const isSoundList = (listKey) => /audio|vocal|sound|loudness|denoise/.test(listKey);
const effectLabel = (listKey) => (isSoundList(listKey) ? 'les effets sur le son' : 'les effets et réglages de couleur');

/** The compound clip's own effects, by material list: they go onto the clips inside. */
const carriedEffects = (segment, index) => {
  const lists = new Map();
  for (const { id, ref } of refsOf(segment, index)) {
    if (PLAIN_LISTS.has(ref.listKey) || NOT_CARRIED.has(ref.listKey)) continue;
    if (!lists.has(ref.listKey)) lists.set(ref.listKey, []);
    lists.get(ref.listKey).push(id);
  }
  return lists;
};

/** Whether an effect list of the compound clip applies to a clip of this track type. */
const appliesTo = (listKey, trackType) => (isSoundList(listKey) ? MEDIA_TRACK_TYPES.has(trackType) : trackType === 'video');

/** What the compound clip does on its own that its clips cannot keep once decomposed. */
const lostEditsOf = (segment, index, nested) => {
  const lost = new Set();
  if (!near(segment.clip?.rotation, 0)) lost.add('la rotation');
  if ((segment.common_keyframes || []).some((group) => (group.keyframe_list || []).length)) lost.add('les images clés (et masques)');
  for (const { ref } of refsOf(segment, index)) {
    if (ref.listKey === 'material_animations') {
      if ((ref.item.animations || []).length) lost.add('les animations');
    } else if (ref.listKey === 'audio_fades') {
      if (Number(ref.item.fade_in_duration) > 0 || Number(ref.item.fade_out_duration) > 0) lost.add('les fondus du son');
    } else if (ref.listKey === 'common_mask') lost.add('les images clés (et masques)');
  }
  // an effect is lost on the clips that already have their own effect of that kind
  const carried = carriedEffects(segment, index);
  if (carried.size && nested) {
    const innerIndex = buildMaterialIndex(nested);
    const { from, to } = spanOf(segment, segmentSpeed(segment, index) || 1);
    for (const track of nested.tracks) {
      for (const inner of track.segments || []) {
        if (segmentEnd(inner) <= from || inner.target_timerange.start >= to) continue;
        const own = new Set(refsOf(inner, innerIndex).map(({ ref }) => ref.listKey));
        for (const listKey of carried.keys()) if (appliesTo(listKey, track.type) && own.has(listKey)) lost.add(effectLabel(listKey));
      }
    }
  }
  return [...lost];
};

/** The part of the inner timeline a compound clip shows. */
const spanOf = (segment, speed) => {
  const from = segment.source_timerange.start;
  return { from, to: from + (Number(segment.source_timerange.duration) || Math.round(segment.target_timerange.duration * speed)) };
};

/** The compound clip's framing applied to a clip it contains (zoom and position compose, rotation aside). */
const composeClip = (outer, inner) => {
  if (!outer || !inner) return inner;
  const sx = Number(outer.scale?.x ?? 1);
  const sy = Number(outer.scale?.y ?? 1);
  const flipH = outer.flip?.horizontal === true;
  const flipV = outer.flip?.vertical === true;
  const ix = Number(inner.transform?.x ?? 0) * (flipH ? -1 : 1);
  const iy = Number(inner.transform?.y ?? 0) * (flipV ? -1 : 1);
  return {
    ...inner,
    scale: { x: Number(inner.scale?.x ?? 1) * sx, y: Number(inner.scale?.y ?? 1) * sy },
    transform: { x: Number(outer.transform?.x ?? 0) + ix * sx, y: Number(outer.transform?.y ?? 0) + iy * sy },
    flip: { horizontal: (inner.flip?.horizontal === true) !== flipH, vertical: (inner.flip?.vertical === true) !== flipV },
    alpha: Number(inner.alpha ?? 1) * Number(outer.alpha ?? 1),
  };
};

const IDENTITY_CLIP = { scale: { x: 1, y: 1 }, rotation: 0, transform: { x: 0, y: 0 }, flip: { vertical: false, horizontal: false }, alpha: 1 };

const isIdentityClip = (clip) =>
  !clip ||
  (near(clip.scale?.x, 1) && near(clip.scale?.y, 1) && near(clip.transform?.x, 0) && near(clip.transform?.y, 0) && near(clip.alpha, 1) && clip.flip?.horizontal !== true && clip.flip?.vertical !== true);

/** Why this compound clip cannot be decomposed here, or null. */
const blockedReason = (segment, index, dir) => {
  if (!segment.source_timerange) return 'clip composé sans durée';
  const speed = segmentSpeed(segment, index);
  if (speed === null) return 'clip composé avec une vitesse en courbe';
  if (segment.reverse) return 'clip composé inversé';
  const nested = nestedDraftOf(segment, index, dir);
  if (!nested) return 'clip composé illisible';
  const innerIndex = buildMaterialIndex(nested);
  const { from, to } = spanOf(segment, speed);
  for (const track of nested.tracks) {
    if (!MEDIA_TRACK_TYPES.has(track.type)) continue;
    for (const inner of track.segments || []) {
      const start = inner.target_timerange.start;
      const end = segmentEnd(inner);
      if (end <= from || start >= to || !inner.source_timerange || segmentSpeed(inner, innerIndex) !== null) continue;
      const trimmed = start < from || end > to;
      if (trimmed || !near(speed, 1)) return 'un clip dedans a une vitesse en courbe';
    }
  }
  return null;
};

/** The compound clips of a project: how many, and what decomposing them would change. */
export const describeCompounds = (draft, dir) => {
  const index = buildMaterialIndex(draft);
  const blocked = new Set();
  const lost = new Set();
  let count = 0;
  let ready = 0;
  for (const track of draft.tracks) {
    if (!MEDIA_TRACK_TYPES.has(track.type)) continue;
    for (const segment of track.segments || []) {
      if (!isCompoundSegment(segment, index)) continue;
      count++;
      const reason = blockedReason(segment, index, dir);
      if (reason) blocked.add(reason);
      else {
        ready++;
        lostEditsOf(segment, index, nestedDraftOf(segment, index, dir)).forEach((edit) => lost.add(edit));
      }
    }
  }
  return { count, ready, blocked: [...blocked], lostEdits: [...lost] };
};

/** Copies a clip taken out of a compound clip into the project, with its own materials and fresh ids. */
const transplant = (piece, work, workIndex, draft, index, shared) => {
  const moveMaterial = (id) => {
    const ref = workIndex.get(id);
    if (!ref) return id;
    // a compound clip inside the compound clip keeps one inner timeline for all its pieces
    if (ref.listKey === 'drafts' && shared.has(id)) return shared.get(id);
    const clone = copy(ref.item);
    clone.id = newCapcutId();
    (draft.materials[ref.listKey] ||= []).push(clone);
    index.set(clone.id, { listKey: ref.listKey, item: clone });
    if (ref.listKey === 'drafts') shared.set(id, clone.id);
    return clone.id;
  };
  piece.id = newCapcutId();
  piece.material_id = moveMaterial(piece.material_id);
  piece.extra_material_refs = (piece.extra_material_refs || []).map(moveMaterial);
  for (const group of piece.common_keyframes || []) {
    group.id = newCapcutId();
    for (const keyframe of group.keyframe_list || []) keyframe.id = newCapcutId();
  }
  if ((piece.keyframe_refs || []).length) {
    const lists = Object.entries(work.keyframes || {}).filter(([, list]) => Array.isArray(list));
    piece.keyframe_refs = piece.keyframe_refs.map((id) => {
      for (const [key, list] of lists) {
        const found = list.find((k) => k && k.id === id);
        if (!found) continue;
        const clone = { ...copy(found), id: newCapcutId() };
        draft.keyframes ||= {};
        (draft.keyframes[key] ||= []).push(clone);
        return clone.id;
      }
      return id;
    });
  }
  return piece;
};

/** Cuts one inner clip down to [from, to) of the inner timeline (times of the compound clip). */
const takeRange = (inner, innerTrack, from, to, ctx) => {
  const start = inner.target_timerange.start;
  const end = segmentEnd(inner);
  const a = Math.max(start, from);
  const b = Math.min(end, to);
  if (a === start && b === end) return inner;
  const media = MEDIA_TRACK_TYPES.has(innerTrack.type) && inner.source_timerange;
  if (media && segmentSpeed(inner, ctx.materialIndex) !== null) return buildPieces(inner, [{ a, b }], ctx)[0];
  // text, stickers, effects…: same content, shorter
  inner.target_timerange = { start: a, duration: b - a };
  if (inner.source_timerange && typeof inner.source_timerange.duration === 'number') {
    inner.source_timerange = { start: inner.source_timerange.start + (media ? a - start : 0), duration: b - a };
  }
  inner.extra_material_refs = (inner.extra_material_refs || []).map((id) => {
    const ref = ctx.materialIndex.get(id);
    if (!ref || ref.listKey !== 'material_animations' || !(ref.item.animations || []).length) return id;
    return ctx.cloneMaterial(ref, adaptAnimations(ref.item, a === start, b === end, b - a)).id;
  });
  return inner;
};

const maxOf = (values, floor) => values.reduce((max, v) => (v > max ? v : max), floor);

/**
 * Decomposes every compound clip that can be (see blockedReason). The clips of the compound clip's
 * own track type go back on its track, in its place; its other tracks become new tracks.
 * Returns a new draft; the input is not modified.
 */
export const ungroupCompounds = (inputDraft, dir) => {
  const draft = copy(inputDraft);
  const index = buildMaterialIndex(draft);
  const stats = { compounds: 0, clipsAdded: 0, newTracks: 0, skipped: [], lostEdits: [], trackOrigins: {}, segmentsBefore: 0, segmentsAfter: 0 };
  const lost = new Set();
  const skipped = new Set();
  const orphanCandidates = new Set();
  const shared = new Map();
  const created = [];

  const layers = draft.tracks.flatMap((track) => track.segments.map((s) => Number(s.render_index) || 0));
  let videoLayer = maxOf(layers.filter((v) => v < 11000), 0);
  let effectLayer = maxOf(layers.filter((v) => v >= 11000 && v < 14000), 10999);
  let textLayer = maxOf(layers.filter((v) => v >= 14000), 13999);
  const mainVideo = draft.tracks.find((track) => track.type === 'video');
  const fps = Number(draft.fps) || 30;

  draft.tracks.forEach((track, trackIndex) => {
    stats.segmentsBefore += (track.segments || []).length;
    if (!MEDIA_TRACK_TYPES.has(track.type)) return;
    const newTrackFor = new Map();
    const next = [];
    for (const segment of track.segments || []) {
      if (!isCompoundSegment(segment, index)) {
        next.push(segment);
        continue;
      }
      const reason = blockedReason(segment, index, dir);
      if (reason) {
        skipped.add(reason);
        next.push(segment);
        continue;
      }
      lostEditsOf(segment, index, nestedDraftOf(segment, index, dir)).forEach((edit) => lost.add(edit));
      const carried = carriedEffects(segment, index);
      const holder = refsOf(segment, index).find(({ ref }) => ref.listKey === 'drafts');
      const work = copy(nestedDraftOf(segment, index, dir));
      const workIndex = buildMaterialIndex(work);
      const ctx = {
        materialIndex: workIndex,
        cloneMaterial: (ref, replacement) => {
          const clone = copy(replacement || ref.item);
          clone.id = newCapcutId();
          (work.materials[ref.listKey] ||= []).push(clone);
          workIndex.set(clone.id, { listKey: ref.listKey, item: clone });
          return clone;
        },
      };
      const speed = segmentSpeed(segment, index);
      const { from, to } = spanOf(segment, speed);
      const t0 = segment.target_timerange.start;
      const t1 = t0 + segment.target_timerange.duration;
      // inner times on CapCut's frame grid land on the project's grid (frame k starts at floor(k * 1e6 / fps));
      // nothing runs past the end of the compound clip (its source can be a microsecond longer than its target)
      const toParent = (x) => {
        const raw = t0 + (x - from) / speed;
        const k = Math.round((raw * fps) / 1e6);
        const onGrid = Math.floor((k * 1e6) / fps);
        return Math.min(t1, Math.abs(onGrid - raw) <= 2 ? onGrid : Math.round(raw));
      };
      const framing = isIdentityClip(segment.clip) ? null : segment.clip;
      const gain = Number(segment.volume ?? 1);
      const host = work.tracks.findIndex((t) => t.type === track.type && (t.segments || []).some((s) => segmentEnd(s) > from && s.target_timerange.start < to));
      let lastOnHost = null;

      work.tracks.forEach((innerTrack, k) => {
        const pieces = [];
        for (const inner of innerTrack.segments || []) {
          if (Math.min(segmentEnd(inner), to) - Math.max(inner.target_timerange.start, from) < MIN_US) continue;
          const piece = takeRange(inner, innerTrack, from, to, ctx);
          const start = toParent(piece.target_timerange.start);
          piece.target_timerange = { start, duration: toParent(piece.target_timerange.start + piece.target_timerange.duration) - start };
          if (piece.target_timerange.duration < MIN_US) continue;
          const media = MEDIA_TRACK_TYPES.has(innerTrack.type);
          if (!media && typeof piece.source_timerange?.duration === 'number') {
            piece.source_timerange = { ...piece.source_timerange, duration: piece.target_timerange.duration };
          }
          if (media && !near(gain, 1)) piece.volume = Number(piece.volume ?? 1) * gain;
          if (framing && (piece.clip || innerTrack.type === 'video')) piece.clip = composeClip(framing, piece.clip || IDENTITY_CLIP);
          transplant(piece, work, workIndex, draft, index, shared);
          for (const [listKey, ids] of carried) {
            if (!appliesTo(listKey, innerTrack.type) || piece.extra_material_refs.some((id) => index.get(id)?.listKey === listKey)) continue;
            for (const id of ids) {
              const clone = { ...copy(index.get(id).item), id: newCapcutId() };
              draft.materials[listKey].push(clone);
              index.set(clone.id, { listKey, item: clone });
              piece.extra_material_refs.push(clone.id);
            }
          }
          if (media && !near(speed, 1) && piece.source_timerange) {
            // the compound clip's speed now applies to each clip
            piece.speed = (Number(piece.speed) || 1) * speed;
            for (const id of piece.extra_material_refs) {
              const ref = index.get(id);
              if (ref?.listKey === 'speeds') ref.item.speed = piece.speed;
            }
          }
          pieces.push(piece);
        }
        if (!pieces.length) return;
        stats.clipsAdded += pieces.length;
        if (k === host) {
          for (const piece of pieces) {
            piece.render_index = segment.render_index ?? 0;
            piece.track_render_index = segment.track_render_index ?? trackIndex;
          }
          next.push(...pieces);
          lastOnHost = pieces[pieces.length - 1];
          return;
        }
        // the compound clip's other tracks: one new track each, shared by all pieces of the same compound clip
        const key = `${holder.ref.item.id}|${k}`;
        let target = newTrackFor.get(key);
        if (!target) {
          const { segments: _ignored, ...meta } = innerTrack;
          target = { ...copy(meta), id: newCapcutId(), segments: [] };
          if (target.type === 'video') {
            target.flag = 2; // overlay
            target.layer = ++videoLayer;
          }
          target.attribute = (Number(meta.attribute) || 0) | (Number(track.attribute) || 0);
          if (target.type === 'audio' && track === mainVideo && draft.config?.video_mute === true) target.attribute |= 1;
          newTrackFor.set(key, target);
          created.push(target);
          stats.trackOrigins[target.id] = track.id;
        }
        for (const piece of pieces) {
          const layer = Number(piece.render_index) || 0;
          if (target.type === 'video') piece.render_index = target.layer;
          else if (target.type === 'audio') piece.render_index = 0;
          else if (layer >= 14000) piece.render_index = ++textLayer;
          else if (layer >= 11000) piece.render_index = ++effectLayer;
          target.segments.push(piece);
        }
      });

      // the transition after the compound clip now follows its last clip
      const transitions = refsOf(segment, index).filter(({ ref }) => ref.listKey === 'transitions');
      if (transitions.length && lastOnHost) {
        lastOnHost.extra_material_refs = lastOnHost.extra_material_refs.filter((id) => index.get(id)?.listKey !== 'transitions');
        lastOnHost.extra_material_refs.push(...transitions.map(({ id }) => id));
      }
      orphanCandidates.add(segment.material_id);
      for (const { id, ref } of refsOf(segment, index)) if (ref.listKey !== 'transitions' || !lastOnHost) orphanCandidates.add(id);
      stats.compounds++;
    }
    next.sort((x, y) => x.target_timerange.start - y.target_timerange.start);
    track.segments = next;
  });

  for (const track of created) {
    delete track.layer;
    track.segments.sort((x, y) => x.target_timerange.start - y.target_timerange.start);
    draft.tracks.push(track);
    const position = draft.tracks.length - 1;
    for (const segment of track.segments) segment.track_render_index = position;
  }
  stats.newTracks = created.length;
  stats.segmentsAfter = draft.tracks.reduce((sum, track) => sum + (track.segments || []).length, 0);
  stats.materialsCleaned = removeOrphans(draft, orphanCandidates);
  stats.skipped = [...skipped];
  stats.lostEdits = [...lost];
  draft.duration = timelineDuration(draft);
  return { draft, stats };
};
