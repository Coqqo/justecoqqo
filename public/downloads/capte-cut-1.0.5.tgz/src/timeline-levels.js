import fs from 'node:fs';
import path from 'node:path';
import { BIN_US, mediaLevels } from './audio-levels.js';
import { buildMaterialIndex, isCompoundSegment, MEDIA_TRACK_TYPES, resolveMediaPath, segmentSpeed, timelineDuration } from './draft-model.js';

const SILENT_DB = -100;
const LOUD_DB = 0;

const segmentGainDb = (segment) => {
  const volume = Number(segment.volume ?? 1);
  return volume > 0 ? 20 * Math.log10(volume) : null;
};

/** Fills the timeline bins covered by one segment with the loudest source level they map to. */
/**
 * mirrorUs: for a reversed clip read from the original (not reversed) media, the media duration used to
 * mirror source times; null otherwise. CapCut's source range of a reversed clip is in reversed-media time.
 */
const paintSegment = (timeline, segment, sourceLevels, speed, gainDb, mirrorUs = null) => {
  const { start: targetStart, duration: targetDuration } = segment.target_timerange;
  const { start: sourceStart } = segment.source_timerange;
  const targetEnd = targetStart + targetDuration;
  const firstBin = Math.floor(targetStart / BIN_US);
  const lastBin = Math.min(timeline.length, Math.ceil(targetEnd / BIN_US));

  for (let bin = firstBin; bin < lastBin; bin++) {
    const t0 = Math.max(bin * BIN_US, targetStart) - targetStart;
    const t1 = Math.min((bin + 1) * BIN_US, targetEnd) - targetStart;
    if (t1 <= t0) continue;
    const f0 = sourceStart + t0 * speed;
    const f1 = sourceStart + t1 * speed;
    const s0 = mirrorUs === null ? f0 : mirrorUs - f1;
    const s1 = mirrorUs === null ? f1 : mirrorUs - f0;
    const i0 = Math.max(0, Math.floor(s0 / BIN_US));
    const i1 = Math.max(i0 + 1, Math.ceil(s1 / BIN_US));
    let peak = SILENT_DB;
    for (let i = i0; i < i1 && i < sourceLevels.length; i++) if (sourceLevels[i] > peak) peak = sourceLevels[i];
    const level = peak <= SILENT_DB ? SILENT_DB : Math.max(SILENT_DB, Math.min(LOUD_DB, Math.round(peak + gainDb)));
    if (level > timeline[bin]) timeline[bin] = level;
  }
};

const paintConstant = (timeline, segment, value) => {
  const { start, duration } = segment.target_timerange;
  const lastBin = Math.min(timeline.length, Math.ceil((start + duration) / BIN_US));
  for (let bin = Math.floor(start / BIN_US); bin < lastBin; bin++) if (value > timeline[bin]) timeline[bin] = value;
};

const MAX_NESTING = 3;

/** The timeline inside a compound clip: embedded in the material, or in its sub-draft file. */
export const nestedDraftOf = (segment, materialIndex, dir) => {
  const ref = (segment.extra_material_refs || []).map((id) => materialIndex.get(id)).find((r) => r && r.listKey === 'drafts');
  const material = ref?.item;
  if (!material) return null;
  if (material.draft && Array.isArray(material.draft.tracks)) return material.draft;
  const file = resolveMediaPath(String(material.draft_file_path || '').replace(/\\/g, path.sep), dir);
  try {
    const nested = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Array.isArray(nested.tracks) ? nested : null;
  } catch {
    return null;
  }
};

/**
 * Sound level of one timeline (one value per 10 ms) from some of its tracks. A compound clip is
 * listened to through the timeline it contains (all its video and audio tracks).
 */
const renderLevels = async (draft, dir, tracks, ctx, depth) => {
  const materialIndex = buildMaterialIndex(draft);
  const durationUs = Number(draft.duration) || timelineDuration(draft);
  const timeline = new Int8Array(Math.max(1, Math.ceil(durationUs / BIN_US))).fill(SILENT_DB);
  const mainVideoTrack = draft.tracks.find((track) => track.type === 'video');
  const jobs = [];

  for (const track of tracks) {
    const trackMuted = track.type === 'video' && track === mainVideoTrack && draft.config?.video_mute === true;
    if (trackMuted) continue;
    for (const segment of track.segments || []) {
      const material = materialIndex.get(segment.material_id)?.item;
      if (!material || material.type === 'photo' || material.has_audio === false || !segment.source_timerange) continue;
      const gainDb = segmentGainDb(segment);
      if (gainDb === null) continue;
      const speed = segmentSpeed(segment, materialIndex);
      if (speed === null) {
        ctx.warnings.add('Un clip avec une vitesse en courbe ne peut pas être analysé : il est conservé tel quel.');
        jobs.push({ segment, constant: LOUD_DB });
        continue;
      }
      if (isCompoundSegment(segment, materialIndex)) {
        const nested = depth < MAX_NESTING ? nestedDraftOf(segment, materialIndex, dir) : null;
        if (!nested) {
          ctx.warnings.add('Un clip composé n\'a pas pu être lu : il est conservé tel quel.');
          jobs.push({ segment, constant: LOUD_DB });
          continue;
        }
        const innerTracks = nested.tracks.filter((t) => MEDIA_TRACK_TYPES.has(t.type));
        jobs.push({ segment, speed, gainDb, levels: renderLevels(nested, dir, innerTracks, ctx, depth + 1) });
        continue;
      }
      const reversedFile = segment.reverse && material.reverse_path ? resolveMediaPath(material.reverse_path, dir) : '';
      if (segment.reverse && reversedFile && fs.existsSync(reversedFile)) jobs.push({ segment, file: reversedFile, speed, gainDb, mirrorUs: null });
      else jobs.push({ segment, file: resolveMediaPath(material.path, dir), speed, gainDb, mirrorUs: segment.reverse ? Number(material.duration) || null : null });
    }
  }

  await Promise.all(
    jobs.map(async (job) => {
      if (job.levels) {
        job.levels = await job.levels;
        return;
      }
      if (!job.file) return;
      if (!ctx.files.has(job.file)) {
        ctx.files.set(
          job.file,
          (async () => {
            ctx.total++;
            try {
              return await mediaLevels(job.file);
            } catch (error) {
              ctx.warnings.add(error.code === 'missing-media' ? `Média introuvable (conservé tel quel) : ${path.basename(job.file)}` : error.message);
              return null;
            } finally {
              ctx.done++;
              ctx.onProgress({ done: ctx.done, total: ctx.total, file: path.basename(job.file) });
            }
          })(),
        );
      }
      job.media = await ctx.files.get(job.file);
    }),
  );

  for (const job of jobs) {
    if (job.constant !== undefined) paintConstant(timeline, job.segment, job.constant);
    else if (job.levels) paintSegment(timeline, job.segment, job.levels, job.speed, job.gainDb);
    else if (job.media === null) paintConstant(timeline, job.segment, LOUD_DB);
    else if (job.media?.hasAudio) paintSegment(timeline, job.segment, job.media.levels, job.speed, job.gainDb, job.mirrorUs);
  }
  return timeline;
};

/**
 * Builds the sound level of the timeline (one value per 10 ms) from the tracks used for detection.
 * Several tracks combine by loudest value: a moment is silent only when every listened track is silent.
 * Anything that cannot be analysed is treated as loud, so it is never cut by mistake.
 */
export const buildTimelineLevels = async (project, listenTrackIds, onProgress = () => {}) => {
  const { draft, dir } = project;
  const ctx = { warnings: new Set(), files: new Map(), done: 0, total: 0, onProgress };
  const listened = draft.tracks.filter((track) => listenTrackIds.includes(track.id));
  const levels = await renderLevels(draft, dir, listened, ctx, 0);
  const durationUs = Number(draft.duration) || timelineDuration(draft);
  return { binUs: BIN_US, durationUs, levels, warnings: [...ctx.warnings], files: ctx.files.size };
};
