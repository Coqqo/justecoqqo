import { buildMaterialIndex, MEDIA_TRACK_TYPES, newCapcutId, segmentEnd, segmentSpeed, timelineDuration, unsplittableReason } from './draft-model.js';

const copy = (value) => structuredClone(value);

/**
 * Maps a time of the original timeline to its position once the removed intervals are closed up.
 * CapCut keeps clip edges on its frame grid (frame k starts at floor(k * 1e6 / fps)), so times on
 * that grid are shifted by whole frames and stay on it; anything else is shifted in microseconds.
 */
const createTimeMap = (intervals, fps) => {
  const frameStart = (k) => Math.floor((k * 1_000_000) / fps);
  const frameOf = (t) => Math.round((t * fps) / 1_000_000);
  const onGrid = (t) => frameStart(frameOf(t)) === t;
  const starts = intervals.map((i) => i.start);
  const prefix = [0];
  const prefixFrames = [0];
  for (const i of intervals) {
    prefix.push(prefix[prefix.length - 1] + (i.end - i.start));
    prefixFrames.push(prefixFrames[prefixFrames.length - 1] + (frameOf(i.end) - frameOf(i.start)));
  }
  const gridAligned = intervals.every((i) => onGrid(i.start) && onGrid(i.end));
  const lastStartingBefore = (t) => {
    let lo = 0;
    let hi = starts.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (starts[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    return lo - 1;
  };
  const map = (t) => {
    const i = lastStartingBefore(t);
    if (i < 0) return t;
    if (gridAligned && onGrid(t)) {
      const removedFrames = prefixFrames[i] + frameOf(Math.min(t, intervals[i].end)) - frameOf(intervals[i].start);
      return frameStart(frameOf(t) - removedFrames);
    }
    return t - (prefix[i] + Math.min(t, intervals[i].end) - intervals[i].start);
  };
  const isRemoved = (t) => {
    const i = lastStartingBefore(t + 1);
    return i >= 0 && t >= intervals[i].start && t < intervals[i].end;
  };
  return { map, isRemoved, overlapping: (a, b) => intervals.filter((i) => i.end > a && i.start < b) };
};

/**
 * Pulls interval edges onto a nearby clip edge (closer than half a frame) so that no
 * sliver of a clip is left behind and the closed-up timeline has no tiny gaps.
 */
const snapToClipEdges = (intervals, tracks, frameUs) => {
  const edges = [...new Set(tracks.flatMap((t) => t.segments.flatMap((s) => [s.target_timerange.start, segmentEnd(s)])))].sort((a, b) => a - b);
  if (!edges.length) return intervals;
  const nearest = (t) => {
    let lo = 0;
    let hi = edges.length - 1;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (edges[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    const candidates = [edges[lo], edges[lo - 1]].filter((e) => e !== undefined);
    return candidates.reduce((best, e) => (Math.abs(e - t) < Math.abs(best - t) ? e : best));
  };
  const snapped = intervals.map(({ start, end }) => {
    const s = nearest(start);
    const e = nearest(end);
    return { start: Math.abs(s - start) < frameUs / 2 ? s : start, end: Math.abs(e - end) < frameUs / 2 ? e : end };
  });
  const merged = [];
  for (const i of snapped.filter((x) => x.end > x.start).sort((a, b) => a.start - b.start)) {
    const last = merged[merged.length - 1];
    if (last && i.start <= last.end) last.end = Math.max(last.end, i.end);
    else merged.push({ ...i });
  }
  return merged;
};

/** Removes from the blanks every part that falls on a clip that cannot be cut, so nothing drifts out of sync. */
const subtractRanges = (intervals, protectedRanges) => {
  if (!protectedRanges.length) return { kept: intervals, droppedUs: 0, reasons: [] };
  const sorted = [...protectedRanges].sort((x, y) => x.start - y.start);
  const kept = [];
  const reasons = new Set();
  let droppedUs = 0;
  for (const interval of intervals) {
    let cursor = interval.start;
    for (const range of sorted) {
      if (range.end <= cursor || range.start >= interval.end) continue;
      if (range.start > cursor) kept.push({ start: cursor, end: range.start });
      droppedUs += Math.min(range.end, interval.end) - Math.max(range.start, cursor);
      reasons.add(range.reason);
      cursor = Math.max(cursor, range.end);
      if (cursor >= interval.end) break;
    }
    if (cursor < interval.end) kept.push({ start: cursor, end: interval.end });
  }
  return { kept, droppedUs, reasons: [...reasons] };
};

const splitRanges = (segment, timeMap) => {
  const start = segment.target_timerange.start;
  const end = segmentEnd(segment);
  const cuts = new Set([start, end]);
  for (const interval of timeMap.overlapping(start, end)) {
    if (interval.start > start) cuts.add(interval.start);
    if (interval.end < end) cuts.add(interval.end);
  }
  const points = [...cuts].sort((a, b) => a - b);
  const ranges = [];
  for (let k = 0; k < points.length - 1; k++) {
    const a = points[k];
    const b = points[k + 1];
    if (b > a) ranges.push({ a, b, silent: timeMap.isRemoved(Math.floor((a + b) / 2)) });
  }
  return ranges;
};

const sourceRangeFor = (segment, a, b, speed) => {
  const targetStart = segment.target_timerange.start;
  const targetEnd = segmentEnd(segment);
  const { start: sourceStart, duration: sourceDuration } = segment.source_timerange;
  const sourceEnd = sourceStart + sourceDuration;
  // A reversed clip plays CapCut's reversed copy of the media forwards, so its source range maps forwards too.
  let s0 = a === targetStart ? sourceStart : sourceStart + Math.round((a - targetStart) * speed);
  let s1 = b === targetEnd ? sourceEnd : sourceStart + Math.round((b - targetStart) * speed);
  s0 = Math.max(sourceStart, Math.min(sourceEnd, s0));
  s1 = Math.max(s0 + 1, Math.min(sourceEnd, s1));
  return { start: s0, duration: s1 - s0 };
};

const interpolatedValues = (before, after, t) => {
  const from = before.values || [];
  const to = after.values || [];
  if (from.length !== to.length || !from.every(Number.isFinite) || !to.every(Number.isFinite)) return null;
  const ratio = (t - before.time_offset) / (after.time_offset - before.time_offset);
  return from.map((v, i) => v + (to[i] - v) * ratio);
};

/** The value of an animated property at time t, as a new keyframe (linear between its neighbours). */
const keyframeAt = (sorted, t) => {
  const before = [...sorted].reverse().find((k) => k.time_offset <= t);
  const after = sorted.find((k) => k.time_offset >= t);
  const base = before || after;
  if (before && after && after.time_offset > before.time_offset) {
    const values = interpolatedValues(before, after, t);
    return { ...base, id: newCapcutId(), time_offset: t, ...(values ? { values } : {}) };
  }
  return { ...base, id: newCapcutId(), time_offset: t };
};

/**
 * Keyframe times are in source-media time. Like CapCut, a piece keeps only the keyframes inside its
 * own source range, plus a keyframe on each edge holding the value it had there, so the motion is unchanged.
 */
const trimKeyframes = (piece, isCopy) => {
  const { start, duration } = piece.source_timerange;
  const end = start + duration;
  for (const group of piece.common_keyframes || []) {
    const sorted = (group.keyframe_list || []).map((k) => ({ ...k, time_offset: Number(k.time_offset) })).sort((x, y) => x.time_offset - y.time_offset);
    if (!sorted.length) continue;
    const kept = sorted.filter((k) => k.time_offset >= start && k.time_offset <= end);
    if (!kept.length || (kept[0].time_offset > start && sorted[0].time_offset < start)) kept.unshift(keyframeAt(sorted, start));
    if (sorted[sorted.length - 1].time_offset > end && kept[kept.length - 1].time_offset < end) kept.push(keyframeAt(sorted, end));
    group.keyframe_list = kept;
    if (isCopy) {
      group.id = newCapcutId();
      for (const keyframe of kept) keyframe.id = newCapcutId();
    }
  }
};

const ANIMATION_FIRST_ONLY = new Set(['in', 'group']);
const ANIMATION_LAST_ONLY = new Set(['out']);

export const adaptAnimations = (material, isFirst, isLast, pieceDuration) => {
  const animations = (material.animations || [])
    .filter((anim) => (ANIMATION_FIRST_ONLY.has(anim.type) ? isFirst : ANIMATION_LAST_ONLY.has(anim.type) ? isLast : true))
    .map((anim) => {
      const duration = Math.min(Number(anim.duration) || 0, pieceDuration);
      const start = ANIMATION_LAST_ONLY.has(anim.type) ? Math.max(0, pieceDuration - duration) : Math.min(Number(anim.start) || 0, Math.max(0, pieceDuration - duration));
      return { ...anim, duration, start };
    });
  return { ...material, animations };
};

const adaptFade = (material, isFirst, isLast, pieceDuration) => ({
  ...material,
  fade_in_duration: isFirst ? Math.min(Number(material.fade_in_duration) || 0, pieceDuration) : 0,
  fade_out_duration: isLast ? Math.min(Number(material.fade_out_duration) || 0, pieceDuration) : 0,
});

/** Builds the kept pieces of one clip, each with its own copy of the per-clip materials (as CapCut does on a split). */
export const buildPieces = (segment, ranges, ctx) => {
  const speed = segmentSpeed(segment, ctx.materialIndex);
  const pristine = copy(segment);
  const originalDuration = segment.target_timerange.duration;
  const transitionRefs = new Set((segment.extra_material_refs || []).filter((id) => ctx.materialIndex.get(id)?.listKey === 'transitions'));

  return ranges.map((range, k) => {
    const isFirst = k === 0;
    const isLast = k === ranges.length - 1;
    const isCopy = !isFirst;
    const piece = isFirst ? segment : copy(pristine);
    const duration = range.b - range.a;
    piece.target_timerange = { start: range.a, duration };
    piece.source_timerange = sourceRangeFor(pristine, range.a, range.b, speed);

    if (isCopy) {
      piece.id = newCapcutId();
      const main = ctx.materialIndex.get(pristine.material_id);
      if (main) piece.material_id = ctx.cloneMaterial(main).id;
    }

    piece.extra_material_refs = (pristine.extra_material_refs || []).flatMap((id) => {
      const ref = ctx.materialIndex.get(id);
      if (!ref) return [id];
      if (transitionRefs.has(id)) return isLast ? [id] : [];
      // the inner timeline of a compound clip is shared by all its pieces (CapCut does the same)
      if (ref.listKey === 'drafts') return [id];
      if (ranges.length === 1 && duration === originalDuration) return [id];
      if (ref.listKey === 'material_animations') return [ctx.cloneMaterial(ref, adaptAnimations(ref.item, isFirst, isLast, duration)).id];
      if (ref.listKey === 'audio_fades') return [ctx.cloneMaterial(ref, adaptFade(ref.item, isFirst, isLast, duration)).id];
      return isCopy ? [ctx.cloneMaterial(ref).id] : [id];
    });

    if (!(ranges.length === 1 && duration === originalDuration)) trimKeyframes(piece, isCopy);
    return piece;
  });
};

const resolveOverlaps = (segments) => {
  let pushed = 0;
  segments.sort((x, y) => x.target_timerange.start - y.target_timerange.start);
  for (let k = 1; k < segments.length; k++) {
    const previousEnd = segmentEnd(segments[k - 1]);
    if (segments[k].target_timerange.start < previousEnd) {
      segments[k].target_timerange.start = previousEnd;
      pushed++;
    }
  }
  return pushed;
};

const UUID_IN_JSON = /"([0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12})"/g;

/** Drops materials that only belonged to removed clips (referenced nowhere but by their own id). */
export const removeOrphans = (draft, candidateIds) => {
  if (!candidateIds.size) return 0;
  const counts = new Map();
  for (const match of JSON.stringify(draft).matchAll(UUID_IN_JSON)) counts.set(match[1], (counts.get(match[1]) || 0) + 1);
  let removed = 0;
  for (const [key, list] of Object.entries(draft.materials)) {
    if (!Array.isArray(list)) continue;
    const kept = list.filter((item) => !(item && candidateIds.has(item.id) && counts.get(item.id) === 1));
    removed += list.length - kept.length;
    draft.materials[key] = kept;
  }
  return removed;
};

/** Shortens the intro/outro animations of a clip whose length changed. */
const fitAnimations = (segment, duration, ctx) => {
  segment.extra_material_refs = (segment.extra_material_refs || []).map((id) => {
    const ref = ctx.materialIndex.get(id);
    if (!ref || ref.listKey !== 'material_animations' || !(ref.item.animations || []).length) return id;
    return ctx.cloneMaterial(ref, adaptAnimations(ref.item, true, true, duration)).id;
  });
};

/** Trims a media clip from its end (target and source) to a new length. */
const trimMediaEnd = (segment, duration, ctx) => {
  segment.target_timerange = { ...segment.target_timerange, duration };
  if (segment.source_timerange) {
    const speed = segmentSpeed(segment, ctx.materialIndex) || 1;
    segment.source_timerange = { ...segment.source_timerange, duration: Math.max(1, Math.min(segment.source_timerange.duration, Math.round(duration * speed))) };
  }
  fitAnimations(segment, duration, ctx);
};

const hasNoSound = (segment, materialIndex) => {
  const material = materialIndex.get(segment.material_id)?.item;
  return Boolean(material) && (material.type === 'photo' || material.has_audio === false);
};

/**
 * Cuts the given intervals out of the selected tracks.
 *  - mode "ripple": removes the blanks and closes the gaps (other tracks follow when shiftOthers is on);
 *  - mode "split": only splits the clips at each blank, nothing moves, blanks stay to delete by hand.
 * Clips that cannot be cut (speed curves) and silent clips on a listened track
 * (photos, videos without sound) are protected: the blanks over them are dropped.
 * Returns a new draft; the input is not modified.
 */
export const applyCuts = (inputDraft, { intervals, cutTrackIds, listenTrackIds = [], mode = 'ripple', shiftOthers = true }) => {
  const draft = copy(inputDraft);
  const fps = Number(draft.fps) || 30;
  const frameUs = 1_000_000 / fps;
  const materialIndex = buildMaterialIndex(draft);
  const cutTracks = draft.tracks.filter((t) => cutTrackIds.includes(t.id) && MEDIA_TRACK_TYPES.has(t.type));
  if (!cutTracks.length) throw new Error('Choisis au moins une piste vidéo ou audio à couper.');

  const isPhoto = (segment) => materialIndex.get(segment.material_id)?.item?.type === 'photo';
  const protectedReason = (track, segment) =>
    unsplittableReason(segment, materialIndex) ||
    (isPhoto(segment) ? 'photo' : null) ||
    (listenTrackIds.includes(track.id) && hasNoSound(segment, materialIndex) ? 'clip sans son' : null);
  const untouchable = cutTracks.flatMap((track) =>
    track.segments
      .map((segment) => ({ segment, reason: protectedReason(track, segment) }))
      .filter(({ reason }) => reason)
      .map(({ segment, reason }) => ({ start: segment.target_timerange.start, end: segmentEnd(segment), reason })),
  );
  const { kept: cuttable, droppedUs, reasons } = subtractRanges(intervals, untouchable);
  const effective = snapToClipEdges(cuttable, cutTracks, frameUs).filter((i) => i.end - i.start >= frameUs / 2);
  const timeMap = createTimeMap(effective, fps);
  const ripple = mode === 'ripple';

  const cloneMaterial = (ref, replacement) => {
    const clone = copy(replacement || ref.item);
    clone.id = newCapcutId();
    draft.materials[ref.listKey].push(clone);
    return clone;
  };
  const ctx = { materialIndex, cloneMaterial };

  const stats = {
    segmentsBefore: 0,
    segmentsAfter: 0,
    clipsSplit: 0,
    piecesRemoved: 0,
    untouched: droppedUs > 0 ? reasons : [],
    skippedUs: droppedUs,
    othersShifted: 0,
    othersTrimmed: 0,
    othersRemoved: 0,
    pushed: 0,
  };
  const orphanCandidates = new Set();
  const markReplaced = (segment) => {
    // Reference counting in removeOrphans keeps whichever of these a piece still uses.
    orphanCandidates.add(segment.material_id);
    for (const id of segment.extra_material_refs || []) orphanCandidates.add(id);
  };

  for (const track of cutTracks) {
    stats.segmentsBefore += track.segments.length;
    const next = [];
    for (const segment of track.segments) {
      if (unsplittableReason(segment, materialIndex)) {
        // No blank overlaps this clip any more (see subtractRanges), it only moves.
        if (ripple) {
          const start = timeMap.map(segment.target_timerange.start);
          segment.target_timerange = { start, duration: timeMap.map(segmentEnd(segment)) - start };
        }
        next.push(segment);
        continue;
      }
      const ranges = splitRanges(segment, timeMap);
      const kept = ripple ? ranges.filter((r) => !r.silent) : ranges;
      if (ranges.length > 1) {
        stats.clipsSplit++;
        markReplaced(segment);
      }
      stats.piecesRemoved += ranges.length - kept.length;
      if (!kept.length) {
        markReplaced(segment);
        continue;
      }
      const pieces = buildPieces(segment, kept, ctx);
      if (ripple) {
        pieces.forEach((piece, k) => {
          const start = timeMap.map(kept[k].a);
          piece.target_timerange = { start, duration: timeMap.map(kept[k].b) - start };
        });
      }
      next.push(...pieces);
    }
    stats.pushed += resolveOverlaps(next);
    track.segments = next;
    stats.segmentsAfter += next.length;
  }

  if (ripple && shiftOthers && effective.length) {
    const visibleAfterCut = new Map();
    for (const track of draft.tracks) {
      if (cutTracks.includes(track)) continue;
      const next = [];
      for (const segment of track.segments) {
        const start = segment.target_timerange.start;
        const end = segmentEnd(segment);
        const newStart = timeMap.map(start);
        if (MEDIA_TRACK_TYPES.has(track.type)) {
          // Media that is not cut keeps its length; it only follows the edit.
          if (newStart !== start) stats.othersShifted++;
          visibleAfterCut.set(segment, timeMap.map(end) - newStart);
          segment.target_timerange = { ...segment.target_timerange, start: newStart };
          next.push(segment);
          continue;
        }
        const newDuration = timeMap.map(end) - newStart;
        if (newDuration <= frameUs / 2) {
          stats.othersRemoved++;
          continue;
        }
        if (newStart !== start || newDuration !== end - start) stats.othersShifted++;
        segment.target_timerange = { start: newStart, duration: newDuration };
        if (segment.source_timerange && typeof segment.source_timerange.duration === 'number') {
          segment.source_timerange = { ...segment.source_timerange, duration: newDuration };
        }
        if (newDuration < end - start) fitAnimations(segment, newDuration, ctx);
        next.push(segment);
      }
      // A clip that spans a removed blank now runs into the next one: shorten it instead of moving
      // the next clip, so every clip still starts in sync with the edit.
      next.sort((x, y) => x.target_timerange.start - y.target_timerange.start);
      const settled = [];
      for (let k = 0; k < next.length; k++) {
        const segment = next[k];
        const following = next[k + 1];
        if (!following || segmentEnd(segment) <= following.target_timerange.start) {
          settled.push(segment);
          continue;
        }
        const room = following.target_timerange.start - segment.target_timerange.start;
        if (room > frameUs / 2) {
          if (MEDIA_TRACK_TYPES.has(track.type)) trimMediaEnd(segment, room, ctx);
          else {
            segment.target_timerange = { ...segment.target_timerange, duration: room };
            fitAnimations(segment, room, ctx);
          }
          stats.othersTrimmed++;
          settled.push(segment);
        } else if ((visibleAfterCut.get(segment) ?? Infinity) <= frameUs / 2) {
          // Its whole stretch of time was a removed blank: it goes with it.
          stats.othersRemoved++;
        } else settled.push(segment);
      }
      stats.pushed += resolveOverlaps(settled);
      track.segments = settled;
    }
  }

  stats.materialsCleaned = removeOrphans(draft, orphanCandidates);
  draft.duration = timelineDuration(draft);
  stats.durationBefore = Number(inputDraft.duration) || timelineDuration(inputDraft);
  stats.durationAfter = draft.duration;
  stats.intervals = effective.length;
  stats.removedUs = ripple ? effective.reduce((sum, i) => sum + (i.end - i.start), 0) : 0;
  return { draft, stats };
};
