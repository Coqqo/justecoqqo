import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BRAND } from '../public/brand.js';
import { alignToFrames, sanitizeIntervals, suggestThreshold, totalDuration } from '../public/silence.js';
import { findFfmpeg } from './audio-levels.js';
import { applyCuts } from './cutter.js';
import { timelineFingerprint } from './draft-model.js';
import { appDataDir, candidateDraftsDirs, resolveDraftsDir, writeConfig } from './paths.js';
import {
  isProjectOpenInCapcut,
  listBackups,
  listProjects,
  openProject,
  ProjectError,
  projectDirOf,
  projectSummary,
  restoreLatestBackup,
  saveProject,
} from './projects.js';
import { buildTimelineLevels } from './timeline-levels.js';
import { ungroupCompounds } from './ungroup.js';
import { renderPreview, wavHeader } from './preview-audio.js';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PUBLIC_DIR = path.join(ROOT, 'public');
export const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const TOKEN = crypto.randomBytes(18).toString('hex');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8' };

class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const sendJson = (res, status, body) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 25 * 1024 * 1024) {
        reject(new HttpError(413, 'too-large', 'Requête trop volumineuse.'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch {
        reject(new HttpError(400, 'bad-json', 'JSON invalide.'));
      }
    });
    req.on('error', reject);
  });

// ---- Analysis jobs ---------------------------------------------------------

const jobs = new Map();

const startAnalysis = (projectId, listenTrackIds) => {
  const id = crypto.randomUUID();
  const job = { id, status: 'running', progress: { done: 0, total: 0, file: '' }, startedAt: Date.now() };
  jobs.set(id, job);
  (async () => {
    try {
      const project = openProject(resolveDraftsDir(), projectId);
      const result = await buildTimelineLevels(project, listenTrackIds, (progress) => {
        job.progress = progress;
      });
      job.result = {
        binUs: result.binUs,
        durationUs: result.durationUs,
        fps: Number(project.draft.fps) || 30,
        levels: Buffer.from(result.levels.buffer, result.levels.byteOffset, result.levels.byteLength).toString('base64'),
        suggestedThresholdDb: suggestThreshold(result.levels),
        fingerprint: project.fingerprint,
        warnings: result.warnings,
        listenTrackIds,
      };
      job.status = 'done';
    } catch (error) {
      job.status = 'error';
      job.error = error.message;
    }
  })();
  for (const [key, old] of jobs) if (Date.now() - old.startedAt > 30 * 60 * 1000) jobs.delete(key);
  return job;
};

// ---- Listening preview -------------------------------------------------------
// Only the latest mix is kept (in memory): the one of the project on screen.

let preview = null; // { key, pcm }

const startPreview = (projectId, listenTrackIds) => {
  const project = openProject(resolveDraftsDir(), projectId);
  const key = crypto.createHash('sha1').update(`${project.id}|${project.fingerprint}|${[...listenTrackIds].sort().join(',')}`).digest('hex').slice(0, 20);
  const id = crypto.randomUUID();
  const job = { id, status: 'running', progress: {}, startedAt: Date.now() };
  jobs.set(id, job);
  if (preview?.key === key) {
    job.status = 'done';
    job.result = { key, durationUs: preview.durationUs, missing: preview.missing };
    return job;
  }
  (async () => {
    try {
      const result = await renderPreview(project, listenTrackIds);
      preview = { key, ...result };
      job.result = { key, durationUs: result.durationUs, missing: result.missing };
      job.status = 'done';
    } catch (error) {
      job.status = 'error';
      job.error = error.message;
    }
  })();
  return job;
};

/** Streams the preview as a WAV file, with byte ranges so the player can seek anywhere. */
const servePreviewAudio = (req, res, query) => {
  if (!preview || query.get('key') !== preview.key) {
    res.writeHead(404);
    return res.end();
  }
  const header = wavHeader(preview.pcm.length);
  const data = Buffer.from(preview.pcm.buffer, preview.pcm.byteOffset, preview.pcm.byteLength);
  const total = header.length + data.length;
  let start = 0;
  let end = total - 1;
  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
  if (range) {
    if (range[1]) start = Number(range[1]);
    if (range[2]) end = Math.min(Number(range[2]), total - 1);
    if (!range[1] && range[2]) {
      start = Math.max(0, total - Number(range[2]));
      end = total - 1;
    }
    if (start > end || start >= total) {
      res.writeHead(416, { 'Content-Range': `bytes */${total}` });
      return res.end();
    }
  }
  res.writeHead(range ? 206 : 200, {
    'Content-Type': 'audio/wav',
    'Content-Length': end - start + 1,
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'no-store',
    ...(range ? { 'Content-Range': `bytes ${start}-${end}/${total}` } : {}),
  });
  // the header part is only sent when the range starts inside it
  const fromHeader = start < header.length ? header.subarray(start, Math.min(header.length, end + 1)) : Buffer.alloc(0);
  const fromData = data.subarray(Math.max(0, start - header.length), Math.max(0, end + 1 - header.length));
  res.write(fromHeader);
  res.end(fromData);
};

// ---- Routes ------------------------------------------------------------------

const routes = {
  'GET /api/status': () => ({
    version: VERSION,
    name: BRAND.name,
    desktop: process.env.CAPTECUT_DESKTOP === '1',
    launcher: process.env.JUSTECOQQO_LAUNCHER === '1',
    platform: process.platform,
    ffmpeg: findFfmpeg(),
    draftsDir: resolveDraftsDir(),
    draftsDirExists: fs.existsSync(resolveDraftsDir()),
    suggestedDraftsDirs: candidateDraftsDirs(),
    dataDir: appDataDir(),
  }),

  'POST /api/settings': (body) => {
    const dir = String(body.draftsDir || '').trim();
    if (!dir || !fs.existsSync(dir)) throw new HttpError(400, 'bad-dir', "Ce dossier n'existe pas.");
    writeConfig({ draftsDir: dir });
    return { draftsDir: dir };
  },

  'GET /api/projects': () => ({ projects: listProjects(resolveDraftsDir()) }),

  'GET /api/project': (_body, query) => {
    const project = openProject(resolveDraftsDir(), query.get('id'));
    const backups = listBackups(project.id, project.draft.id);
    return { ...projectSummary(project), backups: backups.length, lastChange: backups[0]?.summary?.mode || '' };
  },

  'GET /api/lock': (_body, query) => ({ openInCapcut: isProjectOpenInCapcut(projectDirOf(resolveDraftsDir(), query.get('id'))) }),

  'POST /api/analyze': (body) => {
    if (!findFfmpeg()) throw new HttpError(500, 'no-ffmpeg', `ffmpeg est introuvable : réinstalle ${BRAND.name} depuis ${BRAND.page}`);
    const listen = Array.isArray(body.listenTrackIds) ? body.listenTrackIds.map(String) : [];
    if (!listen.length) throw new HttpError(400, 'no-track', 'Choisis au moins une piste à écouter.');
    const job = startAnalysis(String(body.projectId), listen);
    return { jobId: job.id };
  },

  'POST /api/preview': (body) => {
    const listen = Array.isArray(body.listenTrackIds) ? body.listenTrackIds.map(String) : [];
    if (!listen.length) throw new HttpError(400, 'no-track', 'Choisis au moins une piste à écouter.');
    if (!findFfmpeg()) throw new HttpError(500, 'no-ffmpeg', `ffmpeg est introuvable : réinstalle ${BRAND.name} depuis ${BRAND.page}`);
    return { jobId: startPreview(String(body.projectId), listen).id };
  },

  'POST /api/report': async (body) => {
    // "Prévenir Coqqo de l'incident": forwarded to the site, which posts it in the app's Discord channel
    const response = await fetch('https://justecoqqo.fr/api/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app: 'capte-cut', message: String(body.message || '').slice(0, 1500), context: body.context && typeof body.context === 'object' ? body.context : {} }),
      signal: AbortSignal.timeout(10000),
    }).catch(() => null);
    if (!response?.ok) throw new HttpError(502, 'report', 'Envoi impossible.');
    return { ok: true };
  },

  'GET /api/job': (_body, query) => {
    const job = jobs.get(query.get('id'));
    if (!job) throw new HttpError(404, 'no-job', 'Analyse introuvable.');
    return { status: job.status, progress: job.progress, result: job.result, error: job.error };
  },

  'POST /api/apply': (body) => {
    const draftsDir = resolveDraftsDir();
    const project = openProject(draftsDir, String(body.projectId));
    if (isProjectOpenInCapcut(project.dir) && !body.force) {
      throw new HttpError(409, 'open-in-capcut', 'Le projet est encore ouvert dans CapCut.');
    }
    if (body.fingerprint !== timelineFingerprint(project.draft)) {
      throw new HttpError(412, 'changed', "Le projet a changé depuis l'analyse.");
    }
    const durationUs = Number(project.draft.duration);
    const fps = Number(project.draft.fps) || 30;
    const intervals = alignToFrames(sanitizeIntervals(body.intervals, durationUs), fps, durationUs);
    if (!intervals.length) throw new HttpError(400, 'nothing', 'Aucun blanc à couper.');
    const trackIds = (value) => (Array.isArray(value) ? value.map(String) : []);
    const cutTrackIds = trackIds(body.cutTrackIds);
    if (!cutTrackIds.length) throw new HttpError(400, 'no-track', 'Choisis au moins une piste à couper.');
    const mode = body.mode === 'split' ? 'split' : 'ripple';
    const { draft, stats } = applyCuts(project.draft, {
      intervals,
      cutTrackIds,
      listenTrackIds: trackIds(body.listenTrackIds),
      mode,
      shiftOthers: body.shiftOthers !== false,
    });
    if (!stats.intervals) throw new HttpError(400, 'nothing', 'Les blancs tombent tous sur des clips qui ne peuvent pas être coupés : rien à faire.');
    const summary = { mode, blanks: stats.intervals, removedUs: mode === 'ripple' ? stats.removedUs : totalDuration(intervals) };
    const backup = saveProject(project, draft, summary);
    return { stats, summary, backup, mirrors: project.mirrors.length, fingerprint: timelineFingerprint(draft) };
  },

  'POST /api/ungroup': (body) => {
    const draftsDir = resolveDraftsDir();
    const project = openProject(draftsDir, String(body.projectId));
    if (isProjectOpenInCapcut(project.dir) && !body.force) {
      throw new HttpError(409, 'open-in-capcut', 'Le projet est encore ouvert dans CapCut.');
    }
    const { draft, stats } = ungroupCompounds(project.draft, project.dir);
    if (!stats.compounds) {
      const why = stats.skipped.length ? ` (${stats.skipped.join(', ')})` : '';
      throw new HttpError(400, 'nothing', `Aucun clip composé ne peut être décomposé ici${why}. Tu peux le faire dans CapCut : clic droit sur le clip, « Dissocier ».`);
    }
    const summary = { mode: 'ungroup', compounds: stats.compounds };
    const backup = saveProject(project, draft, summary);
    return { stats, summary, backup, mirrors: project.mirrors.length, fingerprint: timelineFingerprint(draft) };
  },

  'POST /api/undo': (body) => {
    const draftsDir = resolveDraftsDir();
    const dir = projectDirOf(draftsDir, String(body.projectId));
    if (isProjectOpenInCapcut(dir) && !body.force) throw new HttpError(409, 'open-in-capcut', 'Le projet est encore ouvert dans CapCut.');
    const manifest = restoreLatestBackup(draftsDir, String(body.projectId));
    return { restored: manifest.summary, remaining: listBackups(String(body.projectId), openProject(draftsDir, String(body.projectId)).draft.id).length };
  },
};

const serveCover = (res, query) => {
  const file = path.join(projectDirOf(resolveDraftsDir(), query.get('id')), 'draft_cover.jpg');
  if (!fs.existsSync(file)) {
    res.writeHead(404);
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'max-age=60' });
  fs.createReadStream(file).pipe(res);
};

const serveStatic = (res, pathname) => {
  const relative = pathname === '/' ? 'index.html' : pathname.slice(1);
  const file = path.normalize(path.join(PUBLIC_DIR, relative));
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404);
    return res.end('Introuvable');
  }
  let content = fs.readFileSync(file);
  if (relative === 'index.html') content = Buffer.from(content.toString('utf8').replace('__APP_TOKEN__', TOKEN));
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  res.end(content);
};

const handle = async (req, res, port) => {
  const host = req.headers.host || '';
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    res.writeHead(403);
    return res.end();
  }
  const url = new URL(req.url, `http://${host}`);
  if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
  if (req.headers['x-app-token'] !== TOKEN && url.searchParams.get('token') !== TOKEN) return sendJson(res, 403, { error: 'Accès refusé.' });
  const route = routes[`${req.method} ${url.pathname}`];
  if (!route && url.pathname !== '/api/cover' && url.pathname !== '/api/preview-audio') return sendJson(res, 404, { error: 'Route inconnue.' });
  try {
    if (url.pathname === '/api/cover') return serveCover(res, url.searchParams);
    if (url.pathname === '/api/preview-audio') return servePreviewAudio(req, res, url.searchParams);
    const body = req.method === 'POST' ? await readBody(req) : {};
    sendJson(res, 200, await route(body, url.searchParams));
  } catch (error) {
    if (error instanceof HttpError) return sendJson(res, error.status, { error: error.message, code: error.code });
    if (error instanceof ProjectError) return sendJson(res, 400, { error: error.message, code: error.code });
    console.error(error);
    sendJson(res, 500, { error: error.message || 'Erreur inattendue.' });
  }
};

/**
 * Starts the local server on 127.0.0.1 (trying the next ports if the preferred one is taken).
 * @returns {Promise<{url: string, port: number, server: http.Server}>}
 */
export const startServer = ({ preferredPort = 4848, attempts = 15 } = {}) =>
  new Promise((resolve, reject) => {
    const tryPort = (port, attemptsLeft) => {
      const server = http.createServer((req, res) =>
        handle(req, res, server.address().port).catch((error) => {
          console.error(error);
          if (!res.headersSent) sendJson(res, 500, { error: 'Erreur inattendue.' });
          else res.end();
        }),
      );
      server.once('error', (error) => {
        if (error.code === 'EADDRINUSE' && attemptsLeft > 0) tryPort(port + 1, attemptsLeft - 1);
        else reject(error);
      });
      server.listen(port, '127.0.0.1', () => {
        const actual = server.address().port;
        resolve({ url: `http://127.0.0.1:${actual}/`, port: actual, server });
      });
    };
    tryPort(preferredPort, attempts);
  });
