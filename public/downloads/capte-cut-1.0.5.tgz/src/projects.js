import fs from 'node:fs';
import path from 'node:path';
import { appDataDir } from './paths.js';
import { describeTracks, timelineDuration, timelineFingerprint } from './draft-model.js';
import { describeCompounds } from './ungroup.js';

const ROOT_DOCUMENTS = ['draft_content.json', 'draft_info.json', 'template-2.tmp'];
const MAX_BACKUPS_PER_PROJECT = 15;

export class ProjectError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

const readJson = (file) => {
  const raw = fs.readFileSync(file);
  const text = raw.toString('utf8').replace(/^﻿/, '');
  if (!text.trimStart().startsWith('{')) return { encrypted: true };
  try {
    return { value: JSON.parse(text) };
  } catch {
    return { corrupt: true };
  }
};

const safeFolderName = (name) => {
  if (!name || name.includes('/') || name.includes('\\') || name === '.' || name === '..') {
    throw new ProjectError('bad-project', 'Nom de projet invalide.');
  }
  return name;
};

export const projectDirOf = (draftsDir, folderName) => path.join(draftsDir, safeFolderName(folderName));

export const isProjectOpenInCapcut = (projectDir) => fs.existsSync(path.join(projectDir, '.locked'));

const readRootMeta = (draftsDir) => {
  try {
    const parsed = readJson(path.join(draftsDir, 'root_meta_info.json')).value;
    const byFolder = new Map();
    for (const entry of parsed?.all_draft_store || []) {
      const folder = path.basename(String(entry.draft_fold_path || '').replace(/[\\/]+$/, ''));
      if (folder) byFolder.set(folder, entry);
    }
    return byFolder;
  } catch {
    return new Map();
  }
};

export const listProjects = (draftsDir) => {
  if (!draftsDir || !fs.existsSync(draftsDir)) return [];
  const rootMeta = readRootMeta(draftsDir);
  const projects = [];
  for (const entry of fs.readdirSync(draftsDir, { withFileTypes: true })) {
    if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
    const dir = path.join(draftsDir, entry.name);
    const document = ROOT_DOCUMENTS.map((name) => path.join(dir, name)).find((file) => fs.existsSync(file));
    if (!document) continue;
    let meta = {};
    try {
      meta = readJson(path.join(dir, 'draft_meta_info.json')).value || {};
    } catch {
      /* the meta file is optional */
    }
    const root = rootMeta.get(entry.name) || {};
    const modifiedUs = Number(meta.tm_draft_modified || root.tm_draft_modified || 0);
    const modifiedMs = modifiedUs > 1e14 ? modifiedUs / 1000 : modifiedUs > 1e11 ? modifiedUs : fs.statSync(document).mtimeMs;
    projects.push({
      id: entry.name,
      name: meta.draft_name || root.draft_name || entry.name,
      modifiedMs,
      durationUs: Number(meta.tm_duration || root.tm_duration || 0),
      hasCover: fs.existsSync(path.join(dir, 'draft_cover.jpg')),
      openInCapcut: isProjectOpenInCapcut(dir),
    });
  }
  return projects.sort((a, b) => b.modifiedMs - a.modifiedMs);
};

const mainTimelineDocuments = (projectDir) => {
  const pointer = path.join(projectDir, 'Timelines', 'project.json');
  if (!fs.existsSync(pointer)) return [];
  const parsed = readJson(pointer).value;
  const id = parsed?.main_timeline_id;
  if (typeof id !== 'string' || !/^[A-Za-z0-9-]+$/.test(id)) return [];
  return ROOT_DOCUMENTS.map((name) => path.join(projectDir, 'Timelines', id, name)).filter((file) => fs.existsSync(file));
};

/**
 * Loads a project. CapCut keeps several identical copies of the timeline (draft_content.json,
 * template-2.tmp and the same pair under Timelines/<id>/); every readable copy of the same
 * timeline is returned as a mirror so a save keeps them all in sync.
 */
export const openProject = (draftsDir, folderName) => {
  const dir = projectDirOf(draftsDir, folderName);
  if (!fs.existsSync(dir)) throw new ProjectError('not-found', 'Projet introuvable.');

  const candidates = [...ROOT_DOCUMENTS.map((name) => path.join(dir, name)).filter((f) => fs.existsSync(f)), ...mainTimelineDocuments(dir)];
  if (!candidates.length) throw new ProjectError('not-found', 'Aucun fichier de timeline dans ce projet.');

  const parsed = candidates.map((file) => ({ file, ...readJson(file) }));
  const primary = parsed.find((c) => c.value && Array.isArray(c.value.tracks));
  if (!primary) {
    if (parsed.some((c) => c.encrypted)) {
      throw new ProjectError('encrypted', 'Ce projet est chiffré par CapCut (souvent un projet créé depuis un template) : il ne peut pas être modifié.');
    }
    throw new ProjectError('corrupt', 'Le fichier du projet est illisible.');
  }

  const draft = primary.value;
  const mirrors = parsed.filter((c) => c.value && c.value.id === draft.id && Array.isArray(c.value.tracks)).map((c) => c.file);
  const skipped = parsed.filter((c) => !mirrors.includes(c.file)).map((c) => path.relative(dir, c.file));

  return {
    id: folderName,
    dir,
    draft,
    primaryFile: primary.file,
    mirrors,
    skipped,
    metaFile: fs.existsSync(path.join(dir, 'draft_meta_info.json')) ? path.join(dir, 'draft_meta_info.json') : null,
    fingerprint: timelineFingerprint(draft),
  };
};

export const projectSummary = (project) => ({
  id: project.id,
  name: project.id,
  fps: Number(project.draft.fps) || 30,
  durationUs: Number(project.draft.duration) || timelineDuration(project.draft),
  tracks: describeTracks(project.draft),
  fingerprint: project.fingerprint,
  openInCapcut: isProjectOpenInCapcut(project.dir),
  mirrorCount: project.mirrors.length,
  capcutVersion: project.draft.new_version || '',
  compounds: describeCompounds(project.draft, project.dir),
});

const backupsRoot = (folderName) => path.join(appDataDir(), 'backups', safeFolderName(folderName));

const timestamp = () => {
  const d = new Date();
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}-${pad(d.getMilliseconds(), 3)}`;
};

const createBackup = (project, summary) => {
  const folder = path.join(backupsRoot(project.id), timestamp());
  const files = [...project.mirrors, ...(project.metaFile ? [project.metaFile] : [])];
  const relative = files.map((file) => path.relative(project.dir, file));
  for (const rel of relative) {
    const target = path.join(folder, 'files', rel);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(path.join(project.dir, rel), target);
  }
  fs.writeFileSync(path.join(folder, 'manifest.json'), JSON.stringify({ project: project.id, draftId: project.draft.id, createdAt: Date.now(), files: relative, summary }, null, 2));
  pruneBackups(project.id);
  return folder;
};

const pruneBackups = (folderName) => {
  const all = listBackupFolders(folderName);
  for (const old of all.slice(MAX_BACKUPS_PER_PROJECT)) fs.rmSync(old, { recursive: true, force: true });
};

const readManifest = (folder) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(folder, 'manifest.json'), 'utf8'));
  } catch {
    return null;
  }
};

/** Backups of a project folder, newest first; with a draft id, only those of that very timeline. */
const listBackupFolders = (folderName, draftId) => {
  const root = backupsRoot(folderName);
  if (!fs.existsSync(root)) return [];
  return fs
    .readdirSync(root)
    .map((name) => ({ folder: path.join(root, name), manifest: readManifest(path.join(root, name)) }))
    .filter(({ manifest }) => manifest && (!draftId || manifest.draftId === draftId))
    .sort((a, b) => b.manifest.createdAt - a.manifest.createdAt)
    .map(({ folder }) => folder);
};

export const listBackups = (folderName, draftId) =>
  listBackupFolders(folderName, draftId).map((folder) => {
    const manifest = readManifest(folder);
    return { folder, createdAt: manifest.createdAt, summary: manifest.summary };
  });

const pause = (ms) => {
  try {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  } catch {
    const until = Date.now() + ms;
    while (Date.now() < until) {
      /* wait: some hosts do not allow blocking the main thread with Atomics.wait */
    }
  }
};
const BUSY_CODES = new Set(['EPERM', 'EBUSY', 'EACCES']);

/** Writes through a temporary file; retries a few times because Windows (antivirus, indexer) can hold files briefly. */
const writeAtomically = (file, content) => {
  const temp = `${file}.captecut-tmp`;
  fs.writeFileSync(temp, content);
  for (let attempt = 0; ; attempt++) {
    try {
      fs.renameSync(temp, file);
      return;
    } catch (error) {
      if (!BUSY_CODES.has(error.code)) throw error;
      if (attempt >= 6) {
        try {
          fs.copyFileSync(temp, file);
          fs.rmSync(temp, { force: true });
          return;
        } catch {
          fs.rmSync(temp, { force: true });
          throw new ProjectError('busy', `Un fichier du projet est utilisé par un autre programme (souvent CapCut encore ouvert) : ${path.basename(file)}.`);
        }
      }
      pause(250);
    }
  }
};

const updateMetaFile = (metaFile, durationUs) => {
  if (!metaFile) return;
  const meta = readJson(metaFile).value;
  if (!meta) return;
  meta.tm_duration = durationUs;
  const modified = Number(meta.tm_draft_modified || 0);
  meta.tm_draft_modified = modified > 1e14 ? Date.now() * 1000 : modified > 1e11 ? Date.now() : Math.floor(Date.now() / 1000);
  writeAtomically(metaFile, JSON.stringify(meta));
};

const restoreFromBackup = (backupFolder, projectDir) => {
  const manifest = readManifest(backupFolder);
  if (!manifest) throw new ProjectError('no-backup', 'Sauvegarde illisible.');
  const missing = manifest.files.filter((rel) => !fs.existsSync(path.join(backupFolder, 'files', rel)) || !fs.existsSync(path.dirname(path.join(projectDir, rel))));
  if (missing.length) throw new ProjectError('backup-mismatch', "Cette sauvegarde ne correspond plus à la structure du projet : rien n'a été modifié.");
  for (const rel of manifest.files) {
    const source = path.join(backupFolder, 'files', rel);
    if (fs.existsSync(source)) writeAtomically(path.join(projectDir, rel), fs.readFileSync(source));
  }
  return manifest;
};

/** Backs the project up, then writes the new timeline to every mirror (all or nothing). */
export const saveProject = (project, newDraft, summary) => {
  const backupFolder = createBackup(project, summary);
  const content = JSON.stringify(newDraft);
  try {
    for (const file of project.mirrors) writeAtomically(file, content);
    updateMetaFile(project.metaFile, newDraft.duration);
  } catch (error) {
    try {
      restoreFromBackup(backupFolder, project.dir);
      fs.rmSync(backupFolder, { recursive: true, force: true });
    } catch {
      /* the backup folder stays available for a manual restore */
    }
    throw error;
  }
  return backupFolder;
};

/** Restores the most recent backup and removes it, so repeated undos walk back in time. */
export const restoreLatestBackup = (draftsDir, folderName) => {
  const { draft } = openProject(draftsDir, folderName);
  const [latest] = listBackupFolders(folderName, draft.id);
  if (!latest) throw new ProjectError('no-backup', 'Aucune sauvegarde à restaurer pour ce projet.');
  const manifest = restoreFromBackup(latest, projectDirOf(draftsDir, folderName));
  fs.rmSync(latest, { recursive: true, force: true });
  return manifest;
};
