import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { BRAND } from '../public/brand.js';

const DRAFTS_SUBPATH = ['User Data', 'Projects', 'com.lveditor.draft'];

export const candidateDraftsDirs = () => {
  const home = os.homedir();
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
    return [
      path.join(local, 'CapCut', ...DRAFTS_SUBPATH),
      path.join(local, 'JianyingPro', ...DRAFTS_SUBPATH),
    ];
  }
  if (process.platform === 'darwin') {
    return [
      path.join(home, 'Movies', 'CapCut', ...DRAFTS_SUBPATH),
      path.join(home, 'Movies', 'JianyingPro', ...DRAFTS_SUBPATH),
    ];
  }
  return [];
};

const LEGACY_FOLDER = 'AutoCut-CapCut';

const dataRoot = () => {
  const home = os.homedir();
  if (process.platform === 'win32') return process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
  if (process.platform === 'darwin') return path.join(home, 'Library', 'Application Support');
  return path.join(home, '.local', 'share');
};

let resolvedDataDir;
export const appDataDir = () => {
  if (resolvedDataDir) return resolvedDataDir;
  const base = process.env.CAPTECUT_DATA_DIR || path.join(dataRoot(), BRAND.dataFolder);
  const legacy = path.join(dataRoot(), LEGACY_FOLDER);
  // Backups made by the first version (named AutoCut) stay available for undo.
  if (!process.env.CAPTECUT_DATA_DIR && !fs.existsSync(base) && fs.existsSync(legacy)) {
    try {
      fs.renameSync(legacy, base);
    } catch {
      /* start fresh if the old folder cannot be moved */
    }
  }
  fs.mkdirSync(base, { recursive: true });
  resolvedDataDir = base;
  return base;
};

const configPath = () => path.join(appDataDir(), 'config.json');

export const readConfig = () => {
  try {
    return JSON.parse(fs.readFileSync(configPath(), 'utf8'));
  } catch {
    return {};
  }
};

export const writeConfig = (patch) => {
  const next = { ...readConfig(), ...patch };
  fs.writeFileSync(configPath(), JSON.stringify(next, null, 2));
  return next;
};

/** The drafts folder the user picked, else the first standard location that exists. */
export const resolveDraftsDir = () => {
  const configured = readConfig().draftsDir;
  if (configured && fs.existsSync(configured)) return configured;
  return candidateDraftsDirs().find((dir) => fs.existsSync(dir)) || configured || candidateDraftsDirs()[0] || '';
};
