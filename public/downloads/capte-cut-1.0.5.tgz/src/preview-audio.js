// The sound of the listened tracks, mixed along the timeline, to listen to before cutting.
// Kept in memory as 16 kHz mono PCM (no file written) and served as a WAV stream.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { findFfmpeg } from './audio-levels.js';
import { buildMaterialIndex, isCompoundSegment, MEDIA_TRACK_TYPES, resolveMediaPath, segmentSpeed, timelineDuration } from './draft-model.js';
import { nestedDraftOf } from './timeline-levels.js';

export const PREVIEW_RATE = 16_000;
const MAX_NESTING = 3;

/** Decodes the first audio stream of a file to 16 kHz mono samples. */
const decodePcm = (file) =>
  new Promise((resolve, reject) => {
    const ffmpeg = findFfmpeg();
    if (!ffmpeg) return reject(new Error('ffmpeg introuvable.'));
    const args = ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', file, '-map', '0:a:0?', '-vn', '-sn', '-dn', '-ac', '1', '-ar', String(PREVIEW_RATE), '-acodec', 'pcm_s16le', '-f', 's16le', 'pipe:1'];
    const child = spawn(ffmpeg, args, { windowsHide: true });
    const chunks = [];
    let size = 0;
    child.stdout.on('data', (chunk) => {
      chunks.push(chunk);
      size += chunk.length;
    });
    child.stderr.on('data', () => {});
    child.on('error', reject);
    child.on('close', () => {
      const buffer = Buffer.concat(chunks, size);
      const samples = new Int16Array(Math.floor(buffer.length / 2));
      new Uint8Array(samples.buffer).set(buffer.subarray(0, samples.length * 2)); // s16le, as in memory
      resolve(samples);
    });
  });

/**
 * Adds one clip to the mix: each output sample takes the source sample it plays at that moment
 * (speed changes the pitch here, which is fine to judge the cuts). mirrorUs: reversed clip read
 * from the original media (its source range is in reversed-media time).
 */
const paint = (mix, segment, source, speed, gain, mirrorUs = null) => {
  const { start: targetStart, duration } = segment.target_timerange;
  const perUs = PREVIEW_RATE / 1e6;
  const first = Math.max(0, Math.round(targetStart * perUs));
  const last = Math.min(mix.length, Math.round((targetStart + duration) * perUs));
  const sourceStart = segment.source_timerange.start * perUs;
  const mirror = mirrorUs === null ? null : mirrorUs * perUs;
  const origin = targetStart * perUs;
  for (let i = first; i < last; i++) {
    const position = sourceStart + (i - origin) * speed;
    const j = Math.floor(mirror === null ? position : mirror - position);
    if (j < 0 || j >= source.length) continue;
    mix[i] += source[j] * gain;
  }
};

const renderMix = async (draft, dir, tracks, ctx, depth) => {
  const index = buildMaterialIndex(draft);
  const durationUs = Number(draft.duration) || timelineDuration(draft);
  const mix = new Float32Array(Math.max(1, Math.ceil((durationUs * PREVIEW_RATE) / 1e6)));
  const mainVideo = draft.tracks.find((track) => track.type === 'video');
  for (const track of tracks) {
    if (track === mainVideo && draft.config?.video_mute === true) continue;
    for (const segment of track.segments || []) {
      const material = index.get(segment.material_id)?.item;
      if (!material || material.type === 'photo' || material.has_audio === false || !segment.source_timerange) continue;
      const gain = Number(segment.volume ?? 1);
      if (!(gain > 0)) continue;
      // a speed curve is played at its average speed
      const speed = segmentSpeed(segment, index) ?? segment.source_timerange.duration / Math.max(1, segment.target_timerange.duration);
      if (isCompoundSegment(segment, index)) {
        const nested = depth < MAX_NESTING ? nestedDraftOf(segment, index, dir) : null;
        if (!nested) continue;
        const inner = await renderMix(nested, dir, nested.tracks.filter((t) => MEDIA_TRACK_TYPES.has(t.type)), ctx, depth + 1);
        paint(mix, segment, inner, speed, gain);
        continue;
      }
      const reversed = segment.reverse && material.reverse_path ? resolveMediaPath(material.reverse_path, dir) : '';
      const useReversed = segment.reverse && reversed && fs.existsSync(reversed);
      const file = useReversed ? reversed : resolveMediaPath(material.path, dir);
      if (!fs.existsSync(file)) {
        ctx.missing.add(path.basename(file));
        continue;
      }
      const source = await ctx.source(file);
      paint(mix, segment, source, speed, gain, segment.reverse && !useReversed ? Number(material.duration) || null : null);
    }
  }
  return mix;
};

/**
 * Mixes the listened tracks of a project along its timeline.
 * @returns {Promise<{ pcm: Int16Array, durationUs: number, missing: string[] }>}
 */
export const renderPreview = async (project, listenTrackIds) => {
  const { draft, dir } = project;
  const decoded = new Map();
  const ctx = {
    missing: new Set(),
    source: (file) => {
      if (!decoded.has(file)) decoded.set(file, decodePcm(file));
      return decoded.get(file);
    },
  };
  const tracks = draft.tracks.filter((track) => listenTrackIds.includes(track.id));
  const mix = await renderMix(draft, dir, tracks, ctx, 0);
  // loud enough to hear the edges of the words, without clipping
  let peak = 1;
  for (let i = 0; i < mix.length; i++) {
    const v = mix[i] < 0 ? -mix[i] : mix[i];
    if (v > peak) peak = v;
  }
  const gain = Math.min(4, (0.89 * 32767) / peak);
  const pcm = new Int16Array(mix.length);
  for (let i = 0; i < mix.length; i++) pcm[i] = Math.max(-32768, Math.min(32767, Math.round(mix[i] * gain)));
  return { pcm, durationUs: Math.round((pcm.length * 1e6) / PREVIEW_RATE), missing: [...ctx.missing] };
};

/** The 44-byte header of a 16-bit mono WAV file holding `samples` samples. */
export const wavHeader = (samples) => {
  const header = Buffer.alloc(44);
  const dataSize = samples * 2;
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(PREVIEW_RATE, 24);
  header.writeUInt32LE(PREVIEW_RATE * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);
  return header;
};
