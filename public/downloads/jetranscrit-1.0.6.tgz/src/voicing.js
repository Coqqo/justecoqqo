// When the voice really speaks in the sound (20 ms steps): used to follow the words while listening.
import fs from 'node:fs';
import path from 'node:path';
import { audioFileOf, folderOf } from './library.js';

const RATE = 16000;
const FRAME = 320; // 20 ms

export const voicedIntervals = (id) => {
  const cache = path.join(folderOf(id), 'voicing.json');
  const file = audioFileOf(id);
  if (fs.existsSync(cache) && fs.statSync(cache).mtimeMs >= fs.statSync(file).mtimeMs) return JSON.parse(fs.readFileSync(cache, 'utf8'));
  const data = fs.readFileSync(file);
  const frames = Math.floor(data.length / 2 / FRAME);
  const db = new Float32Array(frames);
  for (let f = 0; f < frames; f++) {
    let sum = 0;
    for (let i = 0; i < FRAME; i++) {
      const v = data.readInt16LE((f * FRAME + i) * 2) / 32768;
      sum += v * v;
    }
    db[f] = 10 * Math.log10(sum / FRAME + 1e-10);
  }
  // the threshold follows the recording: well above its quiet moments, well below its loud ones
  const sorted = Array.from(db).sort((a, b) => a - b);
  const quiet = sorted[Math.floor(sorted.length * 0.15)] ?? -60;
  const loud = sorted[Math.floor(sorted.length * 0.9)] ?? -20;
  const threshold = Math.max(quiet + 8, loud - 30);
  const intervals = [];
  let start = -1;
  for (let f = 0; f <= frames; f++) {
    const on = f < frames && db[f] > threshold;
    if (on && start < 0) start = f;
    if (!on && start >= 0) {
      const s = (start * FRAME) / RATE;
      const e = (f * FRAME) / RATE;
      const last = intervals[intervals.length - 1];
      if (last && s - last[1] < 0.12) last[1] = e; // tiny gaps inside a word are not pauses
      else intervals.push([s, e]);
      start = -1;
    }
  }
  const rounded = intervals.filter(([s, e]) => e - s >= 0.06).map(([s, e]) => [Math.round(s * 100) / 100, Math.round(e * 100) / 100]);
  fs.writeFileSync(cache, JSON.stringify(rounded));
  return rounded;
};
