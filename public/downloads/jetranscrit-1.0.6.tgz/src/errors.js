// Errors carry a code: the app shows the matching advice (public/help.js).
import fs from 'node:fs';

export const coded = (code, message) => Object.assign(new Error(message), { code });

/** Free bytes on the disk holding dir (null when unknown). */
export const freeBytes = (dir) => {
  try {
    const stats = fs.statfsSync(dir);
    return stats.bavail * stats.bsize;
  } catch {
    return null;
  }
};

export const ensureSpace = (dir, needed) => {
  const free = freeBytes(dir);
  if (free !== null && free < needed) {
    throw coded('disk-full', `Plus assez de place sur ton disque : il faut ${Math.ceil(needed / 1e8) / 10} Go libres, il en reste ${Math.floor(free / 1e8) / 10}.`);
  }
};

/** Disk full while writing: the message says so instead of a cryptic system error. */
export const explainFsError = (error) => (error?.code === 'ENOSPC' ? coded('disk-full', 'Plus assez de place sur ton disque.') : error);
