// Videos from a link (YouTube, TikTok, Instagram, Vimeo, X…) with yt-dlp: only the sound is downloaded.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

let ytdlpPath;
export const findYtdlp = () => {
  if (ytdlpPath) return ytdlpPath;
  const fromEnv = process.env.JETRANSCRIT_YTDLP && fs.existsSync(process.env.JETRANSCRIT_YTDLP) ? process.env.JETRANSCRIT_YTDLP : null;
  if (fromEnv) return (ytdlpPath = fromEnv);
  const finder = process.platform === 'win32' ? 'where' : 'which';
  for (const name of ['yt-dlp', 'yt-dlp.exe']) {
    const result = spawnSync(finder, [name], { encoding: 'utf8', windowsHide: true });
    const found = result.status === 0 && result.stdout.split(/\r?\n/).map((l) => l.trim()).find((l) => l && fs.existsSync(l));
    if (found) return (ytdlpPath = found);
  }
  return null;
};

export const looksLikeLink = (text) => {
  try {
    const url = new URL(String(text).trim());
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
};

const run = (args, { onLine = () => {}, signal } = {}) =>
  new Promise((resolve, reject) => {
    const ytdlp = findYtdlp();
    if (!ytdlp) return reject(Object.assign(new Error("L'outil de téléchargement est introuvable : ouvre jetranscris depuis le launcher justecoqqo pour le réparer."), { code: 'no-ffmpeg' }));
    const child = spawn(ytdlp, ['--encoding', 'utf-8', ...args], { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } });
    let out = '';
    let err = '';
    const abort = () => child.kill();
    signal?.addEventListener('abort', abort, { once: true });
    child.stdout.on('data', (chunk) => {
      out += chunk;
      for (const line of chunk.toString().split(/\r?\n/)) if (line.trim()) onLine(line.trim());
    });
    child.stderr.on('data', (chunk) => {
      for (const line of chunk.toString().split(/\r?\n/)) if (line.startsWith('JTP')) onLine(line.trim());
      err += chunk;
      if (err.length > 8000) err = err.slice(-8000);
    });
    child.on('error', reject);
    child.on('close', (code) => {
      signal?.removeEventListener('abort', abort);
      if (signal?.aborted) return reject(new Error('Annulé.'));
      code === 0 ? resolve(out) : reject(Object.assign(new Error(err.trim().split(/\r?\n/).pop() || 'Téléchargement impossible.'), { raw: err }));
    });
  });

const explain = (error) => {
  const text = `${error.raw || ''} ${error.message}`;
  const result = (code, message) => Object.assign(new Error(message), { code });
  if (/\bprivate\b|sign in|log in|login required|--cookies|age-restricted|confirm your age/i.test(text)) return result('link-private', 'Cette vidéo est privée ou demande une connexion : télécharge-la puis importe le fichier.');
  if (/unsupported url/i.test(text)) return result('link-unsupported', "Ce site n'est pas pris en charge : télécharge la vidéo puis importe le fichier.");
  if (/unable to download|http error 4\d\d|not available|removed/i.test(text)) return result('link-unavailable', "Cette vidéo n'est pas disponible (supprimée, privée ou bloquée dans ton pays).");
  if (/getaddrinfo|network|timed out|connection/i.test(text)) return result('offline', 'Pas de connexion à internet.');
  return result('link-unavailable', `Téléchargement impossible : ${error.message}`);
};

let updatedThisSession = false;
/** The sites change often: when a download fails, yt-dlp updates itself once and tries again. */
const withUpdateRetry = async (task) => {
  try {
    return await task();
  } catch (error) {
    if (updatedThisSession || error.message === 'Annulé.') throw error;
    updatedThisSession = true;
    try {
      await run(['-U']);
    } catch {
      throw error;
    }
    return task();
  }
};

export const linkInfo = async (url) => {
  try {
    const json = await withUpdateRetry(() => run(['-J', '--no-playlist', '--no-warnings', url]));
    const info = JSON.parse(json);
    return { title: info.title || info.id || 'Vidéo', seconds: Number(info.duration) || null, site: info.extractor_key || '', thumbnail: info.thumbnail || '' };
  } catch (error) {
    throw explain(error);
  }
};

/** Downloads the best sound of the video into dir; returns the downloaded file. */
export const downloadAudio = async (url, dir, { onProgress = () => {}, signal } = {}) => {
  fs.mkdirSync(dir, { recursive: true });
  const template = path.join(dir, 'source.%(ext)s');
  try {
    const out = await withUpdateRetry(() =>
      run(['-f', 'bestaudio/best', '--no-playlist', '--no-warnings', '--newline', '--progress', '--no-part', '--progress-template', 'download:JTP %(progress.downloaded_bytes)s %(progress.total_bytes,progress.total_bytes_estimate)s', '-o', template, '--print', 'after_move:filepath', url], {
        signal,
        onLine: (line) => {
          const m = /^JTP (\d+) (\d+|NA)/.exec(line);
          if (m) onProgress({ received: Number(m[1]), total: m[2] === 'NA' ? 0 : Number(m[2]) });
        },
      }),
    );
    const file = out.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('JTP')).pop();
    if (file && fs.existsSync(file)) return file;
    const fallback = fs.readdirSync(dir).find((name) => name.startsWith('source.'));
    if (fallback) return path.join(dir, fallback);
    throw new Error('Le fichier téléchargé est introuvable.');
  } catch (error) {
    if (error.message === 'Annulé.') throw error;
    throw explain(error);
  }
};
