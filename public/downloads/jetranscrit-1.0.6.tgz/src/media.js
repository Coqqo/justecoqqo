// Getting the sound out of any video or audio file, with ffmpeg.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';

export const RATE = 16_000;

const locateOnPath = (command) => {
  const finder = process.platform === 'win32' ? 'where' : 'which';
  const result = spawnSync(finder, [command], { encoding: 'utf8', windowsHide: true });
  if (result.status !== 0) return null;
  return result.stdout.split(/\r?\n/).map((line) => line.trim()).find((line) => line && fs.existsSync(line)) || null;
};

const KNOWN = ['C:\\ffmpeg\\bin\\ffmpeg.exe', 'C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe', '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg'];

let ffmpegPath;
export const findFfmpeg = () => {
  if (ffmpegPath) return ffmpegPath;
  const fromEnv = process.env.JETRANSCRIT_FFMPEG && fs.existsSync(process.env.JETRANSCRIT_FFMPEG) ? process.env.JETRANSCRIT_FFMPEG : null;
  ffmpegPath = fromEnv || locateOnPath('ffmpeg') || KNOWN.find((p) => fs.existsSync(p)) || null;
  return ffmpegPath;
};

const parseClock = (value) => {
  const match = /(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(value || '');
  return match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) : null;
};

/** Length of a media file in seconds (null when ffmpeg cannot tell). */
export const probeDuration = (file) =>
  new Promise((resolve) => {
    const ffmpeg = findFfmpeg();
    if (!ffmpeg) return resolve(null);
    const child = spawn(ffmpeg, ['-hide_banner', '-nostdin', '-i', file], { windowsHide: true });
    let err = '';
    child.stderr.on('data', (chunk) => (err += chunk));
    child.on('error', () => resolve(null));
    child.on('close', () => {
      const duration = parseClock(/Duration:\s*([\d:.]+)/.exec(err)?.[1]);
      const hasAudio = /Stream #\S+.*Audio:/.test(err);
      resolve(duration === null ? null : { seconds: duration, hasAudio });
    });
  });

/**
 * Writes the first sound track of a file as raw 16 kHz mono 16-bit samples.
 * onProgress(seconds done) is called while ffmpeg works. Returns a handle with .promise and .cancel().
 */
export const extractPcm = (input, output, { onProgress = () => {}, startSec = 0, durationSec = 0 } = {}) => {
  const ffmpeg = findFfmpeg();
  if (!ffmpeg) throw new Error('ffmpeg est introuvable : réinstalle jetranscris depuis justecoqqo.fr.');
  const args = ['-hide_banner', '-nostdin', '-loglevel', 'error', '-progress', 'pipe:2', '-y'];
  if (startSec) args.push('-ss', String(startSec));
  args.push('-i', input);
  if (durationSec) args.push('-t', String(durationSec));
  args.push('-map', '0:a:0', '-vn', '-sn', '-dn', '-ac', '1', '-ar', String(RATE), '-acodec', 'pcm_s16le', '-f', 's16le', output);
  const child = spawn(ffmpeg, args, { windowsHide: true });
  let errors = '';
  const promise = new Promise((resolve, reject) => {
    child.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      const us = /out_time_us=(\d+)/.exec(text);
      if (us) onProgress(Number(us[1]) / 1e6);
      else errors += text;
      if (errors.length > 4000) errors = errors.slice(-4000);
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0 && fs.existsSync(output) && fs.statSync(output).size > 0) return resolve(output);
      if (/does not contain any stream|matches no streams/i.test(errors)) return reject(Object.assign(new Error('Ce fichier ne contient pas de son.'), { code: 'no-audio' }));
      if (/no space left/i.test(errors)) return reject(Object.assign(new Error('Plus assez de place sur ton disque.'), { code: 'disk-full' }));
      reject(code === null ? new Error('Annulé.') : Object.assign(new Error('Impossible de lire le son de ce fichier.'), { code: 'unreadable' }));
    });
  });
  return { promise, cancel: () => child.kill() };
};

/** Raw samples (Int16Array) of a whole file, kept in memory: used for the clips of a timeline. */
export const decodeToMemory = (file) =>
  new Promise((resolve, reject) => {
    const ffmpeg = findFfmpeg();
    if (!ffmpeg) return reject(new Error('ffmpeg introuvable.'));
    const args = ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', file, '-map', '0:a:0?', '-vn', '-sn', '-dn', '-ac', '1', '-ar', String(RATE), '-acodec', 'pcm_s16le', '-f', 's16le', 'pipe:1'];
    const child = spawn(ffmpeg, args, { windowsHide: true });
    const chunks = [];
    let size = 0;
    child.stdout.on('data', (chunk) => {
      chunks.push(chunk);
      size += chunk.length;
    });
    child.stderr.on('data', () => {});
    child.on('error', reject);
    child.on('close', () => {
      const buffer = Buffer.concat(chunks, size);
      const samples = new Int16Array(Math.floor(buffer.length / 2));
      new Uint8Array(samples.buffer).set(buffer.subarray(0, samples.length * 2));
      resolve(samples);
    });
  });

/** Writes a mix (Float32, any scale) to a raw 16-bit file, normalised so quiet edits are loud enough. */
export const writeMix = (mix, output) => {
  let peak = 1;
  for (let i = 0; i < mix.length; i++) {
    const v = Math.abs(mix[i]);
    if (v > peak) peak = v;
  }
  const gain = Math.min(4, (0.89 * 32767) / peak);
  const fd = fs.openSync(output, 'w');
  try {
    const chunk = 1 << 20;
    for (let start = 0; start < mix.length; start += chunk) {
      const end = Math.min(mix.length, start + chunk);
      const out = Buffer.alloc((end - start) * 2);
      for (let i = start; i < end; i++) out.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(mix[i] * gain))), (i - start) * 2);
      fs.writeSync(fd, out);
    }
  } finally {
    fs.closeSync(fd);
  }
  return output;
};

/** The 44-byte header of a 16-bit mono WAV file holding `samples` samples. */
export const wavHeader = (samples) => {
  const header = Buffer.alloc(44);
  const dataSize = samples * 2;
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(RATE, 24);
  header.writeUInt32LE(RATE * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);
  return header;
};
