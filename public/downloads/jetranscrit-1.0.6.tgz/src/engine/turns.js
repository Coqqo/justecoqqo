// Turning raw "who speaks when" segments into clean turns and transcription units.

const MAX_UNIT_SEC = 25; // Whisper reads 30 s at a time: units stay below
const JOIN_GAP_SEC = 0.8;

/**
 * Removes the small bits that are almost entirely covered by another voice (a "hm" over someone
 * talking) and makes the remaining turns follow each other without overlap.
 */
export const cleanTurns = (segments) => {
  const sorted = [...segments].filter((s) => s.end - s.start >= 0.15).sort((a, b) => a.start - b.start || b.end - a.end);
  const kept = sorted.filter((s) => {
    const length = s.end - s.start;
    if (length >= 1.2) return true;
    let covered = 0;
    for (const other of sorted) {
      if (other === s || other.speaker === s.speaker) continue;
      covered += Math.max(0, Math.min(s.end, other.end) - Math.max(s.start, other.start));
    }
    return covered / length < 0.6;
  });
  const out = [];
  for (const s of kept) {
    const previous = out[out.length - 1];
    if (previous && s.start < previous.end) {
      if (previous.speaker === s.speaker) {
        previous.end = Math.max(previous.end, s.end);
        continue;
      }
      // overlap between two voices: the cut goes in the middle of the overlap
      const middle = (s.start + Math.min(previous.end, s.end)) / 2;
      previous.end = middle;
      const next = { ...s, start: middle };
      if (next.end - next.start < 0.2) continue;
      out.push(next);
      continue;
    }
    out.push({ ...s });
  }
  return out.filter((s) => s.end - s.start >= 0.2);
};

const cosine = (a, b) => {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return dot / (Math.sqrt(na * nb) || 1);
};

export const SAME_VOICE = 0.55;

/**
 * Merges the voices found in each block into voices of the whole video (average-linkage
 * clustering on the voice prints). wanted > 0 forces that number of voices.
 * @returns {Map<string, number>} local key → global voice
 */
export const assignGlobalSpeakers = (locals, { wanted = 0, threshold = SAME_VOICE } = {}) => {
  const withPrint = locals.filter((l) => l.embedding);
  let clusters = withPrint.map((l, index) => ({ id: index, members: [l], seconds: l.seconds }));
  const similarity = (x, y) => {
    let sum = 0;
    let weight = 0;
    for (const a of x.members) {
      for (const b of y.members) {
        const w = Math.min(a.seconds, b.seconds) + 1;
        sum += cosine(a.embedding, b.embedding) * w;
        weight += w;
      }
    }
    return sum / weight;
  };
  while (clusters.length > 1) {
    let best = null;
    for (let i = 0; i < clusters.length; i++) {
      for (let j = i + 1; j < clusters.length; j++) {
        const score = similarity(clusters[i], clusters[j]);
        if (!best || score > best.score) best = { i, j, score };
      }
    }
    const mustMerge = wanted > 0 && clusters.length > wanted;
    if (!mustMerge && (wanted > 0 || best.score < threshold)) break;
    const [a, b] = [clusters[best.i], clusters[best.j]];
    clusters = clusters.filter((_, index) => index !== best.i && index !== best.j);
    clusters.push({ id: a.id, members: [...a.members, ...b.members], seconds: a.seconds + b.seconds });
  }
  // a "voice" heard less than 3 s in the whole video is most likely a bit of another one
  if (!wanted && clusters.length > 1) {
    const total = clusters.reduce((sum, c) => sum + c.seconds, 0);
    for (const small of clusters.filter((c) => c.seconds < Math.min(3, total * 0.05))) {
      const others = clusters.filter((c) => c !== small && c.seconds >= small.seconds);
      if (!others.length) continue;
      const target = others.reduce((best, c) => (similarity(small, c) > similarity(small, best) ? c : best));
      target.members.push(...small.members);
      target.seconds += small.seconds;
      clusters = clusters.filter((c) => c !== small);
    }
  }
  const mapping = new Map();
  clusters.forEach((cluster, index) => {
    for (const member of cluster.members) mapping.set(member.key, index);
  });
  // a voice too short for a voice print joins the voice speaking next to it (filled in by the caller)
  for (const l of locals) if (!mapping.has(l.key)) mapping.set(l.key, nearestByBlock(l.key, mapping));
  return mapping;
};

const nearestByBlock = (key, mapping) => {
  const block = key.split(':')[0];
  for (const [other, value] of mapping) if (other.split(':')[0] === block) return value;
  return 0;
};

/** Joins the consecutive turns of the same voice into units Whisper can read in one go. */
export const buildUnits = (turns) => {
  const units = [];
  for (const turn of [...turns].sort((a, b) => a.start - b.start)) {
    const last = units[units.length - 1];
    if (last && last.speaker === turn.speaker && turn.start - last.end <= JOIN_GAP_SEC && turn.end - last.start <= MAX_UNIT_SEC) {
      last.end = Math.max(last.end, turn.end);
    } else {
      units.push({ start: turn.start, end: turn.end, speaker: turn.speaker });
    }
  }
  return units;
};

/** Cuts the units longer than Whisper's window at their quietest moment. */
export const splitAtQuietPoints = (units, readAudio) => {
  const out = [];
  const queue = [...units];
  while (queue.length) {
    const unit = queue.shift();
    if (unit.end - unit.start <= MAX_UNIT_SEC + 3) {
      out.push(unit);
      continue;
    }
    const from = unit.start + 12;
    const to = unit.start + MAX_UNIT_SEC;
    const samples = readAudio(from, to);
    const frame = 1600; // 100 ms
    let quietest = { at: to, energy: Infinity };
    for (let i = 0; i + frame <= samples.length; i += frame / 2) {
      let energy = 0;
      for (let k = i; k < i + frame; k++) energy += samples[k] * samples[k];
      if (energy < quietest.energy) quietest = { at: from + (i + frame / 2) / 16000, energy };
    }
    out.push({ ...unit, end: quietest.at });
    queue.unshift({ ...unit, start: quietest.at });
  }
  return out;
};
