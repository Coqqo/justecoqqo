// Cleans what Whisper returns: loops, credits it sometimes invents, stray symbols.

const INVENTED = [
  /sous-titr(age|es|é)[^.]*(amara|communaut|radio-canada|st'?\s?\d+)[^.]*\.?/gi,
  /merci d'avoir regard[ée] cette vid[ée]o ?!?/gi,
  /abonnez-vous[^.]*\.?/gi,
  /subtitles by the amara\.org community/gi,
  /thanks? for watching!?/gi,
];

/** Collapses a sentence or a word repeated over and over (a classic Whisper hiccup). */
const collapseLoops = (text) => {
  const words = text.split(' ');
  const key = (w) => w.toLowerCase().replace(/[.,!?;:…]+$/, '');
  const out = [];
  let i = 0;
  while (i < words.length) {
    let skipped = false;
    // the same group of 1 to 12 words repeated 3 times or more in a row is kept once
    for (let n = 1; n <= 12 && !skipped; n++) {
      if (i + n * 3 > words.length) break;
      const group = words.slice(i, i + n).map(key).join(' ');
      let repeats = 1;
      while (i + n * (repeats + 1) <= words.length && words.slice(i + n * repeats, i + n * (repeats + 1)).map(key).join(' ') === group) repeats += 1;
      if (repeats >= (n === 1 ? 4 : 3)) {
        out.push(...words.slice(i + n * (repeats - 1), i + n * repeats));
        i += n * repeats;
        skipped = true;
      }
    }
    if (!skipped) out.push(words[i++]);
  }
  return out.join(' ');
};

export const cleanText = (raw, seconds) => {
  let text = String(raw || '').replace(/\s+/g, ' ').trim();
  text = collapseLoops(text);
  // the credits are only removed from short bits: in a real sentence they may be genuine
  if (seconds < 8) for (const pattern of INVENTED) text = text.replace(pattern, ' ');
  text = text.replace(/\s+/g, ' ').trim();
  if (!/[\p{L}\p{N}]/u.test(text)) return '';
  // a lone "euh" or "hum" is not worth a line
  if (/^(uh+|um+|euh+|heu+|hum+|hm+|mm+|ah+|oh+|eh+)[\s.,!?…]*$/i.test(text)) return '';
  return text;
};
