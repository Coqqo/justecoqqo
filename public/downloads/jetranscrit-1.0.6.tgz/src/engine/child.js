// The transcription engine runs in a separate process: the models (≈ 1 Go in memory) are released
// as soon as it ends, and cancelling simply stops the process.
import { transcribe } from './engine.js';

process.once('message', async (input) => {
  await transcribe(input, (message) => process.send(message));
  process.send({ type: 'end' }, () => process.exit(0));
});
