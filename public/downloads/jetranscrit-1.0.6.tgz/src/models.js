// The speech models (≈ 600 Mo to download once, ≈ 1,1 Go on disk): Whisper "turbo" for the text,
// pyannote + ERes2Net to tell the voices apart, Silero for single-voice videos.
// The list can be updated from the site without a new version of the app.
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createRequire } from 'node:module';
import { coded, ensureSpace, explainFsError } from './errors.js';
import { subDir } from './paths.js';

const require = createRequire(import.meta.url);
const GH = 'https://github.com/k2-fsa/sherpa-onnx/releases/download';

export const DEFAULT_CATALOG = {
  version: 1,
  packs: [
    {
      id: 'whisper-turbo',
      label: 'Transcription (Whisper)',
      url: `${GH}/asr-models/sherpa-onnx-whisper-turbo.tar.bz2`,
      sha256: 'b11acbbcd660b44a8e0df33724feb5aaa709cf65668f2823d59f656312544f22',
      size: 563790207,
      archive: 'tar.bz2',
      files: {
        encoder: 'sherpa-onnx-whisper-turbo/turbo-encoder.int8.onnx',
        decoder: 'sherpa-onnx-whisper-turbo/turbo-decoder.int8.onnx',
        tokens: 'sherpa-onnx-whisper-turbo/turbo-tokens.txt',
      },
    },
    {
      id: 'segmentation',
      label: 'Détection des voix',
      url: `${GH}/speaker-segmentation-models/sherpa-onnx-pyannote-segmentation-3-0.tar.bz2`,
      sha256: '24615ee884c897d9d2ba09bb4d30da6bb1b15e685065962db5b02e76e4996488',
      size: 6958444,
      archive: 'tar.bz2',
      files: { segmentation: 'sherpa-onnx-pyannote-segmentation-3-0/model.int8.onnx' },
    },
    {
      id: 'embedding',
      label: 'Empreinte des voix',
      url: `${GH}/speaker-recongition-models/3dspeaker_speech_eres2net_sv_en_voxceleb_16k.onnx`,
      sha256: 'c59158379255ad66e161679cca6af8d52d51e389e3224ab7d7a7baae295c2db5',
      size: 26485263,
      archive: 'none',
      files: { embedding: '3dspeaker_speech_eres2net_sv_en_voxceleb_16k.onnx' },
    },
    {
      id: 'vad',
      label: 'Détection de la parole',
      url: `${GH}/asr-models/silero_vad.onnx`,
      sha256: '9e2449e1087496d8d4caba907f23e0bd3f78d91fa552479bb9c23ac09cbb1fd6',
      size: 643854,
      archive: 'none',
      files: { vad: 'silero_vad.onnx' },
    },
  ],
};

const CATALOG_URL = 'https://justecoqqo.fr/jetranscrit/models.json';
const modelsDir = () => process.env.JETRANSCRIT_MODELS_DIR || subDir('models');
const packDir = (pack) => path.join(modelsDir(), `${pack.id}-${pack.sha256.slice(0, 10)}`);

let catalog = DEFAULT_CATALOG;
/** Takes the list from the site when it can be reached (and is well-formed). */
export const refreshCatalog = async () => {
  try {
    const response = await fetch(CATALOG_URL, { signal: AbortSignal.timeout(5000), cache: 'no-store' });
    if (!response.ok) return catalog;
    const remote = await response.json();
    const valid = Array.isArray(remote?.packs) && remote.packs.every((p) => /^[a-z0-9-]+$/.test(p.id) && /^https:\/\//.test(p.url) && /^[0-9a-f]{64}$/.test(p.sha256) && p.files);
    if (valid) catalog = remote;
  } catch {
    /* offline: the built-in list is used */
  }
  return catalog;
};

/** Paths of every model file when they are all on the computer, else null. */
export const installedModels = () => {
  if (process.env.JETRANSCRIT_MODELS_FLAT) {
    // development: a flat folder with the files under their usual names
    const flat = process.env.JETRANSCRIT_MODELS_FLAT;
    return {
      encoder: path.join(flat, 'turbo-encoder.int8.onnx'),
      decoder: path.join(flat, 'turbo-decoder.int8.onnx'),
      tokens: path.join(flat, 'turbo-tokens.txt'),
      segmentation: path.join(flat, 'seg.int8.onnx'),
      embedding: path.join(flat, '3dspeaker_speech_eres2net_sv_en_voxceleb_16k.onnx'),
      vad: path.join(flat, 'silero_vad.onnx'),
    };
  }
  const files = {};
  for (const pack of catalog.packs) {
    const dir = packDir(pack);
    if (!fs.existsSync(path.join(dir, '.complete'))) return null;
    for (const [key, relative] of Object.entries(pack.files)) {
      const full = path.join(dir, relative);
      if (!fs.existsSync(full)) return null;
      files[key] = full;
    }
  }
  return files;
};

export const missingDownloadBytes = () => catalog.packs.filter((pack) => !fs.existsSync(path.join(packDir(pack), '.complete'))).reduce((sum, p) => sum + (p.size || 0), 0);

const download = async (pack, target, onBytes, signal) => {
  let response;
  try {
    response = await fetch(pack.url, { signal });
  } catch (error) {
    if (signal?.aborted) throw error;
    throw coded('models-download', 'Le moteur de transcription ne se télécharge pas : vérifie ta connexion à internet.');
  }
  if (!response.ok || !response.body) throw coded('models-download', `Le moteur de transcription ne se télécharge pas (erreur ${response.status}).`);
  const hash = crypto.createHash('sha256');
  let received = 0;
  const counter = new TransformStream({
    transform(chunk, controller) {
      received += chunk.length;
      hash.update(chunk);
      onBytes(received);
      controller.enqueue(chunk);
    },
  });
  try {
    await pipeline(Readable.fromWeb(response.body.pipeThrough(counter)), fs.createWriteStream(target), { signal });
  } catch (error) {
    if (signal?.aborted || error?.code === 'ENOSPC') throw explainFsError(error);
    throw coded('models-download', 'Le téléchargement du moteur a été coupé : vérifie ta connexion, puis relance.');
  }
  if (hash.digest('hex') !== pack.sha256) throw coded('models-download', 'Le moteur téléchargé est abîmé (connexion coupée ?) : relance.');
};

const systemTar = () => {
  if (process.platform !== 'win32') return 'tar';
  const windowsTar = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');
  return fs.existsSync(windowsTar) ? windowsTar : null;
};

const extractWithSystemTar = (archive, dir) =>
  new Promise((resolve, reject) => {
    const tar = process.env.JETRANSCRIT_NO_SYSTEM_TAR ? null : systemTar();
    if (!tar) return reject(new Error('no tar'));
    const child = spawn(tar, ['-xjf', archive, '-C', dir], { windowsHide: true });
    child.on('error', reject);
    child.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`tar ${code}`))));
  });

/** Pure JavaScript fallback: bz2 stream → tar entries written to disk. */
const extractWithJs = async (archive, dir) => {
  const bunzip = require('unbzip2-stream');
  let pending = Buffer.alloc(0);
  let current = null; // { stream, remaining, padding }
  const writeEntry = (name, size) => {
    const clean = name.replace(/^\.\//, '');
    const full = path.resolve(dir, clean);
    if (!full.startsWith(path.resolve(dir) + path.sep)) throw new Error('Archive invalide.');
    fs.mkdirSync(path.dirname(full), { recursive: true });
    return { fd: fs.openSync(full, 'w'), remaining: size, padding: (512 - (size % 512)) % 512 };
  };
  const consume = () => {
    for (;;) {
      if (current) {
        if (current.remaining > 0) {
          const take = Math.min(current.remaining, pending.length);
          if (!take) return;
          fs.writeSync(current.fd, pending, 0, take);
          pending = pending.subarray(take);
          current.remaining -= take;
          if (current.remaining > 0) return;
        }
        if (pending.length < current.padding) return;
        pending = pending.subarray(current.padding);
        fs.closeSync(current.fd);
        current = null;
      }
      if (pending.length < 512) return;
      const header = pending.subarray(0, 512);
      pending = pending.subarray(512);
      if (header.every((b) => b === 0)) continue;
      const name = (header.subarray(345, 500).toString('utf8').replace(/\0.*$/s, '') ? `${header.subarray(345, 500).toString('utf8').replace(/\0.*$/s, '')}/` : '') + header.subarray(0, 100).toString('utf8').replace(/\0.*$/s, '');
      const size = parseInt(header.subarray(124, 136).toString('utf8').replace(/\0.*$/s, '').trim() || '0', 8);
      const type = String.fromCharCode(header[156] || 48);
      if (type === '0' || type === '\0') current = writeEntry(name, size);
      else current = { fd: fs.openSync(process.platform === 'win32' ? 'NUL' : '/dev/null', 'w'), remaining: size, padding: (512 - (size % 512)) % 512 };
    }
  };
  await new Promise((resolve, reject) => {
    fs.createReadStream(archive)
      .pipe(bunzip())
      .on('data', (chunk) => {
        try {
          pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
          consume();
        } catch (error) {
          reject(error);
        }
      })
      .on('error', reject)
      .on('end', resolve);
  });
  if (current) fs.closeSync(current.fd);
};

/**
 * Downloads and unpacks what is missing. onProgress({ label, received, total, phase }).
 */
export const ensureModels = async ({ onProgress = () => {}, signal } = {}) => {
  if (installedModels()) return installedModels();
  await refreshCatalog();
  const missing = catalog.packs.filter((pack) => !fs.existsSync(path.join(packDir(pack), '.complete')));
  const total = missing.reduce((sum, p) => sum + (p.size || 0), 0);
  // the archive and what comes out of it are on the disk together for a moment
  ensureSpace(modelsDir(), total * 2.2 + 200e6);
  let before = 0;
  for (const pack of missing) {
    const dir = packDir(pack);
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, pack.archive === 'none' ? Object.values(pack.files)[0] : 'download.tar.bz2');
    await download(pack, file, (received) => onProgress({ phase: 'download', label: pack.label, received: before + received, total }), signal);
    if (pack.archive === 'tar.bz2') {
      onProgress({ phase: 'unpack', label: pack.label, received: before + pack.size, total });
      try {
        await extractWithSystemTar(file, dir);
      } catch {
        try {
          await extractWithJs(file, dir);
        } catch (error) {
          throw explainFsError(error);
        }
      }
      fs.rmSync(file, { force: true });
    }
    fs.writeFileSync(path.join(dir, '.complete'), new Date().toISOString());
    before += pack.size || 0;
  }
  // older versions of the models are removed
  const keep = new Set(catalog.packs.map((pack) => path.basename(packDir(pack))));
  for (const name of fs.readdirSync(modelsDir())) if (!keep.has(name)) fs.rmSync(path.join(modelsDir(), name), { recursive: true, force: true });
  const ready = installedModels();
  if (!ready) throw coded('models-download', 'Le moteur de transcription est incomplet : relance.');
  return ready;
};
