// Premiere Pro projects (.prproj: gzipped XML). Found on the computer, read without being modified.
// A sequence is transcribed as it sounds: every audio clip of its audio tracks, at its place.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import { decodeToMemory, RATE } from './media.js';

const TICKS_PER_SECOND = 254016000000;
const SKIP_DIRS = new Set(['node_modules', '$recycle.bin', 'appdata', 'library', '.git', 'windows', 'program files', 'program files (x86)']);

/* ------------------------------------------------------------------ finding projects */

const premiereDocumentRoots = () => {
  const home = os.homedir();
  return [path.join(home, 'Documents', 'Adobe', 'Premiere Pro'), path.join(home, 'OneDrive', 'Documents', 'Adobe', 'Premiere Pro')];
};

/** Paths of recent projects written in Premiere's preference files. */
const recentFromPrefs = () => {
  const found = new Set();
  for (const root of premiereDocumentRoots()) {
    if (!fs.existsSync(root)) continue;
    for (const version of fs.readdirSync(root)) {
      const versionDir = path.join(root, version);
      let profiles = [];
      try {
        profiles = fs.readdirSync(versionDir).filter((name) => name.startsWith('Profile-'));
      } catch {
        continue;
      }
      for (const profile of profiles) {
        const prefs = path.join(versionDir, profile, 'Adobe Premiere Pro Prefs');
        if (!fs.existsSync(prefs)) continue;
        const text = fs.readFileSync(prefs, 'utf8');
        for (const match of text.matchAll(/([A-Za-z]:\\[^<>"|?*\r\n]+?\.prproj|\/[^<>"|?*\r\n]+?\.prproj)/gi)) found.add(match[1].replace(/&amp;/g, '&'));
      }
    }
  }
  return [...found];
};

const scanFolder = (dir, depth, out, limit = 400) => {
  if (depth < 0 || out.length >= limit) return;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (out.length >= limit) return;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const lower = entry.name.toLowerCase();
      if (lower.startsWith('.') || SKIP_DIRS.has(lower) || lower.includes('auto-save')) continue;
      scanFolder(full, depth - 1, out, limit);
    } else if (entry.name.toLowerCase().endsWith('.prproj')) out.push(full);
  }
};

export const listPremiereProjects = (extraDirs = []) => {
  const home = os.homedir();
  const found = new Set(recentFromPrefs().filter((file) => fs.existsSync(file)));
  const scanned = [];
  for (const dir of [...premiereDocumentRoots(), path.join(home, 'Desktop'), path.join(home, 'Documents'), path.join(home, 'Videos'), path.join(home, 'Movies'), ...extraDirs]) {
    if (fs.existsSync(dir)) scanFolder(dir, 5, scanned);
  }
  for (const file of scanned) found.add(file);
  return [...found]
    .map((file) => {
      try {
        const stat = fs.statSync(file);
        return { id: file, name: path.basename(file, path.extname(file)), folder: path.dirname(file), modifiedMs: stat.mtimeMs };
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .sort((a, b) => b.modifiedMs - a.modifiedMs);
};

/* ------------------------------------------------------------------ reading a project */

/** Indexes the top-level objects of the XML (they point to each other with ObjectRef / ObjectURef). */
const indexObjects = (xml) => {
  const byId = new Map();
  const opening = /<([A-Za-z][\w.]*)\s+Object(U?)ID="([^"]+)"[^>]*?(\/?)>/g;
  let match;
  while ((match = opening.exec(xml))) {
    const [whole, tag, , id, selfClosing] = match;
    if (selfClosing) {
      byId.set(id, { tag, body: '' });
      continue;
    }
    // find the matching closing tag (same tag name may nest)
    let depth = 1;
    const re = new RegExp(`<(/?)${tag.replace(/\./g, '\\.')}(?=[\\s>/])[^>]*?(/?)>`, 'g');
    re.lastIndex = match.index + whole.length;
    let close;
    let end = xml.length;
    while ((close = re.exec(xml))) {
      if (close[2]) continue;
      depth += close[1] ? -1 : 1;
      if (depth === 0) {
        end = close.index;
        break;
      }
    }
    byId.set(id, { tag, body: xml.slice(match.index + whole.length, end) });
    opening.lastIndex = end;
  }
  return byId;
};

const firstValue = (body, tag) => {
  const m = new RegExp(`<${tag}(?:\\s[^>]*)?>([^<]*)</${tag}>`).exec(body);
  return m ? m[1] : null;
};
const refs = (body, tag) => [...body.matchAll(new RegExp(`<${tag}[^>]*?Object(?:U)?Ref="([^"]+)"`, 'g'))].map((m) => m[1]);
const ref = (body, tag) => refs(body, tag)[0] || null;
const decodeXml = (text) => String(text || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');

export const readPremiereProject = (file) => {
  const raw = fs.readFileSync(file);
  const xml = (raw[0] === 0x1f && raw[1] === 0x8b ? zlib.gunzipSync(raw) : raw).toString('utf8');
  return { file, objects: indexObjects(xml) };
};

export const listSequences = (project) => {
  const sequences = [];
  for (const [id, object] of project.objects) {
    if (object.tag !== 'Sequence') continue;
    const name = decodeXml(firstValue(object.body, 'Name')) || 'Séquence';
    const clips = sequenceAudioClips(project, id, 0);
    if (!clips.length) continue;
    const seconds = clips.reduce((max, c) => Math.max(max, c.end), 0);
    sequences.push({ id, name, seconds, clips: clips.length });
  }
  return sequences.sort((a, b) => b.seconds - a.seconds);
};

const mediaPathOf = (project, mediaId) => {
  const media = project.objects.get(mediaId);
  if (!media) return null;
  const candidates = [firstValue(media.body, 'ActualMediaFilePath'), firstValue(media.body, 'FilePath'), firstValue(media.body, 'RelativePath')].map(decodeXml).filter(Boolean);
  for (const candidate of candidates) {
    const absolute = path.isAbsolute(candidate) ? candidate : path.resolve(path.dirname(project.file), candidate);
    if (fs.existsSync(absolute)) return absolute;
  }
  return candidates[0] || null;
};

/** Audio clips of a sequence: { start, end, inPoint (seconds), speed, file | nested sequence id }. */
const sequenceAudioClips = (project, sequenceId, depth) => {
  const sequence = project.objects.get(sequenceId);
  if (!sequence || depth > 3) return [];
  const clips = [];
  for (const groupId of refs(sequence.body, 'Second')) {
    const group = project.objects.get(groupId);
    if (!group || group.tag !== 'AudioTrackGroup') continue;
    for (const trackId of refs(group.body, 'Track')) {
      const track = project.objects.get(trackId);
      if (!track || !/AudioClipTrack/.test(track.tag)) continue;
      if (/<IsMuted>true<\/IsMuted>/.test(track.body)) continue;
      for (const itemId of refs(track.body, 'TrackItem')) {
        const item = project.objects.get(itemId);
        if (!item || !/AudioClipTrackItem/.test(item.tag)) continue;
        if (/<Disabled>true<\/Disabled>/.test(item.body)) continue;
        const start = Number(firstValue(item.body, 'Start') || 0) / TICKS_PER_SECOND;
        const end = Number(firstValue(item.body, 'End') || 0) / TICKS_PER_SECOND;
        const subClip = project.objects.get(ref(item.body, 'SubClip'));
        const clip = subClip && project.objects.get(ref(subClip.body, 'Clip'));
        if (!clip || end <= start) continue;
        const inPoint = Number(firstValue(clip.body, 'InPoint') || 0) / TICKS_PER_SECOND;
        const speed = Math.abs(Number(firstValue(clip.body, 'PlaybackSpeed') || 1)) || 1;
        const source = project.objects.get(ref(clip.body, 'Source'));
        if (!source) continue;
        const nestedSequence = ref(source.body, 'Sequence');
        if (/SequenceSource/.test(source.tag) && nestedSequence) {
          clips.push({ start, end, inPoint, speed, nested: nestedSequence });
          continue;
        }
        const mediaId = ref(source.body, 'Media');
        const file = mediaId && mediaPathOf(project, mediaId);
        if (file) clips.push({ start, end, inPoint, speed, file });
      }
    }
  }
  return clips;
};

const renderSequence = async (project, sequenceId, ctx, depth) => {
  const clips = sequenceAudioClips(project, sequenceId, depth);
  const seconds = clips.reduce((max, c) => Math.max(max, c.end), 0);
  const mix = new Float32Array(Math.max(1, Math.ceil(seconds * RATE)));
  for (const clip of clips) {
    let source;
    if (clip.nested) {
      source = await renderSequence(project, clip.nested, ctx, depth + 1);
    } else {
      if (!fs.existsSync(clip.file)) {
        ctx.missing.add(path.basename(clip.file));
        continue;
      }
      ctx.onFile(path.basename(clip.file));
      source = await ctx.source(clip.file);
    }
    const first = Math.round(clip.start * RATE);
    const last = Math.min(mix.length, Math.round(clip.end * RATE));
    const sourceStart = clip.inPoint * RATE;
    for (let i = first; i < last; i++) {
      const j = Math.floor(sourceStart + (i - first) * clip.speed);
      if (j >= 0 && j < source.length) mix[i] += source[j];
    }
  }
  return mix;
};

export const renderPremiereMix = async (file, sequenceId, { onFile = () => {} } = {}) => {
  const project = readPremiereProject(file);
  const decoded = new Map();
  const ctx = {
    missing: new Set(),
    onFile,
    source: (media) => {
      if (!decoded.has(media)) decoded.set(media, decodeToMemory(media));
      return decoded.get(media);
    },
  };
  const sequence = project.objects.get(sequenceId);
  if (!sequence) throw new Error('Séquence introuvable dans ce projet.');
  const mix = await renderSequence(project, sequenceId, ctx, 0);
  return { mix, name: `${path.basename(file, '.prproj')} · ${decodeXml(firstValue(sequence.body, 'Name')) || 'Séquence'}`, missing: [...ctx.missing] };
};
