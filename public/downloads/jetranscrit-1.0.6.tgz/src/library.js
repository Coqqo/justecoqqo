// The transcriptions saved on the computer: one folder each (sound, text, voices).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { subDir } from './paths.js';

export const VOICE_COLORS = ['#ff6b4a', '#4a8bff', '#2fbf8f', '#b06bff', '#f2b33d', '#ff5fa2', '#3fc4d9', '#8a9a3c', '#e0703a', '#6d7cff'];

const root = () => subDir('transcriptions');
const isSafeId = (id) => typeof id === 'string' && /^[a-z0-9-]{8,40}$/.test(id);
export const folderOf = (id) => {
  if (!isSafeId(id)) throw new Error('Transcription introuvable.');
  return path.join(root(), id);
};

const readJson = (file, fallback = null) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
};

const writeJson = (file, value) => {
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value));
  fs.renameSync(temp, file);
};

export const createEntry = ({ title, source, options }) => {
  const id = `${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
  const dir = folderOf(id);
  fs.mkdirSync(dir, { recursive: true });
  const meta = { id, title: title || 'Sans titre', source, options, createdAt: Date.now(), status: 'queued', seconds: null, speakerCount: null, language: null, error: null };
  writeJson(path.join(dir, 'meta.json'), meta);
  return meta;
};

export const readMeta = (id) => readJson(path.join(folderOf(id), 'meta.json'));

export const updateMeta = (id, patch) => {
  const meta = { ...readMeta(id), ...patch };
  writeJson(path.join(folderOf(id), 'meta.json'), meta);
  return meta;
};

export const listEntries = () => {
  if (!fs.existsSync(root())) return [];
  return fs
    .readdirSync(root())
    .filter(isSafeId)
    .map((id) => readJson(path.join(root(), id, 'meta.json')))
    .filter(Boolean)
    .sort((a, b) => b.createdAt - a.createdAt);
};

export const audioFileOf = (id) => path.join(folderOf(id), 'audio.pcm');

export const saveResult = (id, result) => {
  const speakers = Array.from({ length: Math.max(1, result.speakerCount) }, (_, index) => ({ id: index, name: `Voix ${index + 1}`, color: VOICE_COLORS[index % VOICE_COLORS.length] }));
  const transcript = {
    speakers,
    segments: result.segments.map((s, index) => ({ id: `s${index}`, start: s.start, end: s.end, speaker: s.speaker, text: s.text })),
    language: result.language,
  };
  writeJson(path.join(folderOf(id), 'transcript.json'), transcript);
  return updateMeta(id, { status: 'done', seconds: result.seconds, speakerCount: speakers.length, language: result.language, detectedLanguage: result.detectedLanguage || '', elapsedMs: result.elapsedMs, finishedAt: Date.now(), error: null });
};

export const readTranscript = (id) => {
  const meta = readMeta(id);
  const transcript = readJson(path.join(folderOf(id), 'transcript.json'));
  if (!meta || !transcript) throw new Error('Transcription introuvable.');
  return { ...transcript, id, title: meta.title, meta };
};

/** Saves the corrections made in the editor (text, voices, names). */
export const saveTranscript = (id, { speakers, segments, title }) => {
  const current = readTranscript(id);
  const cleanSpeakers = (Array.isArray(speakers) ? speakers : current.speakers)
    .filter((s) => Number.isInteger(s.id) && s.id >= 0 && s.id < 100)
    .map((s) => ({ id: s.id, name: String(s.name || `Voix ${s.id + 1}`).slice(0, 60), color: /^#[0-9a-f]{6}$/i.test(s.color) ? s.color : VOICE_COLORS[s.id % VOICE_COLORS.length] }));
  const known = new Set(cleanSpeakers.map((s) => s.id));
  const cleanSegments = (Array.isArray(segments) ? segments : current.segments)
    .filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end) && known.has(s.speaker))
    .map((s, index) => ({ id: typeof s.id === 'string' ? s.id.slice(0, 20) : `s${index}`, start: s.start, end: s.end, speaker: s.speaker, text: String(s.text || '').slice(0, 20000) }))
    .sort((a, b) => a.start - b.start);
  writeJson(path.join(folderOf(id), 'transcript.json'), { speakers: cleanSpeakers, segments: cleanSegments, language: current.language });
  const patch = { speakerCount: cleanSpeakers.length, editedAt: Date.now() };
  if (typeof title === 'string' && title.trim()) patch.title = title.trim().slice(0, 120);
  updateMeta(id, patch);
  return readTranscript(id);
};

export const removeEntry = (id) => fs.rmSync(folderOf(id), { recursive: true, force: true });
