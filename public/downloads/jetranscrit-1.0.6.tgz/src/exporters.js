// Turning a transcript into files: text, subtitles (SRT, VTT), Word, CSV, JSON.
import zlib from 'node:zlib';

const pad = (n, width = 2) => String(Math.floor(n)).padStart(width, '0');

export const clock = (seconds, { ms = false, separator = ',' } = {}) => {
  const s = Math.max(0, seconds);
  const base = `${pad(s / 3600)}:${pad((s % 3600) / 60)}:${pad(s % 60)}`;
  return ms ? `${base}${separator}${pad(Math.round((s % 1) * 1000) % 1000, 3)}` : base;
};

const shortClock = (seconds) => (seconds >= 3600 ? clock(seconds) : `${pad(seconds / 60)}:${pad(seconds % 60)}`);

const speakerName = (transcript, id) => transcript.speakers.find((s) => s.id === id)?.name || `Voix ${id + 1}`;

/** The segments to export: all, or only those of some voices. */
const pick = (transcript, speakers) => {
  const wanted = Array.isArray(speakers) && speakers.length ? new Set(speakers) : null;
  return transcript.segments.filter((s) => s.text.trim() && (!wanted || wanted.has(s.speaker)));
};

/** Consecutive segments of the same voice read as one paragraph. */
const paragraphs = (segments) => {
  const out = [];
  for (const s of segments) {
    const last = out[out.length - 1];
    if (last && last.speaker === s.speaker && s.start - last.end < 4) {
      last.text += ` ${s.text.trim()}`;
      last.end = s.end;
    } else out.push({ speaker: s.speaker, start: s.start, end: s.end, text: s.text.trim() });
  }
  return out;
};

export const toText = (transcript, { speakers, names = true, times = true } = {}) => {
  const segments = pick(transcript, speakers);
  const single = new Set(segments.map((s) => s.speaker)).size <= 1;
  return (
    paragraphs(segments)
      .map((p) => {
        const head = [times ? `[${shortClock(p.start)}]` : '', names && !single ? `${speakerName(transcript, p.speaker)} :` : ''].filter(Boolean).join(' ');
        return head ? `${head} ${p.text}` : p.text;
      })
      .join('\n\n') + '\n'
  );
};

/** Splits a segment into subtitle cues of at most two lines, timed by the length of the text. */
const cues = (segments, maxLine = 42) => {
  const out = [];
  for (const s of segments) {
    const words = s.text.trim().split(/\s+/);
    const chunks = [];
    let lines = [''];
    for (const word of words) {
      const line = lines[lines.length - 1];
      if ((line ? `${line} ${word}` : word).length <= maxLine) lines[lines.length - 1] = line ? `${line} ${word}` : word;
      else if (lines.length < 2) lines.push(word);
      else {
        chunks.push(lines);
        lines = [word];
      }
    }
    if (lines[0]) chunks.push(lines);
    const totalChars = chunks.reduce((sum, c) => sum + c.join(' ').length, 0) || 1;
    let at = s.start;
    for (const chunk of chunks) {
      const length = ((s.end - s.start) * chunk.join(' ').length) / totalChars;
      out.push({ start: at, end: at + length, lines: chunk, speaker: s.speaker });
      at += length;
    }
  }
  return out;
};

export const toSrt = (transcript, { speakers, names = false } = {}) =>
  cues(pick(transcript, speakers))
    .map((c, i) => {
      const prefix = names ? `${speakerName(transcript, c.speaker)} : ` : '';
      return `${i + 1}\n${clock(c.start, { ms: true })} --> ${clock(c.end, { ms: true })}\n${prefix}${c.lines.join('\n')}\n`;
    })
    .join('\n');

export const toVtt = (transcript, { speakers, names = false } = {}) =>
  'WEBVTT\n\n' +
  cues(pick(transcript, speakers))
    .map((c) => {
      const voice = names ? `<v ${speakerName(transcript, c.speaker)}>` : '';
      return `${clock(c.start, { ms: true, separator: '.' })} --> ${clock(c.end, { ms: true, separator: '.' })}\n${voice}${c.lines.join('\n')}\n`;
    })
    .join('\n');

const csvCell = (value) => `"${String(value).replace(/"/g, '""')}"`;
export const toCsv = (transcript, { speakers } = {}) =>
  '﻿' + ['Début;Fin;Voix;Texte', ...pick(transcript, speakers).map((s) => [clock(s.start), clock(s.end), speakerName(transcript, s.speaker), s.text.trim()].map(csvCell).join(';'))].join('\r\n') + '\r\n';

export const toJson = (transcript, { speakers } = {}) =>
  JSON.stringify(
    {
      title: transcript.title,
      language: transcript.language,
      speakers: transcript.speakers.filter((s) => !speakers?.length || speakers.includes(s.id)).map(({ id, name }) => ({ id, name })),
      segments: pick(transcript, speakers).map(({ start, end, speaker, text }) => ({ start, end, speaker: speakerName(transcript, speaker), text })),
    },
    null,
    2,
  );

/* ------------------------------------------------------------------ Word (.docx) */

const xmlEscape = (text) => String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();
const crc32 = (buffer) => {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
};

/** A minimal zip writer (deflate), enough for a .docx. */
export const zip = (files) => {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const data = Buffer.from(content);
    const packed = zlib.deflateRawSync(data);
    const nameBuffer = Buffer.from(name);
    const crc = crc32(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(8, 8);
    local.writeUInt32LE(0, 10);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(packed.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuffer.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, nameBuffer, packed);
    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(8, 10);
    central.writeUInt32LE(0, 12);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(packed.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBuffer.length, 28);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, nameBuffer);
    offset += local.length + nameBuffer.length + packed.length;
  }
  const centralSize = centrals.reduce((sum, b) => sum + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(Object.keys(files).length, 8);
  end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, ...centrals, end]);
};

export const toDocx = (transcript, { speakers, names = true, times = true } = {}) => {
  const segments = pick(transcript, speakers);
  const single = new Set(segments.map((s) => s.speaker)).size <= 1;
  const run = (text, { bold = false, color = '' } = {}) =>
    `<w:r><w:rPr>${bold ? '<w:b/>' : ''}${color ? `<w:color w:val="${color}"/>` : ''}</w:rPr><w:t xml:space="preserve">${xmlEscape(text)}</w:t></w:r>`;
  const body = [
    `<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr>${run(transcript.title || 'Transcription')}</w:p>`,
    ...paragraphs(segments).map((p) => {
      const parts = [];
      if (times) parts.push(run(`[${shortClock(p.start)}] `, { color: '888888' }));
      if (names && !single) {
        const color = (transcript.speakers.find((s) => s.id === p.speaker)?.color || '#333333').replace('#', '');
        parts.push(run(`${speakerName(transcript, p.speaker)} : `, { bold: true, color }));
      }
      parts.push(run(p.text));
      return `<w:p><w:pPr><w:spacing w:after="160"/></w:pPr>${parts.join('')}</w:p>`;
    }),
  ].join('');
  return zip({
    '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
    '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
    'word/_rels/document.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
    'word/styles.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:lang w:val="fr-FR"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:pPr><w:spacing w:after="300"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/></w:rPr></w:style></w:styles>',
    'word/document.xml': `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`,
  });
};

export const FORMATS = {
  txt: { label: 'Texte (.txt)', mime: 'text/plain; charset=utf-8', build: (t, o) => '﻿' + toText(t, o).replace(/\n/g, '\r\n') },
  docx: { label: 'Word (.docx)', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', build: toDocx },
  srt: { label: 'Sous-titres (.srt)', mime: 'application/x-subrip; charset=utf-8', build: toSrt },
  vtt: { label: 'Sous-titres web (.vtt)', mime: 'text/vtt; charset=utf-8', build: toVtt },
  csv: { label: 'Tableur (.csv)', mime: 'text/csv; charset=utf-8', build: toCsv },
  json: { label: 'Données (.json)', mime: 'application/json; charset=utf-8', build: toJson },
};
