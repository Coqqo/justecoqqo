// One transcription at a time: get the sound, get the models if needed, then the engine.
import fs from 'node:fs';
import path from 'node:path';
import { fork } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { renderCapcutMix } from './capcut/capcut.js';
import { audioFileOf, createEntry, folderOf, readMeta, saveResult, updateMeta } from './library.js';
import { downloadAudio } from './links.js';
import { extractPcm, probeDuration, writeMix } from './media.js';
import { coded, ensureSpace, explainFsError } from './errors.js';
import { ensureModels } from './models.js';
import { renderPremiereMix } from './premiere.js';
import { resolveCapcutDir } from './paths.js';

const ENGINE = fileURLToPath(new URL('./engine/child.js', import.meta.url));

const queue = [];
const states = new Map(); // id → live state shown in the app
let running = null; // { id, cancel }

const setState = (id, patch) => {
  const state = { ...(states.get(id) || {}), ...patch, updatedAt: Date.now() };
  states.set(id, state);
  return state;
};

export const jobState = (id) => states.get(id) || null;
export const activeJobs = () => [...states.values()].filter((s) => !['done', 'error', 'cancelled'].includes(s.step));

/** Adds a transcription to the queue and returns its entry. */
export const enqueue = ({ title, source, options }) => {
  const meta = createEntry({ title, source, options });
  setState(meta.id, { id: meta.id, title: meta.title, step: 'queued', percent: 0, label: 'En attente…', preview: [] });
  queue.push(meta.id);
  pump();
  return meta;
};

export const cancel = (id) => {
  const index = queue.indexOf(id);
  if (index >= 0) {
    queue.splice(index, 1);
    finish(id, 'cancelled', 'Annulée.');
    return true;
  }
  if (running?.id === id) {
    running.cancelled = true;
    running.cancel?.();
    return true;
  }
  return false;
};

const finish = (id, step, label, code = null) => {
  setState(id, { step, label, code, percent: step === 'done' ? 100 : states.get(id)?.percent || 0 });
  if (step !== 'done') updateMeta(id, { status: step, error: step === 'error' ? label : null, errorCode: step === 'error' ? code : null });
};

const pump = async () => {
  if (running || !queue.length) return;
  const id = queue.shift();
  running = { id, cancelled: false, cancel: null };
  try {
    await runJob(id, running);
    if (running.cancelled) finish(id, 'cancelled', 'Annulée.');
  } catch (error) {
    if (running.cancelled) finish(id, 'cancelled', 'Annulée.');
    else {
      console.error(error);
      const clear = explainFsError(error);
      finish(id, 'error', clear.message || 'Erreur inattendue.', clear.code && !String(clear.code).startsWith('E') ? clear.code : null);
    }
  } finally {
    running = null;
    pump();
  }
};

/* ------------------------------------------------------------------ step 1: the sound */

const prepareAudio = async (id, job) => {
  const meta = readMeta(id);
  const { source } = meta;
  const output = audioFileOf(id);
  const show = (fraction, label) => setState(id, { step: 'audio', percent: Math.round(fraction * 10), label });

  if (source.kind === 'capcut' || source.kind === 'premiere') {
    show(0, 'Lecture du montage…');
    let count = 0;
    const onFile = (name) => show(Math.min(0.9, (count += 1) / 30), `Lecture des clips… (${name})`);
    const { mix, name, missing } =
      source.kind === 'capcut' ? await renderCapcutMix(resolveCapcutDir(), source.id, { onFile }) : await renderPremiereMix(source.file, source.sequenceId, { onFile });
    if (job.cancelled) throw new Error('Annulé.');
    if (!mix.some((v) => v !== 0)) {
      if (missing.length) throw coded('missing-media', `Les fichiers de ce montage sont introuvables (${missing.slice(0, 3).join(', ')}${missing.length > 3 ? '…' : ''}). Ils ont peut-être été déplacés.`);
      throw coded('silent-edit', "Ce montage n'a pas de son.");
    }
    writeMix(mix, output);
    updateMeta(id, { missing, title: meta.title || name });
    setState(id, { missing });
    return mix.length / 16000;
  }

  let input = source.path;
  if (source.kind === 'link') {
    const controller = new AbortController();
    job.cancel = () => controller.abort();
    show(0, 'Téléchargement de la vidéo…');
    input = await downloadAudio(source.url, path.join(folderOf(id), 'download'), {
      signal: controller.signal,
      onProgress: ({ received, total }) => show(total ? (received / total) * 0.7 : 0.3, `Téléchargement du son… ${(received / 1e6).toFixed(1)} Mo`),
    });
  }
  if (!input || !fs.existsSync(input)) throw coded('unreadable', 'Le fichier est introuvable (déplacé ou supprimé ?).');
  const info = await probeDuration(input);
  if (info && !info.hasAudio) throw coded('no-audio', 'Ce fichier ne contient pas de son.');
  ensureSpace(folderOf(id), (info?.seconds || 0) * 32000 + 200e6);
  const total = info?.seconds || 0;
  const base = source.kind === 'link' ? 0.7 : 0;
  show(base, 'Extraction du son…');
  const task = extractPcm(input, output, { onProgress: (sec) => show(base + (total ? Math.min(1, sec / total) : 0.5) * (1 - base), 'Extraction du son…') });
  job.cancel = task.cancel;
  await task.promise;
  if (source.kind === 'link') fs.rmSync(path.join(folderOf(id), 'download'), { recursive: true, force: true });
  if (source.kind === 'upload') fs.rmSync(source.path, { force: true });
  return fs.statSync(output).size / 2 / 16000;
};

/* ------------------------------------------------------------------ step 2 and 3 */

const runEngine = (id, job, models, options) =>
  new Promise((resolve, reject) => {
    // inside the launcher, process.execPath is the launcher itself: it runs the engine as plain Node
    const child = fork(ENGINE, [], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, stdio: ['ignore', 'ignore', 'pipe', 'ipc'], windowsHide: true, serialization: 'advanced' });
    let errors = '';
    child.stderr.on('data', (chunk) => {
      errors = (errors + chunk).slice(-3000);
    });
    let result = null;
    job.cancel = () => child.kill();
    const preview = [];
    child.on('message', (message) => {
      if (message.type === 'progress') {
        if (message.phase === 'voices') {
          setState(id, { step: 'voices', percent: 10 + Math.round((message.done / Math.max(1, message.total)) * 25), label: 'Repérage des voix…' });
        } else if (message.phase === 'language') {
          setState(id, { step: 'text', percent: 35, label: 'Transcription…', language: message.language });
        } else if (message.phase === 'text') {
          if (message.preview) {
            preview.push(message.preview);
            if (preview.length > 6) preview.shift();
          }
          setState(id, {
            step: 'text',
            percent: 35 + Math.round((message.done / Math.max(1, message.total)) * 64),
            label: 'Transcription…',
            remainingSec: message.remainingSec,
            preview: [...preview],
          });
        }
      } else if (message.type === 'done') result = message.result;
      else if (message.type === 'error') reject(coded('engine-crash', `Le moteur de transcription s'est arrêté (${message.message}).`));
    });
    child.on('error', reject);
    child.on('exit', (code) => {
      if (result) return resolve(result);
      if (job.cancelled) return reject(new Error('Annulé.'));
      if (errors) console.error(errors);
      reject(/bad_alloc|out of memory|std::bad/i.test(errors) ? coded('memory', "Pas assez de mémoire pour transcrire : ferme d'autres programmes puis relance.") : coded('engine-crash', "Le moteur de transcription s'est arrêté."));
    });
    child.send({ pcmFile: audioFileOf(id), models, options });
  });

const runJob = async (id, job) => {
  updateMeta(id, { status: 'running', startedAt: Date.now() });
  const seconds = await prepareAudio(id, job);
  if (job.cancelled) return;
  if (seconds < 0.5) throw coded('no-audio', 'Le son est vide.');
  updateMeta(id, { seconds });

  const controller = new AbortController();
  job.cancel = () => controller.abort();
  const models = await ensureModels({
    signal: controller.signal,
    onProgress: ({ phase, received, total }) =>
      setState(id, {
        step: 'models',
        percent: 10,
        label: phase === 'unpack' ? 'Installation du moteur de transcription…' : 'Premier lancement : téléchargement du moteur de transcription (une seule fois)',
        download: { received, total },
      }),
  });
  if (job.cancelled) return;
  setState(id, { download: null });

  const options = readMeta(id).options || {};
  const result = await runEngine(id, job, models, { language: options.language || 'auto', speakers: options.speakers || 'auto' });
  if (job.cancelled) return;
  if (!result.segments.length) throw coded('no-speech', "Aucune parole n'a été trouvée dans ce son.");
  saveResult(id, result);
  setState(id, { step: 'done', percent: 100, label: 'Terminé', preview: [] });
};
