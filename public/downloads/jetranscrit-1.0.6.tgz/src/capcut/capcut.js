// CapCut projects: listed from CapCut's drafts folder and read without ever being modified.
// A project is transcribed as it sounds in the edit: every audible clip, at its place on the timeline.
import fs from 'node:fs';
import path from 'node:path';
import { decodeToMemory, RATE } from '../media.js';
import { buildMaterialIndex, isCompoundSegment, MEDIA_TRACK_TYPES, resolveMediaPath, segmentSpeed, timelineDuration } from './draft-model.js';

const ROOT_DOCUMENTS = ['draft_content.json', 'draft_info.json', 'template-2.tmp'];
const MAX_NESTING = 3;

const readJson = (file) => {
  try {
    const text = fs.readFileSync(file, 'utf8').replace(/^﻿/, '');
    if (!text.trimStart().startsWith('{')) return { encrypted: true };
    return { value: JSON.parse(text) };
  } catch {
    return { corrupt: true };
  }
};

const safeFolder = (name) => {
  if (!name || /[\\/]/.test(name) || name === '.' || name === '..') throw new Error('Projet invalide.');
  return name;
};

export const listCapcutProjects = (draftsDir) => {
  if (!draftsDir || !fs.existsSync(draftsDir)) return [];
  const projects = [];
  for (const entry of fs.readdirSync(draftsDir, { withFileTypes: true })) {
    if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
    const dir = path.join(draftsDir, entry.name);
    const document = ROOT_DOCUMENTS.map((name) => path.join(dir, name)).find((file) => fs.existsSync(file));
    if (!document) continue;
    const meta = readJson(path.join(dir, 'draft_meta_info.json')).value || {};
    const modifiedUs = Number(meta.tm_draft_modified || 0);
    const modifiedMs = modifiedUs > 1e14 ? modifiedUs / 1000 : modifiedUs > 1e11 ? modifiedUs : fs.statSync(document).mtimeMs;
    projects.push({
      id: entry.name,
      name: meta.draft_name || entry.name,
      modifiedMs,
      seconds: Number(meta.tm_duration || 0) / 1e6,
      hasCover: fs.existsSync(path.join(dir, 'draft_cover.jpg')),
    });
  }
  return projects.sort((a, b) => b.modifiedMs - a.modifiedMs);
};

export const capcutCover = (draftsDir, id) => {
  const file = path.join(draftsDir, safeFolder(id), 'draft_cover.jpg');
  return fs.existsSync(file) ? file : null;
};

export const loadCapcutDraft = (draftsDir, id) => {
  const dir = path.join(draftsDir, safeFolder(id));
  const candidates = ROOT_DOCUMENTS.map((name) => path.join(dir, name)).filter((file) => fs.existsSync(file));
  const parsed = candidates.map((file) => readJson(file));
  const draft = parsed.find((p) => p.value && Array.isArray(p.value.tracks))?.value;
  if (!draft) {
    if (parsed.some((p) => p.encrypted)) throw Object.assign(new Error('Ce projet est chiffré par CapCut (souvent un projet fait depuis un modèle) : il ne peut pas être lu. Exporte la vidéo et importe-la à la place.'), { code: 'capcut-encrypted' });
    throw new Error('Le fichier de ce projet est illisible.');
  }
  const meta = readJson(path.join(dir, 'draft_meta_info.json')).value || {};
  return { draft, dir, name: meta.draft_name || id };
};

const nestedDraftOf = (segment, index, dir) => {
  const ref = (segment.extra_material_refs || []).map((id) => index.get(id)).find((r) => r && r.listKey === 'drafts');
  const material = ref?.item;
  if (!material) return null;
  if (material.draft && Array.isArray(material.draft.tracks)) return material.draft;
  const file = resolveMediaPath(String(material.draft_file_path || '').replace(/\\/g, path.sep), dir);
  const nested = readJson(file).value;
  return Array.isArray(nested?.tracks) ? nested : null;
};

/** Adds one clip to the mix (speed changes the pitch here, which does not bother the transcription). */
const paint = (mix, segment, source, speed, gain, mirrorUs = null) => {
  const { start: targetStart, duration } = segment.target_timerange;
  const perUs = RATE / 1e6;
  const first = Math.max(0, Math.round(targetStart * perUs));
  const last = Math.min(mix.length, Math.round((targetStart + duration) * perUs));
  const sourceStart = segment.source_timerange.start * perUs;
  const mirror = mirrorUs === null ? null : mirrorUs * perUs;
  const origin = targetStart * perUs;
  for (let i = first; i < last; i++) {
    const position = sourceStart + (i - origin) * speed;
    const j = Math.floor(mirror === null ? position : mirror - position);
    if (j < 0 || j >= source.length) continue;
    mix[i] += source[j] * gain;
  }
};

const renderMix = async (draft, dir, ctx, depth) => {
  const index = buildMaterialIndex(draft);
  const durationUs = Number(draft.duration) || timelineDuration(draft);
  const mix = new Float32Array(Math.max(1, Math.ceil((durationUs * RATE) / 1e6)));
  const mainVideo = draft.tracks.find((track) => track.type === 'video');
  for (const track of draft.tracks.filter((t) => MEDIA_TRACK_TYPES.has(t.type))) {
    if (track === mainVideo && draft.config?.video_mute === true) continue;
    for (const segment of track.segments || []) {
      const material = index.get(segment.material_id)?.item;
      if (!material || material.type === 'photo' || material.has_audio === false || !segment.source_timerange) continue;
      const gain = Number(segment.volume ?? 1);
      if (!(gain > 0)) continue;
      const speed = segmentSpeed(segment, index) ?? segment.source_timerange.duration / Math.max(1, segment.target_timerange.duration);
      if (isCompoundSegment(segment, index)) {
        const nested = depth < MAX_NESTING ? nestedDraftOf(segment, index, dir) : null;
        if (nested) paint(mix, segment, await renderMix(nested, dir, ctx, depth + 1), speed, gain);
        continue;
      }
      const reversed = segment.reverse && material.reverse_path ? resolveMediaPath(material.reverse_path, dir) : '';
      const useReversed = Boolean(segment.reverse && reversed && fs.existsSync(reversed));
      if (!material.path && !useReversed) continue;
      const file = useReversed ? reversed : resolveMediaPath(material.path, dir);
      if (!fs.existsSync(file)) {
        ctx.missing.add(path.basename(file));
        continue;
      }
      ctx.onFile(path.basename(file));
      const source = await ctx.source(file);
      paint(mix, segment, source, speed, gain, segment.reverse && !useReversed ? Number(material.duration) || null : null);
    }
  }
  return mix;
};

/** The sound of the whole edit (Float32Array at 16 kHz) and the media that could not be found. */
export const renderCapcutMix = async (draftsDir, id, { onFile = () => {} } = {}) => {
  const { draft, dir, name } = loadCapcutDraft(draftsDir, id);
  const decoded = new Map();
  const ctx = {
    missing: new Set(),
    onFile,
    source: (file) => {
      if (!decoded.has(file)) decoded.set(file, decodeToMemory(file));
      return decoded.get(file);
    },
  };
  const mix = await renderMix(draft, dir, ctx, 0);
  return { mix, name, missing: [...ctx.missing] };
};
