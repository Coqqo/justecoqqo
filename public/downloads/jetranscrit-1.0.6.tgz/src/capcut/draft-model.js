import crypto from 'node:crypto';
import path from 'node:path';

/** CapCut writes GUIDs like "6A13A13B-2C18-47e6-8E33-3818A8FC20FB": upper case except the third group. */
export const newCapcutId = () => {
  const [a, b, c, d, e] = crypto.randomUUID().split('-');
  return [a.toUpperCase(), b.toUpperCase(), c.toLowerCase(), d.toUpperCase(), e.toUpperCase()].join('-');
};

export const buildMaterialIndex = (draft) => {
  const index = new Map();
  for (const [listKey, list] of Object.entries(draft.materials || {})) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (item && typeof item === 'object' && typeof item.id === 'string') index.set(item.id, { listKey, item });
    }
  }
  return index;
};

export const segmentEnd = (segment) => segment.target_timerange.start + segment.target_timerange.duration;

export const trackEnd = (track) => track.segments.reduce((max, segment) => Math.max(max, segmentEnd(segment)), 0);

export const timelineDuration = (draft) => draft.tracks.reduce((max, track) => Math.max(max, trackEnd(track)), 0);

export const MEDIA_TRACK_TYPES = new Set(['video', 'audio']);

const PLACEHOLDER_PATTERN = /##_draftpath_placeholder_[0-9A-Fa-f-]+_##/g;

/** Resolve a material path, expanding CapCut's "draft path" placeholder to the project folder. */
export const resolveMediaPath = (rawPath, projectDir) => {
  if (!rawPath) return '';
  const expanded = rawPath.replace(PLACEHOLDER_PATTERN, projectDir);
  return path.normalize(expanded);
};

const refsOfType = (segment, materialIndex, listKey) =>
  (segment.extra_material_refs || []).map((id) => materialIndex.get(id)).filter((ref) => ref && ref.listKey === listKey);

/** Constant speed of a segment, or null when it uses a speed curve (cannot be split linearly). */
export const segmentSpeed = (segment, materialIndex) => {
  const speedMaterial = refsOfType(segment, materialIndex, 'speeds')[0]?.item;
  if (speedMaterial && speedMaterial.mode === 1 && speedMaterial.curve_speed) return null;
  const speed = Number(segment.speed ?? speedMaterial?.speed ?? 1);
  return speed > 0 ? speed : 1;
};

export const isCompoundSegment = (segment, materialIndex) => refsOfType(segment, materialIndex, 'drafts').length > 0;

/**
 * Why a media segment cannot be cut (or null when it can). Compound clips are cut like any clip:
 * as CapCut does, every piece keeps pointing to the same inner timeline.
 */
export const unsplittableReason = (segment, materialIndex) => {
  if (!segment.source_timerange) return 'pas de source';
  if (segmentSpeed(segment, materialIndex) === null) return 'vitesse en courbe';
  return null;
};

export const describeTracks = (draft) => {
  const counters = {};
  const labels = { video: 'Vidéo', audio: 'Audio', text: 'Texte', effect: 'Effets', filter: 'Filtres', sticker: 'Stickers', adjust: 'Réglages' };
  const materialIndex = buildMaterialIndex(draft);
  return draft.tracks.map((track, position) => {
    counters[track.type] = (counters[track.type] || 0) + 1;
    const number = counters[track.type];
    const isMain = track.type === 'video' && number === 1;
    const segments = track.segments || [];
    const materials = segments.map((segment) => materialIndex.get(segment.material_id)?.item).filter(Boolean);
    const hasAudio = MEDIA_TRACK_TYPES.has(track.type) && materials.some((m) => m.type !== 'photo' && m.has_audio !== false);
    const names = [...new Set(materials.map((m) => m.material_name || m.name || path.basename(m.path || '')).filter(Boolean))];
    // [start, end, flags]: 1 = never cut (photo, speed curve), 2 = no sound.
    const clips = segments.map((segment) => {
      const material = materialIndex.get(segment.material_id)?.item;
      const media = MEDIA_TRACK_TYPES.has(track.type);
      const locked = media && (material?.type === 'photo' || Boolean(unsplittableReason(segment, materialIndex)));
      const silent = media && (material?.type === 'photo' || material?.has_audio === false);
      return [segment.target_timerange.start, segmentEnd(segment), (locked ? 1 : 0) | (silent ? 2 : 0)];
    });
    return {
      id: track.id,
      position,
      type: track.type,
      label: `${labels[track.type] || track.type} ${number}`,
      clips,
      isMain,
      segmentCount: segments.length,
      start: segments.length ? Math.min(...segments.map((s) => s.target_timerange.start)) : 0,
      end: trackEnd(track),
      hasAudio,
      canCut: MEDIA_TRACK_TYPES.has(track.type),
      mediaNames: names.slice(0, 4),
      mediaCount: names.length,
    };
  });
};

/** Hash of everything the cut depends on, so an apply never runs against a timeline that changed after analysis. */
export const timelineFingerprint = (draft) => {
  const shape = draft.tracks.map((track) => [
    track.id,
    track.segments.map((s) => [
      s.id,
      s.target_timerange.start,
      s.target_timerange.duration,
      s.source_timerange?.start ?? null,
      s.source_timerange?.duration ?? null,
      s.speed ?? null,
      s.volume ?? null,
      s.reverse ?? null,
      s.material_id,
      s.extra_material_refs || [],
    ]),
  ]);
  shape.push(draft.fps);
  return crypto.createHash('sha1').update(JSON.stringify(shape)).digest('hex').slice(0, 16);
};
