import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { BRAND } from '../public/brand.js';

const dataRoot = () => {
  const home = os.homedir();
  if (process.platform === 'win32') return process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
  if (process.platform === 'darwin') return path.join(home, 'Library', 'Application Support');
  return path.join(home, '.local', 'share');
};

let resolvedDataDir;
export const appDataDir = () => {
  if (resolvedDataDir) return resolvedDataDir;
  const base = process.env.JETRANSCRIT_DATA_DIR || path.join(dataRoot(), BRAND.dataFolder);
  fs.mkdirSync(base, { recursive: true });
  resolvedDataDir = base;
  return base;
};

export const subDir = (...parts) => {
  const dir = path.join(appDataDir(), ...parts);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const configPath = () => path.join(appDataDir(), 'config.json');

export const readConfig = () => {
  try {
    return JSON.parse(fs.readFileSync(configPath(), 'utf8'));
  } catch {
    return {};
  }
};

export const writeConfig = (patch) => {
  const next = { ...readConfig(), ...patch };
  fs.writeFileSync(configPath(), JSON.stringify(next, null, 2));
  return next;
};

/** CapCut keeps its projects there (the user can pick another folder). */
export const candidateCapcutDirs = () => {
  const home = os.homedir();
  const sub = ['User Data', 'Projects', 'com.lveditor.draft'];
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
    return [path.join(local, 'CapCut', ...sub), path.join(local, 'JianyingPro', ...sub)];
  }
  if (process.platform === 'darwin') return [path.join(home, 'Movies', 'CapCut', ...sub), path.join(home, 'Movies', 'JianyingPro', ...sub)];
  return [];
};

export const resolveCapcutDir = () => {
  const configured = readConfig().capcutDir;
  if (configured && fs.existsSync(configured)) return configured;
  if (process.env.JETRANSCRIT_CAPCUT_DIR) return process.env.JETRANSCRIT_CAPCUT_DIR;
  return candidateCapcutDirs().find((dir) => fs.existsSync(dir)) || configured || candidateCapcutDirs()[0] || '';
};
