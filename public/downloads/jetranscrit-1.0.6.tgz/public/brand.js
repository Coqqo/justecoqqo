// The only place where the name and the links of the tool are written.
export const BRAND = Object.freeze({
  name: 'jetranscris',
  tagline: 'Transcris tes vidéos, voix par voix',
  site: 'https://justecoqqo.fr',
  page: 'https://justecoqqo.fr/jetranscris/',
  support: 'https://justecoqqo.fr/soutenir/?app=jetranscrit',
  dataFolder: 'jetranscrit',
});
