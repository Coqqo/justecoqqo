import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';
import { BRAND } from '../public/brand.js';
import { capcutCover, listCapcutProjects } from './capcut/capcut.js';
import { FORMATS } from './exporters.js';
import { activeJobs, cancel, enqueue, jobState } from './jobs.js';
import { audioFileOf, listEntries, readMeta, readTranscript, removeEntry, saveTranscript, updateMeta } from './library.js';
import { findYtdlp, linkInfo, looksLikeLink } from './links.js';
import { findFfmpeg, wavHeader } from './media.js';
import { installedModels, missingDownloadBytes } from './models.js';
import { candidateCapcutDirs, resolveCapcutDir, subDir, writeConfig } from './paths.js';
import { listPremiereProjects, listSequences, readPremiereProject } from './premiere.js';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PUBLIC_DIR = path.join(ROOT, 'public');
export const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const TOKEN = crypto.randomBytes(18).toString('hex');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2' };
const VIDEO_EXTENSIONS = ['mp4', 'mov', 'mkv', 'avi', 'webm', 'm4v', 'wmv', 'flv', 'mts', 'm2ts', 'mpg', 'mpeg', '3gp', 'mp3', 'wav', 'm4a', 'aac', 'flac', 'ogg', 'opus', 'wma', 'aiff', 'aif'];

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

/* The desktop window lives in the launcher (Electron): its file dialogs are used when available. */
let electron;
const getElectron = async () => {
  if (electron !== undefined) return electron;
  try {
    electron = process.versions.electron ? await import('electron') : null;
  } catch {
    electron = null;
  }
  return electron;
};
const focusedWindow = (e) => e.BrowserWindow.getFocusedWindow() || e.BrowserWindow.getAllWindows()[0];

const sendJson = (res, status, body) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 30 * 1024 * 1024) {
        reject(new HttpError(413, 'Requête trop volumineuse.'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch {
        reject(new HttpError(400, 'JSON invalide.'));
      }
    });
    req.on('error', reject);
  });

const exportOptions = (body) => ({
  speakers: Array.isArray(body.speakers) ? body.speakers.map(Number).filter(Number.isInteger) : [],
  names: body.names !== false,
  times: body.times !== false,
});

const safeFileName = (text) => String(text || 'transcription').replace(/[<>:"/\\|?*\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'transcription';

const routes = {
  'GET /api/status': async () => ({
    version: VERSION,
    name: BRAND.name,
    platform: process.platform,
    launcher: process.env.JUSTECOQQO_LAUNCHER === '1',
    nativeDialogs: Boolean(await getElectron()),
    ffmpeg: Boolean(findFfmpeg()),
    ytdlp: Boolean(findYtdlp()),
    modelsReady: Boolean(installedModels()),
    modelsDownloadBytes: installedModels() ? 0 : missingDownloadBytes(),
    capcutDir: resolveCapcutDir(),
    capcutDirExists: fs.existsSync(resolveCapcutDir()),
    capcutDirs: candidateCapcutDirs(),
    cpuCount: os.cpus().length,
  }),

  'POST /api/settings': (body) => {
    const dir = String(body.capcutDir || '').trim();
    if (!dir || !fs.existsSync(dir)) throw new HttpError(400, "Ce dossier n'existe pas.");
    writeConfig({ capcutDir: dir });
    return { capcutDir: dir };
  },

  'POST /api/pick-folder': async () => {
    const e = await getElectron();
    if (!e) throw new HttpError(400, 'Indisponible ici.');
    const result = await e.dialog.showOpenDialog(focusedWindow(e), { properties: ['openDirectory'] });
    return { path: result.canceled ? null : result.filePaths[0] };
  },

  'GET /api/capcut/projects': () => ({ projects: listCapcutProjects(resolveCapcutDir()), dir: resolveCapcutDir() }),

  'GET /api/premiere/projects': () => ({ projects: listPremiereProjects() }),

  'GET /api/premiere/sequences': (_body, query) => {
    const file = query.get('file');
    if (!file || !file.toLowerCase().endsWith('.prproj') || !fs.existsSync(file)) throw new HttpError(404, 'Projet introuvable.');
    try {
      return { sequences: listSequences(readPremiereProject(file)) };
    } catch {
      throw Object.assign(new HttpError(400, "Ce projet Premiere n'a pas pu être lu. Exporte l'audio de ta séquence et importe le fichier à la place."), { code: 'premiere-unreadable' });
    }
  },

  'POST /api/pick-premiere': async () => {
    const e = await getElectron();
    if (!e) throw new HttpError(400, 'Indisponible ici.');
    const result = await e.dialog.showOpenDialog(focusedWindow(e), { properties: ['openFile'], filters: [{ name: 'Projet Premiere Pro', extensions: ['prproj'] }] });
    if (result.canceled) return { file: null };
    return { file: result.filePaths[0] };
  },

  'POST /api/pick-file': async () => {
    const e = await getElectron();
    if (!e) throw new HttpError(400, 'Indisponible ici.');
    const result = await e.dialog.showOpenDialog(focusedWindow(e), { properties: ['openFile'], filters: [{ name: 'Vidéos et sons', extensions: VIDEO_EXTENSIONS }, { name: 'Tous les fichiers', extensions: ['*'] }] });
    if (result.canceled) return { file: null };
    const file = result.filePaths[0];
    return { file, name: path.basename(file), size: fs.statSync(file).size };
  },

  'POST /api/link/info': async (body) => {
    const url = String(body.url || '').trim();
    if (!looksLikeLink(url)) throw new HttpError(400, "Ce n'est pas un lien valide.");
    return linkInfo(url);
  },

  'POST /api/transcribe': (body) => {
    const source = body.source || {};
    const options = { language: String(body.options?.language || 'auto').slice(0, 5), speakers: ['auto', '1', '2', '3', '4', '5', '6', '7', '8'].includes(String(body.options?.speakers)) ? String(body.options.speakers) : 'auto' };
    let clean;
    if (source.kind === 'file' || source.kind === 'upload') {
      if (!source.path || !fs.existsSync(source.path)) throw new HttpError(400, 'Fichier introuvable.');
      clean = { kind: source.kind, path: String(source.path) };
    } else if (source.kind === 'capcut') clean = { kind: 'capcut', id: String(source.id) };
    else if (source.kind === 'premiere') clean = { kind: 'premiere', file: String(source.file), sequenceId: String(source.sequenceId) };
    else if (source.kind === 'link') {
      if (!looksLikeLink(source.url)) throw new HttpError(400, "Ce n'est pas un lien valide.");
      if (!findYtdlp()) throw Object.assign(new HttpError(500, "L'outil de téléchargement est introuvable : ouvre jetranscrit depuis le launcher justecoqqo pour le réparer."), { code: 'no-ffmpeg' });
      clean = { kind: 'link', url: String(source.url).trim() };
    } else throw new HttpError(400, 'Source inconnue.');
    if (clean.kind !== 'link' && !findFfmpeg()) throw Object.assign(new HttpError(500, 'Un composant manque (ffmpeg) : ouvre jetranscrit depuis le launcher justecoqqo pour le réparer.'), { code: 'no-ffmpeg' });
    const meta = enqueue({ title: String(body.title || '').slice(0, 120), source: clean, options });
    return { id: meta.id };
  },

  'POST /api/retry': (body) => {
    const old = readMeta(String(body.id));
    if (!old) throw new HttpError(404, 'Transcription introuvable.');
    const meta = enqueue({ title: old.title, source: old.source, options: old.options });
    removeEntry(old.id);
    return { id: meta.id };
  },

  'GET /api/jobs': () => ({ jobs: activeJobs() }),
  'GET /api/job': (_body, query) => ({ job: jobState(query.get('id')) }),
  'POST /api/cancel': (body) => ({ cancelled: cancel(String(body.id)) }),

  'GET /api/transcriptions': () => ({ items: listEntries().map((meta) => ({ ...meta, live: jobState(meta.id) })) }),
  'GET /api/transcription': (_body, query) => readTranscript(query.get('id')),
  'POST /api/transcription/save': (body) => saveTranscript(String(body.id), body),
  'POST /api/transcription/rename': (body) => updateMeta(String(body.id), { title: String(body.title || '').trim().slice(0, 120) || 'Sans titre' }),
  'POST /api/transcription/delete': (body) => {
    cancel(String(body.id));
    removeEntry(String(body.id));
    return { ok: true };
  },

  'POST /api/export': async (body) => {
    const format = FORMATS[body.format];
    if (!format) throw new HttpError(400, 'Format inconnu.');
    const transcript = readTranscript(String(body.id));
    const options = exportOptions(body);
    const content = format.build(transcript, options);
    const voice = options.speakers.length === 1 ? transcript.speakers.find((s) => s.id === options.speakers[0])?.name || '' : '';
    const fileName = `${safeFileName(transcript.title)}${voice ? ` - ${safeFileName(voice)}` : ''}.${body.format}`;
    const e = await getElectron();
    if (!e || body.inline) return { content: Buffer.from(content).toString('base64'), fileName, mime: format.mime };
    const result = await e.dialog.showSaveDialog(focusedWindow(e), { defaultPath: path.join(e.app.getPath('documents'), fileName), filters: [{ name: format.label, extensions: [body.format] }] });
    if (result.canceled || !result.filePath) return { saved: false };
    fs.writeFileSync(result.filePath, content);
    return { saved: true, path: result.filePath };
  },

  'POST /api/reveal': async (body) => {
    const e = await getElectron();
    if (e && body.path && fs.existsSync(body.path)) e.shell.showItemInFolder(body.path);
    return { ok: true };
  },
};

/* Dropped files arrive here (the browser cannot give their path): they are copied to a temporary folder. */
const receiveUpload = async (req, res, query) => {
  const name = safeFileName(query.get('name') || 'video');
  const dir = subDir('uploads');
  const file = path.join(dir, `${Date.now().toString(36)}-${name}`);
  await pipeline(req, fs.createWriteStream(file));
  sendJson(res, 200, { path: file, name });
};

const serveAudio = (req, res, query) => {
  const file = audioFileOf(query.get('id'));
  if (!fs.existsSync(file)) {
    res.writeHead(404);
    return res.end();
  }
  const dataSize = fs.statSync(file).size;
  const header = wavHeader(dataSize / 2);
  const total = header.length + dataSize;
  let start = 0;
  let end = total - 1;
  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
  if (range) {
    if (range[1]) start = Number(range[1]);
    if (range[2]) end = Math.min(Number(range[2]), total - 1);
    if (!range[1] && range[2]) {
      start = Math.max(0, total - Number(range[2]));
      end = total - 1;
    }
    if (start > end || start >= total) {
      res.writeHead(416, { 'Content-Range': `bytes */${total}` });
      return res.end();
    }
  }
  res.writeHead(range ? 206 : 200, {
    'Content-Type': 'audio/wav',
    'Content-Length': end - start + 1,
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'no-store',
    ...(range ? { 'Content-Range': `bytes ${start}-${end}/${total}` } : {}),
  });
  if (start < header.length) res.write(header.subarray(start, Math.min(header.length, end + 1)));
  const dataStart = Math.max(0, start - header.length);
  const dataEnd = end - header.length;
  if (dataEnd < dataStart) return res.end();
  fs.createReadStream(file, { start: dataStart, end: dataEnd }).pipe(res);
};

const serveCover = (res, query) => {
  const file = capcutCover(resolveCapcutDir(), query.get('id'));
  if (!file) {
    res.writeHead(404);
    return res.end();
  }
  res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'max-age=60' });
  fs.createReadStream(file).pipe(res);
};

const serveStatic = (res, pathname) => {
  const relative = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  const file = path.normalize(path.join(PUBLIC_DIR, relative));
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404);
    return res.end('Introuvable');
  }
  let content = fs.readFileSync(file);
  if (relative === 'index.html') content = Buffer.from(content.toString('utf8').replace('__APP_TOKEN__', TOKEN));
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  res.end(content);
};

const SPECIAL = { '/api/upload': receiveUpload, '/api/audio': serveAudio, '/api/capcut/cover': (_req, res, query) => serveCover(res, query) };

const handle = async (req, res, port) => {
  const host = req.headers.host || '';
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    res.writeHead(403);
    return res.end();
  }
  const url = new URL(req.url, `http://${host}`);
  if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
  if (req.headers['x-app-token'] !== TOKEN && url.searchParams.get('token') !== TOKEN) return sendJson(res, 403, { error: 'Accès refusé.' });
  try {
    const special = SPECIAL[url.pathname];
    if (special) return await special(req, res, url.searchParams);
    const route = routes[`${req.method} ${url.pathname}`];
    if (!route) return sendJson(res, 404, { error: 'Route inconnue.' });
    const body = req.method === 'POST' ? await readBody(req) : {};
    sendJson(res, 200, await route(body, url.searchParams));
  } catch (error) {
    if (error instanceof HttpError) return sendJson(res, error.status, { error: error.message, code: error.code });
    if (error.code && /^[a-z-]+$/.test(error.code)) return sendJson(res, 400, { error: error.message, code: error.code });
    console.error(error);
    if (!res.headersSent) sendJson(res, 500, { error: error.message || 'Erreur inattendue.' });
  }
};

export const startServer = ({ preferredPort = 4870, attempts = 15 } = {}) =>
  new Promise((resolve, reject) => {
    const tryPort = (port, attemptsLeft) => {
      const server = http.createServer((req, res) =>
        handle(req, res, server.address().port).catch((error) => {
          console.error(error);
          if (!res.headersSent) sendJson(res, 500, { error: 'Erreur inattendue.' });
          else res.end();
        }),
      );
      server.once('error', (error) => {
        if (error.code === 'EADDRINUSE' && attemptsLeft > 0) tryPort(port + 1, attemptsLeft - 1);
        else reject(error);
      });
      server.listen(port, '127.0.0.1', () => {
        const actual = server.address().port;
        resolve({ url: `http://127.0.0.1:${actual}/`, port: actual, server });
      });
    };
    tryPort(preferredPort, attempts);
  });
