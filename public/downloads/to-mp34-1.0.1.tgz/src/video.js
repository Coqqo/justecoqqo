// Reading what a video offers (resolutions, sound qualities) and downloading it, with yt-dlp + ffmpeg.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

export const coded = (code, message) => Object.assign(new Error(message), { code });

/* ------------------------------------------------------------------ tools */

const onPath = (names) => {
  const finder = process.platform === 'win32' ? 'where' : 'which';
  for (const name of names) {
    const result = spawnSync(finder, [name], { encoding: 'utf8', windowsHide: true });
    const found = result.status === 0 && result.stdout.split(/\r?\n/).map((l) => l.trim()).find((l) => l && fs.existsSync(l));
    if (found) return found;
  }
  return null;
};

const fromEnv = (name) => (process.env[name] && fs.existsSync(process.env[name]) ? process.env[name] : null);
let tools = null;
export const findTools = () => {
  if (tools?.ytdlp && tools?.ffmpeg) return tools;
  tools = { ytdlp: fromEnv('TOMP34_YTDLP') || onPath(['yt-dlp', 'yt-dlp.exe']), ffmpeg: fromEnv('TOMP34_FFMPEG') || onPath(['ffmpeg', 'ffmpeg.exe']) };
  return tools;
};

/* ------------------------------------------------------------------ platforms */

export const PLATFORMS = {
  youtube: { name: 'YouTube', hosts: ['youtube.com', 'youtu.be', 'youtube-nocookie.com'] },
  instagram: { name: 'Instagram', hosts: ['instagram.com', 'instagr.am'] },
  tiktok: { name: 'TikTok', hosts: ['tiktok.com'] },
};

/** The platform of a link (null when it is none of them). */
export const platformOf = (link) => {
  let url;
  try {
    url = new URL(String(link).trim());
  } catch {
    return null;
  }
  if (!/^https?:$/.test(url.protocol)) return null;
  const host = url.hostname.toLowerCase().replace(/^www\.|^m\.|^music\.|^vm\.|^vt\./, '');
  for (const [id, platform] of Object.entries(PLATFORMS)) if (platform.hosts.some((h) => host === h || host.endsWith(`.${h}`))) return id;
  return 'other';
};

/* ------------------------------------------------------------------ running yt-dlp */

const run = (args, { onLine = () => {}, signal } = {}) =>
  new Promise((resolve, reject) => {
    const { ytdlp } = findTools();
    if (!ytdlp) return reject(coded('no-tools', 'Un composant manque (yt-dlp) : ouvre to mp34 depuis le launcher justecoqqo pour le réparer.'));
    // yt-dlp writes in UTF-8 (by default Windows uses its own code page: « Adèle » came back as « Ad�le »)
    const child = spawn(ytdlp, ['--encoding', 'utf-8', ...args], { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } });
    let out = '';
    let err = '';
    const abort = () => child.kill();
    signal?.addEventListener('abort', abort, { once: true });
    // a line can arrive in two pieces: only whole lines are read
    let pending = '';
    const lines = (chunk) => {
      const parts = (pending + chunk.toString()).split(/\r?\n|\r/);
      pending = parts.pop();
      for (const line of parts) if (line.trim()) onLine(line.trim());
    };
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      out += chunk;
      if (out.length > 64 * 1024 * 1024) out = out.slice(-1024);
      lines(chunk);
    });
    child.stderr.on('data', (chunk) => {
      err = (err + chunk).slice(-8000);
      lines(chunk);
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (pending.trim()) onLine(pending.trim());
      signal?.removeEventListener('abort', abort);
      if (signal?.aborted) return reject(coded('cancelled', 'Annulé.'));
      code === 0 ? resolve(out) : reject(Object.assign(new Error(err.trim().split(/\r?\n/).filter((l) => /ERROR/.test(l)).pop() || err.trim().split(/\r?\n/).pop() || 'Erreur.'), { raw: err }));
    });
  });

/** Turns yt-dlp's messages into something clear (with a code for the help panel). */
const explain = (error) => {
  if (error.code) return error;
  const text = `${error.raw || ''} ${error.message}`;
  if (/\bprivate\b|sign in|log in|login required|--cookies|age-restricted|confirm your age|inappropriate|members-only|join this channel/i.test(text))
    return coded('private', "Cette vidéo est privée, réservée aux abonnés ou limitée par l'âge : elle ne peut pas être téléchargée.");
  if (/unsupported url|no video formats|is not a valid url/i.test(text)) return coded('bad-link', "Ce lien ne mène pas à une vidéo. Copie le lien de la vidéo elle-même (bouton Partager › Copier le lien).");
  if (/getaddrinfo|network is unreachable|timed out|connection (refused|reset)|unable to connect|nodename nor servname/i.test(text)) return coded('offline', 'Pas de connexion à internet.');
  if (/no space left/i.test(text)) return coded('disk-full', "Plus assez de place sur ton disque.");
  if (/permission denied|access is denied|errno 13/i.test(text)) return coded('folder', "to mp34 ne peut pas écrire dans ce dossier : choisis-en un autre.");
  if (/unavailable|not available|removed|deleted|does not exist|http error 404|copyright|blocked|geo/i.test(text)) return coded('unavailable', "Cette vidéo n'est pas disponible (supprimée, privée ou bloquée dans ton pays).");
  if (/http error 429|too many requests|rate.?limit/i.test(text)) return coded('rate-limit', 'Le site bloque les téléchargements pour le moment : réessaie dans quelques minutes.');
  return coded('unknown', `Le téléchargement n'a pas marché : ${error.message.replace(/^ERROR:\s*/, '')}`);
};

let updated = false;
/** The sites change often: when something fails, yt-dlp updates itself once and tries again. */
const withUpdate = async (task) => {
  try {
    return await task();
  } catch (error) {
    if (updated || error.code === 'cancelled' || error.code === 'no-tools') throw error;
    const clear = explain(error);
    if (['private', 'offline', 'disk-full', 'folder'].includes(clear.code)) throw error;
    updated = true;
    try {
      await run(['-U']);
    } catch {
      throw error;
    }
    return task();
  }
};

/* ------------------------------------------------------------------ what a video offers */

const NAMES = { 4320: '8K', 2160: '4K', 1440: '2K', 1080: 'Full HD', 720: 'HD', 480: 'SD', 360: '', 240: '', 144: '' };
export const STANDARD_HEIGHTS = [4320, 2160, 1440, 1080, 720, 480, 360, 240, 144];
export const DEFAULT_HEIGHT = 1080;

/** The standard step of a height (a 1920×1012 video counts as 1080p). */
const stepOf = (format) => {
  const h = Number(format.height) || 0;
  const w = Number(format.width) || 0;
  // vertical videos (TikTok, Shorts): their quality is the short side
  const side = w && h ? Math.min(w, h) : h;
  if (!side) return 0;
  return STANDARD_HEIGHTS.find((step) => side >= step * 0.9) || side;
};

const roundKbps = (value) => Math.round(Number(value) || 0);

export const describeFormats = (info) => {
  const formats = (info.formats || []).filter((f) => f.format_id && !/storyboard|mhtml/.test(`${f.format_note} ${f.ext}`));
  // some sites (and direct links) do not say which codecs a file has: a video file is assumed to have both
  const VIDEO_EXT = /^(mp4|webm|mov|mkv|flv|m4v|ts|3gp)$/i;
  const hasVideo = (f) => (f.vcodec ? f.vcodec !== 'none' : Boolean(f.height) || VIDEO_EXT.test(f.ext || ''));
  const hasAudio = (f) => (f.acodec ? f.acodec !== 'none' : !f.vcodec || f.vcodec === 'none' || VIDEO_EXT.test(f.ext || ''));
  const audioOnly = formats.filter((f) => hasAudio(f) && !hasVideo(f));
  const videos = formats.filter(hasVideo);

  // one file per quality step: the most compatible codec (H.264), else the richest one
  const steps = new Map();
  const score = (f) => (/^(avc|h264)/i.test(f.vcodec) ? 1e9 : 0) + (Number(f.tbr) || Number(f.filesize || f.filesize_approx) / 1e5 || 0);
  for (const f of videos) {
    const step = stepOf(f); // 0: quality not given by the site
    const current = steps.get(step);
    if (!current || score(f) > score(current.format)) {
      steps.set(step, { height: step, fps: Number(f.fps) || 0, size: Number(f.filesize || f.filesize_approx) || 0, format: f, withAudio: hasAudio(f) });
    }
  }

  const audioBitrates = new Map();
  for (const f of audioOnly) {
    const kbps = roundKbps(f.abr || f.tbr);
    if (!kbps) continue;
    const size = Number(f.filesize || f.filesize_approx) || 0;
    if (!audioBitrates.has(kbps)) audioBitrates.set(kbps, { kbps, id: f.format_id, ext: f.ext, size });
  }
  // no sound-only file (often TikTok, Instagram): the sound comes from the video
  if (!audioBitrates.size && formats.some(hasAudio)) {
    const best = formats.filter(hasAudio).map((f) => roundKbps(f.abr)).filter(Boolean).sort((a, b) => b - a)[0] || 0;
    audioBitrates.set(best, { kbps: best, id: null, size: 0 });
  }

  const videoChoices = [...steps.values()].sort((a, b) => b.height - a.height).map((s) => ({
    height: s.height,
    id: s.format.format_id,
    withAudio: s.withAudio,
    label: s.height ? `${s.height}p` : 'Originale',
    name: s.height ? NAMES[s.height] || '' : 'la seule disponible',
    fps: s.fps > 30 ? Math.round(s.fps) : 0,
    sizeBytes: s.size,
  }));
  const audioChoices = [...audioBitrates.values()].sort((a, b) => b.kbps - a.kbps).map((a, i) => ({
    kbps: a.kbps,
    id: a.id,
    label: a.kbps ? `${a.kbps} kb/s` : 'qualité d’origine',
    name: i === 0 ? 'Meilleure' : '',
    sizeBytes: a.size,
  }));
  const defaultHeight = videoChoices.find((c) => c.height <= DEFAULT_HEIGHT)?.height ?? videoChoices[videoChoices.length - 1]?.height ?? null;
  return {
    title: info.title || info.id || 'vidéo',
    uploader: info.uploader || info.channel || '',
    seconds: Number(info.duration) || null,
    thumbnail: info.thumbnail || '',
    isLive: Boolean(info.is_live),
    video: videoChoices,
    audio: audioChoices,
    defaultHeight,
    defaultAudio: audioChoices[0]?.kbps ?? null,
  };
};

export const readVideo = async (url, { signal } = {}) => {
  try {
    const json = await withUpdate(() => run(['-J', '--no-playlist', '--no-warnings', url], { signal }));
    const info = JSON.parse(json);
    if (info._type === 'playlist') throw coded('playlist', "Ce lien est une playlist ou un profil : ouvre une seule vidéo et copie son lien.");
    if (info.is_live) throw coded('live', "C'est un direct en cours : attends qu'il soit terminé pour le télécharger.");
    return describeFormats(info);
  } catch (error) {
    throw explain(error);
  }
};

/* ------------------------------------------------------------------ downloading */

/** yt-dlp arguments for one download (exported for the tests). */
export const downloadArgs = ({ url, kind, height, videoId, withAudio, audio, folder, ffmpeg, workDir = folder }) => {
  const name = kind === 'audio' || !height || height >= 9999 ? '%(title).150B.%(ext)s' : `%(title).150B (${height}p).%(ext)s`;
  // everything is made in a hidden folder of its own, then moved: a file already in the destination
  // with the same name is never touched, replaced or deleted
  const args = ['--no-playlist', '--no-warnings', '--newline', '--progress', '--windows-filenames', '--no-part', '--no-mtime', '-P', `home:${workDir}`, '-P', `temp:${workDir}`, '-o', name];
  args.push('--progress-template', 'download:TMP %(info.format_id)s %(progress.downloaded_bytes)s %(progress.total_bytes,progress.total_bytes_estimate)s %(progress.speed)s');
  args.push('--print', 'after_move:TMPFILE %(filepath)s');
  if (ffmpeg) args.push('--ffmpeg-location', ffmpeg);
  const audioPart = audio?.id ? `${audio.id}` : 'ba';
  if (kind === 'audio') {
    args.push('-f', `${audioPart}/ba/b`, '-x', '--audio-format', 'mp3', '--audio-quality', `${mp3Bitrate(audio?.kbps)}K`);
  } else {
    // the exact file chosen for this quality, joined to the chosen sound (fallbacks if a site changed meanwhile)
    const chosen = videoId ? (withAudio ? `${videoId}` : `${videoId}+${audioPart}/${videoId}+ba`) : `bv*[height<=${height}]+${audioPart}`;
    args.push('-f', `${chosen}/bv*[height<=${height}]+ba/b[height<=${height}]/bv*+ba/b`);
    args.push('-S', `res:${height},vcodec:h264,acodec:aac`, '--merge-output-format', 'mp4');
  }
  args.push(url);
  return args;
};

/** The MP3 bitrate matching the chosen source quality (an MP3 needs a little more to sound the same). */
export const mp3Bitrate = (kbps) => {
  const wanted = (Number(kbps) || 160) * 1.25;
  return [128, 160, 192, 256, 320].find((b) => b >= wanted) || 320;
};

const finishedFile = (dir, kind) => {
  const wanted = kind === 'audio' ? ['.mp3'] : ['.mp4', '.mkv', '.webm', '.mov'];
  const found = fs
    .readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isFile() && wanted.includes(path.extname(e.name).toLowerCase()) && !/\.f\d+\.\w+$/.test(e.name))
    .map((e) => path.join(dir, e.name))
    .sort((a, b) => fs.statSync(b).size - fs.statSync(a).size);
  return found[0] || null;
};

export const download = async ({ url, kind, height, videoId, withAudio, audio, folder, sizes = {} }, { onProgress = () => {}, signal } = {}) => {
  fs.mkdirSync(folder, { recursive: true });
  const { ffmpeg } = findTools();
  if (!ffmpeg) throw coded('no-tools', 'Un composant manque (ffmpeg) : ouvre to mp34 depuis le launcher justecoqqo pour le réparer.');
  const parts = new Map(); // format id → { received, total }
  let file = null;
  let phase = 'download';
  const workDir = path.join(folder, `.to-mp34-${Date.now().toString(36)}`);
  fs.mkdirSync(workDir, { recursive: true });
  const args = downloadArgs({ url, kind, height, videoId, withAudio, audio, folder, ffmpeg, workDir });
  const onLine = (line) => {
    const m = /^TMP (\S+) (\d+) (\d+|NA) (\S+)/.exec(line);
    if (m) {
      const total = m[3] === 'NA' ? sizes[m[1]] || 0 : Number(m[3]);
      parts.set(m[1], { received: Number(m[2]), total });
      const received = [...parts.values()].reduce((sum, p) => sum + p.received, 0);
      const known = [...parts.values()].reduce((sum, p) => sum + (p.total || p.received), 0);
      const expected = Math.max(known, sizes.total || 0);
      onProgress({ phase: 'download', received, total: expected, speed: Number(m[4]) || 0 });
      return;
    }
    if (line.startsWith('TMPFILE ')) file = line.slice(8).trim();
    else if (/^\[(Merger|ExtractAudio|FixupM3u8|VideoConvertor|FFmpeg\w*)\]/.test(line) && phase !== 'finish') {
      phase = 'finish';
      onProgress({ phase: 'finish' });
    } else if (/has already been downloaded/.test(line)) {
      const existing = /\[download\] (.+) has already been downloaded/.exec(line);
      if (existing) file = existing[1];
    }
  };
  try {
    await withUpdate(() => run(args, { onLine, signal }));
    // the folder is private to this download: if the printed name can't be read, the finished file is the one in it
    if (!file || !fs.existsSync(file)) file = finishedFile(workDir, kind);
    if (!file) throw coded('unknown', 'Le fichier téléchargé est introuvable.');
    // into the chosen folder, next to what is already there ("titre (2).mp4" if the name is taken)
    const ext = path.extname(file);
    const base = path.basename(file, ext);
    let target = path.join(folder, `${base}${ext}`);
    for (let n = 2; fs.existsSync(target); n++) target = path.join(folder, `${base} (${n})${ext}`);
    try {
      fs.renameSync(file, target);
    } catch {
      fs.copyFileSync(file, target);
    }
    return { file: target, bytes: fs.statSync(target).size };
  } catch (error) {
    throw explain(error);
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
};
