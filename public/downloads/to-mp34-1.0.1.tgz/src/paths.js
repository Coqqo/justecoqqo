import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { BRAND } from '../public/brand.js';

const dataRoot = () => {
  const home = os.homedir();
  if (process.platform === 'win32') return process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
  if (process.platform === 'darwin') return path.join(home, 'Library', 'Application Support');
  return path.join(home, '.local', 'share');
};

let resolved;
export const appDataDir = () => {
  if (resolved) return resolved;
  resolved = process.env.TOMP34_DATA_DIR || path.join(dataRoot(), BRAND.dataFolder);
  fs.mkdirSync(resolved, { recursive: true });
  return resolved;
};

const configPath = () => path.join(appDataDir(), 'config.json');

export const readConfig = () => {
  try {
    return JSON.parse(fs.readFileSync(configPath(), 'utf8'));
  } catch {
    return {};
  }
};

export const writeConfig = (patch) => {
  const next = { ...readConfig(), ...patch };
  fs.writeFileSync(configPath(), JSON.stringify(next, null, 2));
  return next;
};

/** Where files go when the user has not chosen: Téléchargements\to mp34. */
export const defaultFolder = () => {
  const home = os.homedir();
  const downloads = [path.join(home, 'Downloads'), path.join(home, 'Téléchargements')].find((dir) => fs.existsSync(dir)) || home;
  return path.join(downloads, 'to mp34');
};

export const savedFolder = () => {
  const saved = readConfig().folder;
  return saved && fs.existsSync(saved) ? saved : null;
};
