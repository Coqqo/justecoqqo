import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defaultFolder, readConfig, savedFolder, writeConfig } from './paths.js';
import { coded, download, findTools, PLATFORMS, platformOf, readVideo } from './video.js';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PUBLIC_DIR = path.join(ROOT, 'public');
export const VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const TOKEN = crypto.randomBytes(18).toString('hex');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2' };

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

let electron;
const getElectron = async () => {
  if (electron !== undefined) return electron;
  try {
    electron = process.versions.electron ? await import('electron') : null;
  } catch {
    electron = null;
  }
  return electron;
};
const focusedWindow = (e) => e.BrowserWindow.getFocusedWindow() || e.BrowserWindow.getAllWindows()[0];

const sendJson = (res, status, body) => {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
};

const readBody = (req) =>
  new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 1024 * 1024) {
        reject(new HttpError(413, 'Requête trop volumineuse.'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
      } catch {
        reject(new HttpError(400, 'JSON invalide.'));
      }
    });
    req.on('error', reject);
  });

/* ------------------------------------------------------------------ videos read and downloads */

const infos = new Map(); // url → description (sizes for the progress bar)
const jobs = new Map();
const HISTORY_MAX = 30;

const addToHistory = (entry) => {
  const history = [entry, ...(readConfig().history || []).filter((h) => h.file !== entry.file)].slice(0, HISTORY_MAX);
  writeConfig({ history });
};

const startDownload = (request) => {
  const id = crypto.randomUUID();
  const controller = new AbortController();
  const job = { id, status: 'running', phase: 'start', received: 0, total: 0, speed: 0, title: request.title, kind: request.kind, controller, startedAt: Date.now() };
  jobs.set(id, job);
  download(request, {
    signal: controller.signal,
    onProgress: (progress) => Object.assign(job, progress),
  })
    .then(({ file, bytes }) => {
      Object.assign(job, { status: 'done', phase: 'done', file, bytes });
      addToHistory({ file, title: request.title, kind: request.kind, quality: request.kind === 'audio' ? `MP3` : `${request.height}p`, at: Date.now(), bytes });
    })
    .catch((error) => Object.assign(job, { status: error.code === 'cancelled' ? 'cancelled' : 'error', error: error.message, code: error.code || null }));
  for (const [key, old] of jobs) if (old.status !== 'running' && Date.now() - old.startedAt > 3600 * 1000) jobs.delete(key);
  return job;
};

const publicJob = ({ controller, ...job }) => job;

/* ------------------------------------------------------------------ routes */

const routes = {
  'GET /api/status': async () => {
    const tools = findTools();
    return {
      version: VERSION,
      tools: { ytdlp: Boolean(tools.ytdlp), ffmpeg: Boolean(tools.ffmpeg) },
      nativeDialogs: Boolean(await getElectron()),
      folder: savedFolder() || defaultFolder(),
      remembered: Boolean(savedFolder()),
      platforms: Object.fromEntries(Object.entries(PLATFORMS).map(([id, p]) => [id, p.name])),
      history: (readConfig().history || []).filter((h) => fs.existsSync(h.file)).slice(0, 8),
    };
  },

  'POST /api/info': async (body) => {
    const url = String(body.url || '').trim();
    const platform = platformOf(url);
    if (!platform) throw new HttpError(400, "Ce n'est pas un lien. Copie le lien depuis l'appli ou le site (bouton Partager › Copier le lien).", 'bad-link');
    const info = await readVideo(url);
    infos.set(url, info);
    if (infos.size > 20) infos.delete(infos.keys().next().value);
    return { ...info, platform };
  },

  'POST /api/pick-folder': async (body) => {
    const e = await getElectron();
    if (!e) throw new HttpError(400, 'Indisponible ici.');
    const result = await e.dialog.showOpenDialog(focusedWindow(e), { properties: ['openDirectory', 'createDirectory'], defaultPath: body.current || defaultFolder(), title: 'Où enregistrer ?' });
    return { folder: result.canceled ? null : result.filePaths[0] };
  },

  'POST /api/download': async (body) => {
    const url = String(body.url || '').trim();
    const info = infos.get(url);
    if (!info) throw new HttpError(400, 'Recolle le lien de la vidéo.', 'bad-link');
    const kind = body.kind === 'audio' ? 'audio' : 'video';
    const folder = String(body.folder || '').trim() || defaultFolder();
    if (!path.isAbsolute(folder)) throw new HttpError(400, 'Choisis un dossier.', 'folder');
    try {
      fs.mkdirSync(folder, { recursive: true });
      fs.accessSync(folder, fs.constants.W_OK);
    } catch {
      throw coded('folder', "to mp34 ne peut pas écrire dans ce dossier : choisis-en un autre.");
    }
    let height = null;
    let video = null;
    if (kind === 'video') {
      const choice = info.video.find((v) => v.height === Number(body.height)) || info.video.find((v) => v.height === info.defaultHeight) || info.video[0];
      if (!choice) throw new HttpError(400, "Cette vidéo n'a pas de qualité disponible.", 'unavailable');
      height = choice.height;
      video = choice;
    }
    const audio = info.audio.find((a) => a.kbps === Number(body.audioKbps)) || info.audio[0] || null;
    if (kind === 'video' && !height) height = 9999; // quality not given: whatever the site has
    const videoSize = kind === 'video' ? info.video.find((v) => v.height === height)?.sizeBytes || 0 : 0;
    const sizes = { total: videoSize + (audio?.sizeBytes || 0) };
    if (audio?.id) sizes[audio.id] = audio.sizeBytes;
    if (body.remember) writeConfig({ folder });
    else if (readConfig().folder && body.forget) writeConfig({ folder: null });
    if (video?.id) sizes[video.id] = video.sizeBytes;
    const job = startDownload({ url, kind, height, videoId: video?.id, withAudio: video?.withAudio, audio, folder, sizes, title: info.title });
    return { id: job.id };
  },

  'POST /api/report': async (body) => {
    // "Prévenir Coqqo de l'incident": forwarded to the site, which posts it in the app's Discord channel
    const response = await fetch('https://justecoqqo.fr/api/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app: 'to-mp34', message: String(body.message || '').slice(0, 1500), context: body.context && typeof body.context === 'object' ? body.context : {} }),
      signal: AbortSignal.timeout(10000),
    }).catch(() => null);
    if (!response?.ok) throw new HttpError(502, 'Envoi impossible.');
    return { ok: true };
  },

  'GET /api/job': (_body, query) => {
    const job = jobs.get(query.get('id'));
    if (!job) throw new HttpError(404, 'Téléchargement introuvable.');
    return publicJob(job);
  },

  'POST /api/cancel': (body) => {
    jobs.get(String(body.id))?.controller.abort();
    return { ok: true };
  },

  'POST /api/forget-folder': () => {
    writeConfig({ folder: null });
    return { folder: defaultFolder() };
  },

  'POST /api/reveal': async (body) => {
    const e = await getElectron();
    const file = String(body.file || '');
    if (e && file && fs.existsSync(file)) e.shell.showItemInFolder(file);
    return { ok: true };
  },

  'POST /api/open': async (body) => {
    const e = await getElectron();
    const file = String(body.file || '');
    if (e && file && fs.existsSync(file)) await e.shell.openPath(file);
    return { ok: true };
  },
};

const serveStatic = (res, pathname) => {
  const relative = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  const file = path.normalize(path.join(PUBLIC_DIR, relative));
  if (!file.startsWith(PUBLIC_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404);
    return res.end('Introuvable');
  }
  let content = fs.readFileSync(file);
  if (relative === 'index.html') content = Buffer.from(content.toString('utf8').replace('__APP_TOKEN__', TOKEN));
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  res.end(content);
};

const handle = async (req, res, port) => {
  const host = req.headers.host || '';
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    res.writeHead(403);
    return res.end();
  }
  const url = new URL(req.url, `http://${host}`);
  if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
  if (req.headers['x-app-token'] !== TOKEN) return sendJson(res, 403, { error: 'Accès refusé.' });
  const route = routes[`${req.method} ${url.pathname}`];
  if (!route) return sendJson(res, 404, { error: 'Route inconnue.' });
  try {
    const body = req.method === 'POST' ? await readBody(req) : {};
    sendJson(res, 200, await route(body, url.searchParams));
  } catch (error) {
    if (error instanceof HttpError) return sendJson(res, error.status, { error: error.message, code: error.code });
    if (error.code && /^[a-z-]+$/.test(error.code)) return sendJson(res, 400, { error: error.message, code: error.code });
    console.error(error);
    sendJson(res, 500, { error: error.message || 'Erreur inattendue.' });
  }
};

export const startServer = ({ preferredPort = 4880, attempts = 15 } = {}) =>
  new Promise((resolve, reject) => {
    const tryPort = (port, attemptsLeft) => {
      const server = http.createServer((req, res) =>
        handle(req, res, server.address().port).catch((error) => {
          console.error(error);
          if (!res.headersSent) sendJson(res, 500, { error: 'Erreur inattendue.' });
          else res.end();
        }),
      );
      server.once('error', (error) => {
        if (error.code === 'EADDRINUSE' && attemptsLeft > 0) tryPort(port + 1, attemptsLeft - 1);
        else reject(error);
      });
      server.listen(port, '127.0.0.1', () => {
        const actual = server.address().port;
        resolve({ url: `http://127.0.0.1:${actual}/`, port: actual, server });
      });
    };
    tryPort(preferredPort, attempts);
  });
