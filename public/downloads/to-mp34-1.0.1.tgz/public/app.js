// to mp34: site → link → video or sound → quality → folder → download.
import { BRAND } from './brand.js';
import { PROBLEMS, TIPS, problemFor } from './help.js';
import { offerReport, setupReports } from './report.js';

const TOKEN = document.querySelector('meta[name="app-token"]').content;
const $ = (id) => document.getElementById(id);
const el = (tag, props = {}, children = []) => {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else if (value !== undefined && value !== null && value !== false) node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of [].concat(children)) if (child !== null && child !== undefined && child !== false) node.append(child);
  return node;
};
const icon = (name) => {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#i-${name}`);
  svg.append(use);
  return svg;
};
const api = async (path, { method = 'GET', body } = {}) => {
  const response = await fetch(path, { method, headers: { 'X-App-Token': TOKEN, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || `Erreur ${response.status}`), { code: data.code });
  return data;
};

const bytes = (value) => {
  if (!value) return '';
  if (value < 1e6) return `${Math.max(1, Math.round(value / 1e3))} Ko`;
  if (value < 1e9) return `${Math.round(value / 1e6)} Mo`;
  return `${(value / 1e9).toFixed(1).replace('.', ',')} Go`;
};
const duration = (seconds) => {
  if (!seconds) return '';
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`;
};
const date = (ms) => new Date(ms).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });
let toastTimer;
const toast = (message) => {
  $('toast').textContent = message;
  $('toast').hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ($('toast').hidden = true), 3500);
};

/* ------------------------------------------------------------------ state and steps */

const STEPS = ['platform', 'link', 'kind', 'quality', 'folder', 'progress'];
const state = { platform: null, url: '', info: null, kind: 'video', height: null, audioKbps: null, folder: '', remember: false, job: null };
let status = {};
const history = [];

const go = (step, { push = true } = {}) => {
  if (push && state.step && state.step !== step) history.push(state.step);
  state.step = step;
  document.querySelectorAll('[data-panel]').forEach((panel) => (panel.hidden = panel.dataset.panel !== step));
  const index = STEPS.indexOf(step);
  document.querySelectorAll('#steps li').forEach((li, i) => {
    li.classList.toggle('on', i === index);
    li.classList.toggle('done', i < index);
  });
  window.scrollTo(0, 0);
};
document.querySelectorAll('[data-back]').forEach((button) => button.addEventListener('click', () => go(history.pop() || 'platform', { push: false })));

const restart = () => {
  history.length = 0;
  Object.assign(state, { url: '', info: null, job: null });
  $('linkInput').value = '';
  $('linkProblem').hidden = true;
  refreshRecent();
  go('platform', { push: false });
};
$('homeBtn').addEventListener('click', () => {
  if (state.step === 'progress' && state.job && !state.job.finished) return toast('Un téléchargement est en cours.');
  restart();
});

/* ------------------------------------------------------------------ problems and help */

const problemBox = (box, error) => {
  const problem = problemFor(error.code);
  setTimeout(() => offerReport(error, { where: state.step === 'progress' ? 'téléchargement' : 'lecture du lien' }), 800);
  box.replaceChildren(icon('alert'), el('b', { text: error.message || problem.title }), el('p', { text: problem.text }), el('button', { type: 'button', text: 'Toute l’aide', onclick: () => openHelp(problem.code) }));
  box.hidden = false;
};

const openHelp = (code) => {
  $('scrim').hidden = false;
  $('helpSheet').hidden = false;
  $('helpSheet').querySelectorAll('details').forEach((d) => (d.open = d.dataset.code === code));
  const target = code && $('helpSheet').querySelector(`details[data-code="${code}"]`);
  if (target) setTimeout(() => target.scrollIntoView({ block: 'center' }), 50);
};
const closeHelp = () => {
  $('scrim').hidden = true;
  $('helpSheet').hidden = true;
};
$('helpBtn').addEventListener('click', () => openHelp(null));
$('scrim').addEventListener('click', closeHelp);
document.querySelector('[data-close]').addEventListener('click', closeHelp);
document.addEventListener('keydown', (event) => event.key === 'Escape' && closeHelp());
const item = (code, entry) => el('details', { 'data-code': code }, [el('summary', { text: entry.title }), el('p', { text: entry.text })]);
$('helpList').replaceChildren(
  el('h3', { text: 'Bon à savoir' }),
  ...TIPS.map((tip, i) => item(`tip-${i}`, tip)),
  el('h3', { text: 'Si quelque chose ne marche pas' }),
  ...Object.entries(PROBLEMS).map(([code, entry]) => item(code, entry)),
);

/* ------------------------------------------------------------------ 1. platform */

const LINK_HINTS = {
  youtube: 'Dans YouTube : bouton Partager sous la vidéo, puis « Copier le lien ».',
  instagram: 'Dans Instagram : les trois points ou l’avion en papier sur le Reel, puis « Copier le lien ».',
  tiktok: 'Dans TikTok : la flèche Partager à droite de la vidéo, puis « Copier le lien ».',
};
document.querySelectorAll('[data-platform]').forEach((tile) =>
  tile.addEventListener('click', () => {
    state.platform = tile.dataset.platform;
    $('linkPlatform').textContent = `${status.platforms?.[state.platform] || ''}`;
    $('linkHint').textContent = LINK_HINTS[state.platform];
    $('linkProblem').hidden = true;
    go('link');
    setTimeout(() => $('linkInput').focus(), 50);
  }),
);

const refreshRecent = async () => {
  try {
    status = await api('/api/status');
  } catch {
    return;
  }
  const recent = status.history || [];
  $('recent').hidden = !recent.length;
  $('recentList').replaceChildren(
    ...recent.map((entry) =>
      el('li', {}, el('button', { type: 'button', title: 'Afficher dans le dossier', onclick: () => api('/api/reveal', { method: 'POST', body: { file: entry.file } }) }, [icon(entry.kind === 'audio' ? 'wave' : 'film'), el('span', { class: 'r-title', text: entry.title }), el('span', { class: 'r-meta', text: `${entry.quality} · ${bytes(entry.bytes)}` })])),
    ),
  );
};

/* ------------------------------------------------------------------ 2. link */

$('pasteBtn').addEventListener('click', async () => {
  try {
    $('linkInput').value = (await navigator.clipboard.readText()).trim();
    $('linkInput').focus();
  } catch {
    toast('Fais Ctrl + V dans la case.');
  }
});

const platformFromLink = (link) => {
  const host = (() => {
    try {
      return new URL(link).hostname.toLowerCase();
    } catch {
      return '';
    }
  })();
  if (/youtube\.com$|youtu\.be$/.test(host)) return 'youtube';
  if (/instagram\.com$|instagr\.am$/.test(host)) return 'instagram';
  if (/tiktok\.com$/.test(host)) return 'tiktok';
  return null;
};

$('linkForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  let link = $('linkInput').value.trim();
  if (link && !/^https?:\/\//i.test(link)) link = `https://${link}`;
  if (!link) return $('linkInput').focus();
  const found = platformFromLink(link);
  if (found && found !== state.platform) {
    state.platform = found;
    toast(`C'est un lien ${status.platforms?.[found] || found} : pas de souci.`);
  }
  const button = $('linkGo');
  button.disabled = true;
  button.replaceChildren(el('span', { class: 'spinner' }), 'Lecture de la vidéo…');
  $('linkProblem').hidden = true;
  try {
    const info = await api('/api/info', { method: 'POST', body: { url: link } });
    Object.assign(state, { url: link, info, height: info.defaultHeight, audioKbps: info.defaultAudio });
    if (!info.video.length) state.kind = 'audio';
    renderVideoCard($('videoCard'));
    document.querySelector('[data-kind="video"]').hidden = !info.video.length;
    go('kind');
  } catch (error) {
    problemBox($('linkProblem'), error);
  } finally {
    button.disabled = false;
    button.replaceChildren('Continuer', icon('arrow'));
  }
});

const renderVideoCard = (box) => {
  const info = state.info;
  const thumb = info.thumbnail && /^https:\/\//.test(info.thumbnail) ? el('img', { src: info.thumbnail, alt: '', referrerpolicy: 'no-referrer' }) : el('span', { class: 'thumb' });
  thumb.addEventListener?.('error', () => thumb.replaceWith(el('span', { class: 'thumb' })));
  box.replaceChildren(thumb, el('div', {}, [el('b', { text: info.title }), el('span', { text: [status.platforms?.[state.platform], info.uploader, duration(info.seconds)].filter(Boolean).join(' · ') })]));
};

/* ------------------------------------------------------------------ 3. video or sound */

document.querySelectorAll('[data-kind]').forEach((tile) =>
  tile.addEventListener('click', () => {
    state.kind = tile.dataset.kind;
    renderQuality();
    go('quality');
  }),
);

/* ------------------------------------------------------------------ 4. quality */

const renderQuality = () => {
  const { info } = state;
  const video = state.kind === 'video';
  $('videoQuality').hidden = !video;
  if (video) {
    const best = info.video[0];
    $('videoMax').textContent = best ? `jusqu'à ${best.label}${best.name ? ` ${best.name}` : ''} pour cette vidéo` : '';
    $('videoChoices').replaceChildren(
      ...info.video.map((choice) => {
        const button = el('button', { type: 'button', class: `choice${choice.height === state.height ? ' on' : ''}` }, [
          el('b', { text: choice.label }),
          el('span', { text: [choice.name, choice.fps ? `${choice.fps} i/s` : '', choice.sizeBytes ? `≈ ${bytes(choice.sizeBytes)}` : ''].filter(Boolean).join(' · ') || ' ' }),
        ]);
        button.addEventListener('click', () => {
          state.height = choice.height;
          renderQuality();
        });
        return button;
      }),
    );
  }
  $('audioChoices').replaceChildren(
    ...info.audio.map((choice) => {
      const button = el('button', { type: 'button', class: `choice${choice.kbps === state.audioKbps ? ' on' : ''}` }, [el('b', { text: choice.name || choice.label }), el('span', { text: choice.name ? choice.label : video ? 'plus léger' : 'MP3 plus léger' })]);
      button.addEventListener('click', () => {
        state.audioKbps = choice.kbps;
        renderQuality();
      });
      return button;
    }),
  );
  if (!info.audio.length) $('audioChoices').replaceChildren(el('p', { class: 'hint', text: 'Le meilleur son disponible.' }));
};

$('qualityGo').addEventListener('click', () => {
  $('folderPath').textContent = state.folder || status.folder;
  state.folder = state.folder || status.folder;
  $('rememberFolder').checked = Boolean(status.remembered);
  $('folderPick').hidden = !status.nativeDialogs;
  renderSummary();
  go('folder');
});

/* ------------------------------------------------------------------ 5. folder */

const renderSummary = () => {
  const { info } = state;
  const video = state.kind === 'video';
  const v = info.video.find((c) => c.height === state.height);
  const a = info.audio.find((c) => c.kbps === state.audioKbps);
  const parts = [video ? ['Vidéo', 'MP4'] : ['Son', 'MP3'], video && v ? ['Image', `${v.label}${v.name ? ` ${v.name}` : ''}`] : null, a ? ['Son', a.name ? `${a.name} (${a.label})` : a.label] : null];
  const size = (video ? v?.sizeBytes || 0 : 0) + (a?.sizeBytes || 0);
  if (size) parts.push(['Taille', `≈ ${bytes(size)}`]);
  $('summary').replaceChildren(...parts.filter(Boolean).map(([k, value]) => el('span', {}, [`${k} `, el('b', { text: value })])));
};

$('folderPick').addEventListener('click', async () => {
  try {
    const { folder } = await api('/api/pick-folder', { method: 'POST', body: { current: state.folder } });
    if (folder) {
      state.folder = folder;
      $('folderPath').textContent = folder;
    }
  } catch (error) {
    toast(error.message);
  }
});

$('downloadGo').addEventListener('click', async () => {
  const remember = $('rememberFolder').checked;
  $('downloadProblem').hidden = true;
  try {
    const { id } = await api('/api/download', {
      method: 'POST',
      body: { url: state.url, kind: state.kind, height: state.height, audioKbps: state.audioKbps, folder: state.folder, remember, forget: !remember },
    });
    state.job = { id };
    renderVideoCard($('progressCard'));
    $('doneBox').hidden = true;
    $('progressActions').hidden = false;
    $('progressBar').style.width = '0%';
    $('progressTitle').textContent = 'Téléchargement…';
    $('progressMeta').textContent = '';
    go('progress');
    poll(id);
  } catch (error) {
    toast(`${error.message} ${problemFor(error.code).text}`);
    offerReport(error, { where: 'téléchargement' });
  }
});

/* ------------------------------------------------------------------ 6. progress */

let lastSample = null;
const poll = async (id) => {
  if (state.job?.id !== id) return;
  let job;
  try {
    job = await api(`/api/job?id=${id}`);
  } catch {
    return setTimeout(() => poll(id), 1000);
  }
  const bar = $('progressBar');
  const track = bar.parentElement;
  if (job.status === 'running') {
    if (job.phase === 'finish') {
      track.classList.add('indeterminate');
      $('progressTitle').textContent = state.kind === 'audio' ? 'Conversion en MP3…' : 'Assemblage de l’image et du son…';
      $('progressMeta').textContent = 'Presque fini.';
    } else if (job.total) {
      track.classList.remove('indeterminate');
      const percent = Math.min(99, (job.received / job.total) * 100);
      bar.style.width = `${percent}%`;
      $('progressTitle').textContent = `Téléchargement… ${Math.floor(percent)} %`;
      const speed = job.speed ? ` · ${bytes(job.speed)}/s` : '';
      const remaining = job.speed ? Math.max(0, (job.total - job.received) / job.speed) : null;
      $('progressMeta').textContent = `${bytes(job.received)} sur ${bytes(job.total)}${speed}${remaining ? ` · encore ${Math.ceil(remaining)} s` : ''}`;
    } else {
      track.classList.add('indeterminate');
      $('progressMeta').textContent = 'Préparation…';
    }
    lastSample = job;
    return setTimeout(() => poll(id), 500);
  }
  track.classList.remove('indeterminate');
  state.job.finished = true;
  $('progressActions').hidden = true;
  if (job.status === 'done') {
    bar.style.width = '100%';
    $('progressTitle').textContent = 'C’est prêt !';
    $('progressMeta').textContent = `${job.file} · ${bytes(job.bytes)}`;
    $('doneBox').hidden = false;
    $('openFileBtn').hidden = !status.nativeDialogs;
    $('revealBtn').hidden = !status.nativeDialogs;
    $('openFileBtn').onclick = () => api('/api/open', { method: 'POST', body: { file: job.file } });
    $('revealBtn').onclick = () => api('/api/reveal', { method: 'POST', body: { file: job.file } });
  } else if (job.status === 'cancelled') {
    restart();
    toast('Téléchargement annulé.');
  } else {
    $('progressTitle').textContent = 'Ça n’a pas marché';
    $('progressMeta').textContent = '';
    problemBox($('downloadProblem'), { message: job.error, code: job.code });
    $('doneBox').hidden = false;
    $('openFileBtn').hidden = true;
    $('revealBtn').hidden = true;
  }
};

$('cancelBtn').addEventListener('click', () => state.job && api('/api/cancel', { method: 'POST', body: { id: state.job.id } }));
$('againBtn').addEventListener('click', restart);

/* ------------------------------------------------------------------ start */

$('supportLink').href = BRAND.support;
refreshRecent().then(() => {
  setupReports({ app: 'to-mp34', version: status.version, accent: '#c8ff4d', onAccent: '#0e0f13', send: (payload) => api('/api/report', { method: 'POST', body: payload }) });
  if (!status.tools?.ytdlp || !status.tools?.ffmpeg) problemBox($('linkProblem'), { code: 'no-tools', message: PROBLEMS['no-tools'].title });
});
go('platform', { push: false });
