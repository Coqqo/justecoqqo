// Every problem to mp34 can run into, and what to do. Shown under each error and in the "Aide" panel.
// The same list is on the site (justecoqqo.fr/to-mp34/#aide).

export const TIPS = [
  { title: 'Où trouver le lien ?', text: 'Dans l’appli YouTube, Instagram ou TikTok : bouton Partager, puis « Copier le lien ». Sur ordinateur : copie l’adresse de la page de la vidéo.' },
  { title: 'Pourquoi 1080p est choisi de base ?', text: 'C’est la meilleure qualité pour un écran d’ordinateur ou de téléphone, avec des fichiers raisonnables. Si la vidéo existe en 2K ou 4K, tu peux les choisir, gratuitement.' },
  { title: 'Ma vidéo 4K ne se lit pas', text: 'Les vidéos 2K et 4K de YouTube utilisent un format (VP9 ou AV1) que certains vieux lecteurs ne connaissent pas. Ouvre-la avec VLC (gratuit) ou installe l’extension « VP9 / AV1 » gratuite du Microsoft Store.' },
  { title: 'Il n’y a pas de 1080p dans la liste', text: 'La qualité proposée dépend de la vidéo : si elle a été publiée en 720p, on ne peut pas aller au-dessus.' },
];

export const PROBLEMS = {
  'bad-link': { title: 'Ce lien ne mène pas à une vidéo', text: 'Copie le lien de la vidéo elle-même, pas celui d’un profil, d’une recherche ou d’une page d’accueil. Bouton Partager › Copier le lien.' },
  playlist: { title: 'C’est une playlist ou un profil', text: 'to mp34 télécharge une vidéo à la fois : ouvre la vidéo que tu veux, puis copie son lien.' },
  private: { title: 'Vidéo privée ou réservée', text: 'La vidéo est privée, réservée aux abonnés d’une chaîne, ou limitée par l’âge : elle ne peut pas être téléchargée.' },
  unavailable: { title: 'Vidéo pas disponible', text: 'Elle a été supprimée, mise en privé ou bloquée dans ton pays. Ouvre le lien dans ton navigateur pour vérifier.' },
  live: { title: 'C’est un direct', text: 'Les directs en cours ne se téléchargent pas. Attends la fin du direct, puis recommence.' },
  offline: { title: 'Pas de connexion à internet', text: 'Vérifie ta connexion (Wi-Fi, câble), puis réessaie.' },
  'rate-limit': { title: 'Le site bloque pour le moment', text: 'Après beaucoup de téléchargements, YouTube ou TikTok ralentissent parfois. Attends quelques minutes, puis réessaie.' },
  folder: { title: 'Impossible d’écrire dans ce dossier', text: 'Choisis un autre dossier (Téléchargements, Bureau…). Les dossiers système ou en lecture seule ne marchent pas.' },
  'disk-full': { title: 'Plus de place sur le disque', text: 'Une vidéo 4K peut peser plusieurs Go. Libère de la place ou choisis une qualité plus basse.' },
  'no-tools': { title: 'Un composant manque', text: 'Ouvre le launcher justecoqqo, puis to mp34 : il se répare tout seul. Sinon, retélécharge to mp34 depuis justecoqqo.fr.' },
  unknown: { title: 'Le téléchargement n’a pas marché', text: 'Réessaie : to mp34 se met à jour tout seul quand un site change. Si ça recommence, essaie une autre qualité, puis écris-moi sur TikTok avec le lien.' },
  smartscreen: { title: 'Windows affiche « Windows a protégé votre ordinateur »', text: 'C’est normal pour une petite appli pas encore signée. Clique sur « Informations complémentaires », puis « Exécuter quand même ».' },
};

export const problemFor = (code) => (code && PROBLEMS[code] ? { code, ...PROBLEMS[code] } : { code: 'unknown', ...PROBLEMS.unknown });
