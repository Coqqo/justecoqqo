// The only place where the name and the links of the tool are written.
export const BRAND = Object.freeze({
  name: 'to mp34',
  tagline: 'Télécharge une vidéo ou un son en un clic',
  site: 'https://justecoqqo.fr',
  page: 'https://justecoqqo.fr/to-mp34/',
  support: 'https://justecoqqo.fr/soutenir/?app=to-mp34',
  dataFolder: 'to-mp34',
});
